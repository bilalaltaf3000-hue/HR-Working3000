import React, { useEffect, useMemo, useState } from 'react'
import { api, download } from '../api.js'
import { buildOrg, fmt, scopeData } from '../org.js'
import { L } from '../prefs.js'
import { Modal, PeopleModal } from '../ui.jsx'
import { Classic, vacMapOf } from './Organogram.jsx'
import { BenchFramework } from './Benchmark.jsx'

// The HR Dashboard: the restructure, As Is (the HR master file, which the admin can correct or replace) against To Be
// (the portal today). People added in the portal and resigned people are already reflected on both sides, so only the
// restructuring shows: layers, spans, functions, single-report managers, taggings and headcount saved.
const n1 = v => v === null || v === undefined ? '–' : Number(v).toLocaleString('en-US', { maximumFractionDigits: 1 })
const CHANGES = [
  ['line', 'Reporting line changes', 'mv'], ['function', 'Function changes', 'mv'], ['span', 'Span of control changes', 'mv'],
  ['layer', 'Layer changes', 'mv'], ['grade', 'Grade changes', 'mv'], ['title', 'Title changes', 'mv'],
  ['saved', 'Headcount saved', 'gone'], ['resigned', 'Resigned', 'gone'], ['removed', 'In As Is, not in the portal', 'gone'],
  ['added', 'Added (not in the As Is)', 'new'], ['tbh', 'Positions to be hired', 'new'],
]
const COLS = {   // the columns of each change list: [heading, field]
  line: [['As Is manager', 'frm'], ['To Be manager', 'to']], function: [['From', 'frm'], ['To', 'to']], span: [['As Is direct reports', 'frm'], ['To Be', 'to']],
  layer: [['As Is', 'frm'], ['To Be', 'to']], grade: [['From', 'frm'], ['To', 'to']], title: [['As Is title', 'frm'], ['To Be title', 'to']],
  saved: [['Reason', 'reason'], ['Date', 'date'], ['Direct reports (As Is)', 'reports']], resigned: [['Resigned on', 'date']],
  removed: [['As Is manager', 'frm']], added: [['Reports to', 'to'], ['Why', 'why']], tbh: [['Vacancy', 'kind'], ['Type', 'emp_type'], ['Open', 'count'], ['Reports to', 'to']],
  single: [['As Is direct reports', 'frm'], ['To Be direct reports', 'to']], fn_added: [['As Is people', 'frm'], ['To Be people', 'to']], fn_removed: [['As Is people', 'frm'], ['To Be people', 'to']],
  tagging: [['As Is', 'frm'], ['To Be', 'to']], bm_room: [['Level', 'level'], ['Max grade', 'max']], bm_at: [['Level', 'level'], ['Max grade', 'max']], bm_above: [['Level', 'level'], ['Max grade', 'max']],
  hiring_removed: [['Vacancy', 'kind'], ['Positions', 'count'], ['Reason', 'reason'], ['Removed on', 'date']],
  saved_all: [['Saved as', 'what'], ['Headcount', 'n'], ['Reason', 'reason'], ['Date', 'date']],
}

function Delta({ a, b, low, digits }) {
  if (a === undefined || b === undefined || a === b) return <em className="ch-d">no change</em>
  const d = Math.round((b - a) * 10) / 10
  const good = low ? d < 0 : d > 0
  return <em className={'ch-d ' + (good ? 'good' : 'bad')}>{(d > 0 ? '+' : '') + (digits ? d.toFixed(1) : fmt(d) === '-' ? d : d.toLocaleString('en-US'))}</em>
}

function Kpi({ label, a, b, low, digits, sub }) {
  return <div className="ch-k"><span>{label}</span>
    <div className="v">{a !== undefined && <s>{n1(a)}</s>}<b>{n1(b)}</b>{a !== undefined && <Delta a={a} b={b} low={low} digits={digits} />}</div>{sub && <small>{sub}</small>}</div>
}

function ChangeList({ k, title, rows, onPerson, onClose }) {
  const [q, setQ] = useState('')
  const ql = q.trim().toLowerCase()
  const list = rows.filter(r => !ql || (r.name + ' ' + r.code + ' ' + r.function + ' ' + (r.frm || '') + ' ' + (r.to || '')).toLowerCase().includes(ql))
  const cols = COLS[k] || []
  return <Modal wide title={title} sub={k === 'saved_all' ? `${fmt(rows.reduce((a, r) => a + (r.n || 1), 0))} headcount saved` : `${fmt(rows.length)} ${k === 'tbh' ? 'positions' : 'employees'}`} onClose={onClose}>
    <div className="kvline" style={{ marginBottom: 8 }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} /></div>
    <div className="tw scroll" style={{ maxHeight: 480 }}><table>
      <thead><tr><th>{k === 'tbh' ? 'Position' : k === 'saved_all' ? 'Employee / position' : 'Employee'}</th><th>Grade</th><th>Function</th>{cols.map(c => <th key={c[1]}>{c[0]}</th>)}</tr></thead>
      <tbody>{list.slice(0, 1000).map((r, i) => <tr key={r.code || i} className={r.code && onPerson ? 'click' : ''} onClick={r.code && onPerson ? () => onPerson(r) : undefined} title={r.code ? 'Show in the organograms' : ''}>
        <td><b>{r.name}</b>{r.code && <div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div>}</td><td>{r.grade}</td><td>{r.function}</td>
        {cols.map(c => <td key={c[1]} className={c[1] === 'to' && k === 'grade' ? (r.up ? 'ch-up' : 'ch-dn') : ''}>{String(r[c[1]] ?? '')}</td>)}</tr>)}
        {!list.length && <tr><td colSpan={3 + cols.length} className="formula">None.</td></tr>}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={() => {
      const csv = [[k === 'tbh' ? 'Position' : 'Employee', 'Code', 'Grade', 'Function', ...cols.map(c => c[0])], ...list.map(r => [r.name, r.code, r.grade, r.function, ...cols.map(c => r[c[1]] ?? '')])]
        .map(x => x.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n')
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' })); a.download = title + '.csv'; a.click()
    }}>Download List</button></div>
  </Modal>
}

// ---------------------------------------------------------------- vacant / to be hired positions, Replacement and New apart
function VacList({ tbh, onClose }) {
  const tabs = [['replacement', L('vac.repl'), tbh.filter(v => v.vk === 'replacement')], ['new', L('vac.new'), tbh.filter(v => v.vk !== 'replacement')]]
  const [tab, setTab] = useState(tabs[0][2].length || !tabs[1][2].length ? 'replacement' : 'new')
  const [q, setQ] = useState('')
  const cur = tabs.find(t => t[0] === tab)
  const ql = q.trim().toLowerCase()
  const rows = cur[2].filter(r => !ql || [r.name, r.function, r.to, r.unit, r.grade].join(' ').toLowerCase().includes(ql))
  const n = rs => rs.reduce((a, r) => a + (r.count || 0), 0)
  const rem = tab === 'removed'
  return <Modal wide title="Vacant / To Be Hired Positions" sub="To Be · not counted as employees" onClose={onClose}>
    <div className="tabs" style={{ marginBottom: 10 }}>{tabs.map(([k, t, rs]) => <button key={k} aria-current={tab === k} onClick={() => setTab(k)}>{t} ({fmt(n(rs)) === '-' ? 0 : fmt(n(rs))})</button>)}</div>
    <div className="kvline" style={{ marginBottom: 8 }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} /></div>
    <div className="tw scroll" style={{ maxHeight: 440 }}><table>
      <thead><tr><th>Position</th><th>Vacancy</th><th>Function</th><th>Reports To</th><th>Type</th><th>Grade</th><th className="num">{rem ? 'Positions' : 'Open'}</th><th>{rem ? 'Reason' : 'Note'}</th></tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i} className={rem ? 'vac-done' : ''}><td><b>{r.name}</b>{r.unit && <div className="formula">{r.unit}</div>}</td>
        <td><span className={'vk-pill ' + (r.vk === 'replacement' ? 'vk-r' : 'vk-n')}>{L(r.vk === 'replacement' ? 'vac.repl' : 'vac.new')}</span></td>
        <td>{r.function}</td><td>{r.to || 'Function head'}</td><td>{r.emp_type}</td><td>{r.grade || '-'}</td><td className="num">{fmt(r.count)}</td>
        <td className="formula">{rem ? [r.reason, r.date].filter(Boolean).join(' · ') : r.note || ''}</td></tr>)}
        {!rows.length && <tr><td colSpan={8} className="formula">None.</td></tr>}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={() => {
      const csv = [['Position', 'Vacancy', 'Function', 'Reports To', 'Type', 'Grade', rem ? 'Positions' : 'Open', rem ? 'Reason' : 'Note'], ...rows.map(r => [r.name, L(r.vk === 'replacement' ? 'vac.repl' : 'vac.new'), r.function, r.to, r.emp_type, r.grade, r.count, rem ? [r.reason, r.date].filter(Boolean).join(' · ') : r.note || ''])]
        .map(x => x.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n')
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' })); a.download = cur[1] + ' positions.csv'; a.click()
    }}>Download List</button></div>
  </Modal>
}

// ---------------------------------------------------------------- the As Is data: corrections and a new HR file
function AsIsData({ notify, canEdit, onChanged, onClose }) {
  const [d, setD] = useState(null)
  const [q, setQ] = useState('')
  const [show, setShow] = useState('')
  const [ed, setEd] = useState(null)   // the row being edited / added
  const [up, setUp] = useState(null)   // {file, rep}
  const load = () => api(`/api/chro/asis?q=${encodeURIComponent(q)}&show=${show}`).then(setD).catch(e => notify(e.message, true))
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [q, show])
  const save = async () => {
    try {
      const body = { name: ed.name, grade_raw: ed.grade_raw, position: ed.position, function: ed.function, manager_code: ed.manager_code, emp_type: ed.emp_type, kind: ed.kind, unit: ed.unit, note: ed.note }
      if (ed.isNew) await api('/api/chro/asis', { method: 'POST', body: { code: ed.code, ...body } })
      else await api('/api/chro/asis/' + encodeURIComponent(ed.code), { method: 'PATCH', body })
      notify(ed.isNew ? 'Added to the As Is.' : 'As Is corrected.'); setEd(null); load(); onChanged()
    } catch (e) { notify(e.message, true) }
  }
  const remove = async r => {
    if (!window.confirm(`Remove ${r.name} from the As Is? Their team in the As Is will report to their manager.`)) return
    try { await api('/api/chro/asis/' + encodeURIComponent(r.code), { method: 'DELETE' }); notify('Removed from the As Is.'); setEd(null); load(); onChanged() } catch (e) { notify(e.message, true) }
  }
  const upload = async (file, dry) => {
    const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false')
    try {
      const rep = await api('/api/chro/asis/upload', { method: 'POST', form: fd })
      if (dry) setUp({ file, rep }); else { setUp(null); notify(`As Is replaced: ${fmt(rep.rows)} employees from ${file.name}.`); load(); onChanged() }
    } catch (e) { notify(e.message, true) }
  }
  const reset = async () => {
    if (!window.confirm('Rebuild the As Is from the database (the HR master file imported in Admin)? An uploaded HR file stops being used and every correction made here is lost.')) return
    try { const r = await api('/api/chro/asis/reset', { method: 'POST' }); notify(`As Is rebuilt: ${fmt(r.rows)} employees.`); load(); onChanged() } catch (e) { notify(e.message, true) }
  }
  const m = d?.meta || {}
  return <Modal wide title="As Is Data" sub={d ? `${m.file || 'HR master file'} · ${fmt(d.total)} employees${d.edited ? ` · ${fmt(d.edited)} corrected or added` : ''}${m.loaded_at ? ' · loaded ' + m.loaded_at : ''}` : ''} onClose={onClose}>
    <p className="formula" style={{ marginTop: 0 }}>The As Is is used only on this dashboard. {m.source === 'upload' ? 'It comes from an HR file uploaded for this dashboard.' : 'It comes from the database: each employee as in the HR master file imported in Admin (HR manager, function, grade and position), and it follows a new import there.'} Correcting it, or replacing it with a new HR file, does not change anything else in the portal.</p>
    {canEdit && <div className="row-actions" style={{ gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
      <label className="btn pri" style={{ cursor: 'pointer' }}>Upload New HR File<input type="file" accept=".xlsx" hidden onChange={e => { const f = e.target.files[0]; e.target.value = ''; if (f) upload(f, true) }} /></label>
      <button className="btn" onClick={() => setEd({ isNew: true, code: '', name: '', grade_raw: '', position: '', function: '', manager_code: '', emp_type: 'FTE', kind: '', unit: '', note: '' })}>Add Missing Employee</button>
      <button className="btn" onClick={() => download('/api/chro/asis/export', 'As Is.xlsx').catch(e => notify(e.message, true))}>Export As Is (Excel)</button>
      <button className="btn" onClick={reset}>Use Database (rebuild)</button></div>}
    {up && <div className="ch-card" style={{ marginBottom: 10, borderColor: 'var(--amber)' }}>
      <b>{up.file.name}</b>: {fmt(up.rep.rows)} employees. {fmt(up.rep.new_vs_current_as_is)} not in the current As Is, {fmt(up.rep.dropped_vs_current_as_is)} of the current As Is not in the file; {fmt(up.rep.not_in_portal)} not in the portal.
      <div className="row-actions" style={{ marginTop: 8, gap: 8 }}><button className="btn pri" onClick={() => upload(up.file, false)}>Replace the As Is</button><button className="btn" onClick={() => setUp(null)}>Cancel</button></div></div>}
    {ed && <div className="ch-card" style={{ marginBottom: 10 }}><h3>{ed.isNew ? 'Add a missing employee' : `Correct ${ed.name}`}</h3>
      <div className="ch-form">
        <label className="fld"><span className="fl">Employee code</span><input className="inp" value={ed.code} disabled={!ed.isNew} onChange={e => setEd({ ...ed, code: e.target.value })} placeholder="A portal code fills the rest" /></label>
        <label className="fld"><span className="fl">Name</span><input className="inp" value={ed.name} onChange={e => setEd({ ...ed, name: e.target.value })} /></label>
        <label className="fld"><span className="fl">Grade (as in the HR file)</span><input className="inp" value={ed.grade_raw} onChange={e => setEd({ ...ed, grade_raw: e.target.value })} placeholder="e.g. 068-SM I" /></label>
        <label className="fld"><span className="fl">Position</span><input className="inp" value={ed.position} onChange={e => setEd({ ...ed, position: e.target.value })} /></label>
        <label className="fld"><span className="fl">Function</span><input className="inp" list="ch-fns" value={ed.function} onChange={e => setEd({ ...ed, function: e.target.value })} /></label>
        <label className="fld"><span className="fl">Manager code (N-1)</span><input className="inp" value={ed.manager_code} onChange={e => setEd({ ...ed, manager_code: e.target.value })} /></label>
        <label className="fld"><span className="fl">Type</span><select className="inp" value={ed.kind || ed.emp_type} onChange={e => { const v = e.target.value; setEd({ ...ed, emp_type: v === 'FTC' || v === 'dw' ? 'FTC' : 'FTE', kind: v === 'dc' || v === 'dw' ? v : '' }) }}>
          <option value="FTE">FTE</option><option value="dc">{L('dash.dc')}</option><option value="FTC">FTC</option><option value="dw">{L('dash.dw')}</option></select></label>
        <label className="fld"><span className="fl">Unit</span><input className="inp" value={ed.unit} onChange={e => setEd({ ...ed, unit: e.target.value })} /></label>
        <label className="fld" style={{ gridColumn: 'span 3' }}><span className="fl">Note</span><input className="inp" value={ed.note} onChange={e => setEd({ ...ed, note: e.target.value })} placeholder="Why it was corrected" /></label>
      </div>
      <datalist id="ch-fns">{(d?.functions || []).map(f => <option key={f} value={f} />)}</datalist>
      <div className="row-actions" style={{ marginTop: 10, justifyContent: 'space-between' }}>
        <span>{!ed.isNew && <button className="linkbtn" onClick={() => remove(ed)}>Remove from As Is</button>}</span>
        <span style={{ display: 'flex', gap: 8 }}><button className="btn" onClick={() => setEd(null)}>Cancel</button><button className="btn pri" onClick={save}>Save</button></span></div></div>}
    <div className="kvline" style={{ marginBottom: 8 }}>
      <input className="inp" placeholder="Search by name, code or position" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} />
      <select className="inp" value={show} onChange={e => setShow(e.target.value)} style={{ maxWidth: 200 }}><option value="">Everyone</option><option value="edited">Corrected</option><option value="added">Added</option></select></div>
    <div className="tw scroll" style={{ maxHeight: 400 }}><table>
      <thead><tr><th>Employee</th><th>Grade</th><th>Function</th><th>Manager (As Is)</th><th>Source</th></tr></thead>
      <tbody>{(d?.rows || []).map(r => <tr key={r.code} className={canEdit ? 'click' : ''} onClick={canEdit ? () => setEd({ ...r }) : undefined} title={canEdit ? 'Correct' : ''}>
        <td><b>{r.name}</b><div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div></td><td>{r.grade}</td><td>{r.function}</td>
        <td>{r.manager_name || r.manager_code || '–'}</td><td>{r.source === 'file' ? 'HR file' : r.source === 'added' ? <span className="pill p-ok">Added</span> : <span className="pill p-warn" title={r.note}>Corrected</span>}</td></tr>)}
        {d && d.rows.length >= 400 && <tr><td colSpan={5} className="formula">The first 400 are shown. Search to narrow down.</td></tr>}</tbody></table></div>
  </Modal>
}

// ---------------------------------------------------------------- the page
export default function Chro({ notify, theme, user }) {
  const [fn, setFn] = useState('')
  const [d, setD] = useState(null)
  const [raw, setRaw] = useState({ asis: null, tobe: null })
  const [ver, setVer] = useState(0)
  const [list, setList] = useState(null)       // the change list open
  const [focus, setFocus] = useState(null)     // the person shown in the organogram
  const [side, setSide] = useState('tobe')     // which organogram: As Is or To Be
  const [asIs, setAsIs] = useState(false)
  const [plist, setPlist] = useState(null)
  const [busy, setBusy] = useState(false)
  const [openDep, setOpenDep] = useState({})
  const [vacOpen, setVacOpen] = useState(false)
  const [vacs, setVacs] = useState([])           // vacant positions, shown as boxes on the To Be organogram
  const [showTbh, setShowTbh] = useState(true)
  const [vacJd, setVacJd] = useState(null)
  const [fw, setFw] = useState(null)   // the benchmark framework (View Benchmark)
  const openFw = () => api('/api/bm/framework').then(setFw).catch(e => notify(e.message, true))
  const canBm = !!(user && user.can_hr_bm)
  const [showMax, setShowMax] = useState(false)   // the max grade on the To Be organogram (logins given the benchmark)
  const [bench, setBench] = useState(null)
  useEffect(() => { if (canBm && showMax && !bench) api('/api/chro/bench').then(setBench).catch(e => notify(e.message, true)) }, [showMax, ver])
  useEffect(() => { setD(null); api('/api/chro/summary?fn=' + encodeURIComponent(fn)).then(setD).catch(e => notify(e.message, true)) }, [fn, ver])
  useEffect(() => { api('/api/chro/vacancies').then(setVacs).catch(() => setVacs([])) }, [ver])
  useEffect(() => { Promise.all([api('/api/chro/org?side=asis'), api('/api/chro/org?side=tobe')]).then(([a, b]) => setRaw({ asis: a, tobe: b })).catch(e => notify(e.message, true)) }, [ver])
  const orgOf = data => {
    if (!data) return null
    const i = fn ? data.functions.indexOf(fn) : -1
    const scoped = i >= 0 ? scopeData(data, [data.function_ids[i]]) : data
    return scoped.people.length ? buildOrg(scoped, true) : null
  }
  const oa = useMemo(() => orgOf(raw.asis), [raw.asis, fn])
  const ob = useMemo(() => orgOf(raw.tobe), [raw.tobe, fn])
  const changed = () => setVer(v => v + 1)
  const pdf = async () => { setBusy(true); try { await download('/api/chro/pdf?fn=' + encodeURIComponent(fn), 'HR Dashboard.pdf') } catch (e) { notify(e.message, true) } finally { setBusy(false) } }
  const pick = r => { setList(null); if (r.code) setFocus(r.code) }
  const a = d?.asis, b = d?.tobe, cnt = d?.counts || {}, m = d?.meta || {}, k = d?.cards
  const o = side === 'asis' ? oa : ob
  // the person in the chart, or (when they are not on this side) their manager upwards
  let fp = o && focus ? o.byId.get(focus) : null
  if (o && focus && !fp) {
    const rows = new Map([...(raw.asis?.people || []), ...(raw.tobe?.people || [])].map(r => [r[0], r]))
    let c = rows.get(focus)?.[4], n = 0
    while (c && !o.byId.get(c) && n++ < 30) c = rows.get(c)?.[4]
    fp = c ? o.byId.get(c) : null
  }
  const sel = fp || (o && o.ROOT)
  const card = (key, title, big, sub, tone, onClick) => <button type="button" className={'hr-k ' + tone} onClick={onClick} disabled={!onClick}>
    <span className="hr-kt">{title}</span><b>{big}</b><small>{sub}</small></button>
  const red = (x, y) => Math.max(0, (x || 0) - (y || 0))
  const fnList = d?.functions || []
  const vacShown = useMemo(() => vacs.filter(v => !fn || v.function === fn), [vacs, fn])
  const vacMap = useMemo(() => side === 'tobe' && showTbh && ob ? vacMapOf(vacShown, ob, ob.ROOT) : null, [vacShown, ob, side, showTbh])
  const sideSeg = <span className="seg" role="group" aria-label="As Is or To Be"><button type="button" aria-pressed={side === 'asis'} onClick={() => setSide('asis')}>As Is</button><button type="button" aria-pressed={side === 'tobe'} onClick={() => setSide('tobe')}>To Be</button></span>
  const vacTotal = (d?.changes?.tbh || []).reduce((s_, v) => s_ + (v.count || 0), 0)
  const orgBtns = <>
    {d && vacTotal > 0 && side === 'tobe' && <button type="button" className={'btn tbh-btn' + (showTbh ? ' on' : '')} aria-pressed={showTbh} onClick={() => setShowTbh(x => !x)} title="Show the vacant / to be hired positions as boxes on the To Be organogram"><span className="vac-key" />{showTbh ? 'Hide' : 'Show'} To Be Hired</button>}
    {d && vacTotal > 0 && <button type="button" className="btn" onClick={() => setVacOpen(true)} title={`${L("vac.repl")} and ${L("vac.new")} positions to be hired: the list`}>Vacant Positions ({fmt(vacTotal) === '-' ? 0 : fmt(vacTotal)})</button>}
    {canBm && side === 'tobe' && <button type="button" className={'btn bm-btn' + (showMax ? ' on' : '')} aria-pressed={showMax} onClick={() => setShowMax(x => !x)} title="Colour each card by its grade against the max grade of its level"><span className="bm-key" />Show Max Grade</button>}</>
  const strip = o && sel ? <LayerStrip o={o} p={sel} onPick={x => setFocus(x.id)} onList={(t, ps) => setPlist({ title: t, people: ps, org: o })} /> : null
  const one = !!(d?.scoped && fnList.length === 1)
  const uploadHr = async file => {   // the comparison file, for this dashboard only (administrators)
    const send = dry => { const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false'); return api('/api/chro/asis/upload', { method: 'POST', form: fd }) }
    try {
      const rep = await send(true)
      if (!window.confirm(`${file.name}: ${fmt(rep.rows)} employees (${fmt(rep.not_in_portal)} not in the portal, ${fmt(rep.in_portal_not_in_file)} in the portal not in the file).\n\nUse it as the As Is of the HR Dashboard? Corrections made in As Is Data are replaced. Nothing else in the portal changes.`)) return
      const r = await send(false); notify(`HR Dashboard now compares against ${file.name} (${fmt(r.rows)} employees).`); changed()
    } catch (e) { notify(e.message, true) }
  }
  const useDb = async () => {
    if (!window.confirm('Stop using the uploaded HR file and compare against the database (the HR master file imported in Admin)? Corrections made in As Is Data are lost.')) return
    try { const r = await api('/api/chro/asis/reset', { method: 'POST' }); notify(`HR Dashboard compares against the database again (${fmt(r.rows)} employees).`); changed() } catch (e) { notify(e.message, true) }
  }
  return <section className="view on ch-page chv hr-page">
    <div className="hr-top">
      <label className="hr-fn"><span>Function</span>
        <select className="inp" value={fn || (one ? fnList[0] : '')} onChange={e => { setFn(e.target.value); setFocus(null) }}>
          {!one && <option value="">{d?.scoped ? 'All my functions' : L('dash.title') + ' · all functions'}</option>}{fnList.map(f => <option key={f} value={f}>{f}</option>)}</select></label>
      <div className="hr-title"><h1>HR Dashboard</h1><span>Restructure · As Is ({m.source === 'upload' ? `uploaded HR file: ${m.file || 'HR file'}${m.loaded_at ? ', ' + m.loaded_at : ''}` : 'database: HR master file imported in Admin'}) → To Be (the portal today)</span></div>
      <div className="ch-tools">
        {d?.can_edit && <label className="btn" style={{ cursor: 'pointer' }} title="Compare against an HR master file uploaded only for this dashboard. Without one, the database is used.">Upload HR Master File<input type="file" accept=".xlsx" hidden onChange={e => { const f = e.target.files[0]; e.target.value = ''; if (f) uploadHr(f) }} /></label>}
        {d?.can_edit && m.source === 'upload' && <button className="btn" onClick={useDb} title="Stop using the uploaded file: compare against the database again">Use Database</button>}
        {user && user.can_bm_view && <button type="button" className="btn bm-btn" onClick={openFw} title="The grade benchmark framework: levels and max grades">View Benchmark</button>}
        <button className="btn" onClick={() => setAsIs(true)}>As Is Data</button>
        <button className="btn pri" disabled={busy || !d} onClick={pdf}>{busy ? 'Preparing…' : 'Export Report (PDF)'}</button></div>
    </div>
    {!d ? <div className="loading">Loading…</div> : <>
      <div className="hr-cards">
        {card('layers', 'Layers Reduction', red(k.layers.asis, k.layers.tobe), `L${k.layers.asis} → L${k.layers.tobe} deepest layer`, 't1', cnt.layer ? () => setList({ k: 'layer', title: 'Layer changes' }) : null)}
        {card('span', 'Span Reduction', red(k.span.narrow_asis, k.span.narrow_tobe), `Narrow spans (1–2) ${fmt(k.span.narrow_asis)} → ${fmt(k.span.narrow_tobe)} · avg ${n1(k.span.asis)} → ${n1(k.span.tobe)}`, 't2', cnt.span ? () => setList({ k: 'span', title: 'Span of control changes' }) : null)}
        {card('fn', 'Functions Changed', fmt(k.functions.changed) === '-' ? 0 : fmt(k.functions.changed), 'Employees whose function changed', 't3', k.functions.changed ? () => setList({ k: 'function', title: 'Functions changed' }) : null)}
        {card('single', 'Single-Report Managers Reduced', red(k.single.asis, k.single.tobe), `One direct report who manages a team · ${fmt(k.single.asis)} → ${fmt(k.single.tobe)}`, 't4', cnt.single ? () => setList({ k: 'single', title: 'Single-report managers: one direct report who manages a team' }) : null)}
        {card('title', 'Functional Titles Changed', fmt(k.titles) === '-' ? 0 : fmt(k.titles), 'Position (designation) changed', 't7', k.titles ? () => setList({ k: 'title', title: 'Functional titles changed' }) : null)}
        {card('tag', 'Taggings Corrected', fmt(k.tagging) === '-' ? 0 : fmt(k.tagging), 'Line managers changed', 't5', k.tagging ? () => setList({ k: 'line', title: 'Taggings corrected: line managers changed' }) : null)}
        {card('saved', 'Headcount Saved', fmt(k.saved) === '-' ? 0 : fmt(k.saved), `${fmt(k.saved_roles || 0) === '-' ? 0 : fmt(k.saved_roles)} employee roles · ${fmt(k.saved_vac || 0) === '-' ? 0 : fmt(k.saved_vac)} hiring removed`, 't6', k.saved ? () => setList({ k: 'saved_all', title: 'Headcount saved: employee roles and hiring removed' }) : null)}
      </div>
      <div className="ch-card hr-org">
        <div className="hr-orghead"><h3>Organogram</h3>
          {sideSeg}
          <div className="ch-leg">{side === 'tobe' ? <><span><i style={{ background: 'var(--amber-soft)', borderColor: 'var(--amber)' }} />Moved</span><span><i style={{ background: 'color-mix(in srgb,#2E8B57 12%,var(--surface))', borderColor: '#2E8B57' }} />Not in the As Is</span></>
            : <><span><i style={{ background: 'var(--amber-soft)', borderColor: 'var(--amber)' }} />Moves in the To Be</span><span><i style={{ background: 'var(--coral-soft)', borderColor: 'var(--coral)', borderStyle: 'dashed' }} />Headcount saved</span></>}
            {focus && <button className="linkbtn" onClick={() => setFocus(null)}>Back to the top</button>}</div>
          {orgBtns}</div>
        {strip}
        {!o ? <p className="formula">No one {fn ? 'in this function ' : ''}on this side.</p>
          : <div className="orgchart wide"><Classic simple root={o.ROOT} top={o.ROOT} focus={fp || null} onFocus={p => setFocus(p ? p.id : null)} org={o} theme={theme} largeTeam={40} onReroot={() => {}}
              onOpenList={x => setPlist({ title: `${x.n}: direct reports`, people: x.kids.filter(o.counted), org: o })} onSelect={p => setFocus(p.id)} tools={<>{sideSeg}{orgBtns}</>} strip={strip} vacancies={vacMap} onVacancy={v => setVacJd(v)} marks={side === 'tobe' && showMax && bench ? null : (side === 'asis' ? raw.asis : raw.tobe).marks} bench={side === 'tobe' && showMax ? bench : null} /></div>}
      </div>
      {d.benchmark && <div className="hr-bm" style={{ marginTop: 14 }}>
        {[['room', 'Below Benchmark', 'Below the max grade of their level (room to grow)', 'b1'], ['at', 'At Max Benchmark', 'At the max grade of their level', 'b2'], ['above', 'Above Benchmark', 'Above the max grade of their level', 'b3']].map(([x, t, sub, tone]) =>
          <button key={x} type="button" className={'hr-k ' + tone} disabled={!d.benchmark[x]} onClick={() => setList({ k: 'bm_' + x, title: t, rows: d.benchmark.lists[x] })}><span className="hr-kt">{t}</span><b>{fmt(d.benchmark[x]) === '-' ? 0 : fmt(d.benchmark[x])}</b><small>{sub} · To Be, permanent staff</small></button>)}
      </div>}
    </>}
    {fw && <BenchFramework settings={fw.settings} ladder={fw.ladder} onClose={() => setFw(null)} />}
    {vacJd && <Modal title={vacJd.position} sub={['Vacant / to be hired', L(vacJd.kind === 'replacement' ? 'vac.repl' : 'vac.new'), vacJd.emp_type, vacJd.grade, vacJd.unit].filter(Boolean).join(' · ')} onClose={() => setVacJd(null)}>
      <p className="formula" style={{ marginTop: 0 }}>Reports to {vacJd.parent_position ? `${vacJd.parent_position} (vacant)` : vacJd.manager_name || 'the function head'} · {fmt(vacJd.open)} open{vacJd.note ? ' · ' + vacJd.note : ''}</p>
      {vacJd.jd ? <div className="jd-text">{vacJd.jd}</div> : <p className="formula">No job description written yet.</p>}</Modal>}
    {vacOpen && d && <VacList tbh={d.changes.tbh || []} onClose={() => setVacOpen(false)} />}
    {list && d && <ChangeList k={list.k} title={list.title} rows={list.rows || d.changes[list.k] || []} onPerson={pick} onClose={() => setList(null)} />}
    {asIs && <AsIsData notify={notify} canEdit={d?.can_edit} onChanged={changed} onClose={() => setAsIs(false)} />}
    {plist && <PeopleModal title={plist.title} people={plist.people} F={plist.org.F} heads={plist.org.headIds} initial="people" onPerson={x => { setPlist(null); setFocus(x.id) }} onClose={() => setPlist(null)} />}
  </section>
}

// the layers of the person's reporting line, across the top of the organogram: one coloured cell per layer with the
// person on it (or how many people sit on it below them); the bar under each shows how dense that layer is overall
const LNAME = { 1: 'EXCO', 2: 'Function', 3: 'Department', 4: 'Unit', 5: 'Team Lead', 6: 'Teams', 7: 'FTCs' }
function LayerStrip({ o, p, onPick, onList }) {
  const chain = []; let x = p; while (x) { chain.unshift(x); x = x.m >= 0 ? o.P[x.m] : null }
  const at = {}; chain.forEach(c => { if (c.ly > 0 && !at[c.ly]) at[c.ly] = c })
  const below = {}; const st = [...p.kids]
  while (st.length) { const k = st.pop(); if (o.counted(k) && k.ly > 0) (below[k.ly] = below[k.ly] || []).push(k); st.push(...k.kids) }
  const tot = {}; o.C.forEach(c => { if (c.ly > 0) tot[c.ly] = (tot[c.ly] || 0) + 1 })
  const last = Math.max(p.ly || 1, ...Object.keys(below).map(Number), ...Object.keys(tot).map(Number))
  const mx = Math.max(1, ...Object.values(tot))
  const ls = []; for (let l = 1; l <= last; l++) ls.push(l)
  return <div className="hr-strip">{ls.map(l => {
    const c = at[l], un = l > (p.ly || 0), bl = below[l], h = tot[l] ? 0.12 + 0.78 * tot[l] / mx : 0
    return <div key={l} className={'hr-sc' + (l === p.ly ? ' on' : '') + (h > 0.6 ? ' dk' : '')} style={{ '--h': h }} title={`${fmt(tot[l] || 0)} people on Layer ${l}`}>
      <div className="hr-sh"><b>L{l}</b><span>{LNAME[l] || 'Layer ' + l}</span></div>
      <div className="hr-sv">{!un ? (c ? (c === p ? <b>{c.n}</b> : <button type="button" onClick={() => onPick(c)}>{c.n}</button>) : <b>–</b>)
        : bl ? <button type="button" onClick={() => onList(`${p.n}'s team: Layer ${l}`, bl)}>{fmt(bl.length)} {bl.length === 1 ? 'person' : 'people'}</button> : <b>–</b>}</div>
      <div className="hr-den">{fmt(tot[l] || 0)} on this layer</div>
    </div>
  })}</div>
}
