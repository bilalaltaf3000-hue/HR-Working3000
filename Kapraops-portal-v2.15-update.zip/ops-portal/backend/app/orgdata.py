"""Organisation data shared by the dashboard API and the exports."""
from typing import Optional, Set

from sqlalchemy.orm import Session
from .logic import hide_resigned, shown_grade

from . import models
from .security import get_setting

FIELDS = ["code", "name", "grade", "f", "manager", "position", "fte", "gender", "rank", "external", "exclude", "added", "context",
          "region", "service_type", "resigned", "unit", "layer", "dc", "dw", "note"]


def org_rows(db: Session, allowed: Optional[Set[int]], units=None):
    """units: {function id: {unit names}} to limit those functions to some units (people outside them, such as
    the function head, are shown as context only). Resigned employees are left out when the admin hides them."""
    from .security import in_units
    fns = db.query(models.Function).order_by(models.Function.name).all()
    fidx = {f.id: i for i, f in enumerate(fns)}
    emps = db.query(models.Employee).all()
    if hide_resigned():
        emps = [e for e in emps if not e.resigned]
    by = {e.code: e for e in emps}
    root = get_setting(db, "root_code")
    keep = {}
    for e in emps:
        if (allowed is None or e.function_id in allowed) and in_units(e, units):
            keep[e.code] = 0
    if allowed is not None or units:
        # add reporting line upwards as context so the chart stays connected to the top
        for code in list(keep):
            x = by[code]
            seen = 0
            while x.manager_code and x.manager_code in by and seen < 50:
                x = by[x.manager_code]
                seen += 1
                if x.code not in keep:
                    keep[x.code] = 1
                if x.code == root:
                    break
        if root in by and root not in keep and keep:
            keep[root] = 1
    rows = []
    from .benchmark import level_layers
    lays = level_layers(db)
    if root:
        lays[root] = 1
    for code, ctx in keep.items():
        e = by[code]
        rows.append([e.code, e.name, shown_grade(e), fidx.get(e.function_id, -1), e.manager_code or "", e.position or "",
                     1 if e.emp_type == "FTE" else 0, e.gender or "", e.grade_rank if e.grade_rank is not None else -1,
                     1 if e.external else 0, 1 if e.exclude else 0, 1 if e.source == "added" else 0, ctx,
                     e.region or "", e.service_role or "", 1 if e.resigned else 0, e.unit_name or "", lays.get(code), 1 if e.is_dc else 0, 1 if e.is_dw else 0, e.org_note or ""])
    return {"functions": [f.name for f in fns], "function_ids": [f.id for f in fns], "function_types": [f.org_type or "" for f in fns], "fields": FIELDS, "people": rows,
            "root_code": root, "group_label": get_setting(db, "group_label") or "COSO", "import": {"at": (get_setting(db, "last_import") or {}).get("at")}, "scoped": allowed is not None, "unit_scoped": bool(units)}
