# Updating the VM to version 2.15: Work Summaries

Version 2.15 adds **Work Summaries**: a small box button on organogram cards opens a summary of the employee's recorded work, written by the bank's on-premise AI (Qwen on vLLM, as for Role Overlap).

- **2.15 contains everything in 2.14** (Grade Benchmark, Layer 1, the Role Overlap changes). If 2.14 is not installed yet, install this zip instead and read `UPDATE_TO_2.14_VM.md` for what 2.14 brings.
- **Only the portal code changes.** No pip install; vLLM is not touched. New tables and columns are added automatically at start.

---

## What is new

- **The box button** on organogram cards (dashboard and the Organogram page), only for employees with recorded activities, and only for logins with the new **Work Summary** tick (Admin → Users → Edit access; administrators always). The "No team" tag is removed from the organogram.
- **The pop-up:**
  - **Summary of work:** two or three sentences from the AI covering the volume-based work (with the volumes) and the non-volume-based work;
  - four figures from the portal's own data: activities, volume-based, non-volume-based, items a day;
  - **Volume-based work** (each with its volume and frequency) and **Non-volume-based work**, as short phrases;
  - **View all activities** (the full list) and, for the admin, **Write now** for that one person.
  - With fewer than 2 activities there is no written summary; the work is listed.
- **Written in advance:** **Admin → AI Server → Work Summaries** shows how many are up to date, changed since, or not written, and runs **Write New and Changed** (or **Write All Again**) for one function or all, in the background. When an employee's activities change, their pop-up says so and the next run rewrites only them. Only one AI run (summaries or Role Overlap) goes at a time.
- **Grade benchmark follows HR's grid** (Shehzad Shafi's mail):
  - **The layer comes from the level, not from the reporting depth:** Level 1 COSO, Level 2 Division, Level 3 Department, Level 4 Unit, Level 5 Team Lead / Senior Manager / Manager, then **Teams**. A Department head reporting straight to Kamran Muggo is Layer 3.
  - **Teams** sit below Layer 5 and have no direct reports, FTC staff only. Permanent staff reporting to a Teams member are shown as an **Extra layer** (dashed amber card, "Extra layer" figure, list and Excel sheet). The old "max layers 5" setting is gone.
  - **Each level has a band** (lower / max grade), editable in Admin → Structure & Benchmark, filled with the grid: for example Division DGM II / GM I under 50 and GM I / GM II for 50 or more. The **max grade** still decides Opportunity to grow, At Max Grade and Above Max Grade; the band is shown in the lists, the hover text and the Excel.
  - **Layers everywhere follow the level** for tagged functions: the dashboard's Function-Wise Layer table, the Layers figure, the organogram and the reporting line, and the PDF / PowerPoint / Excel. A function marked Department starts at L3 (L2 shows "-"); L6 is Teams and L7 an extra layer below Teams. Untagged functions still count by reporting depth. The **Layers** count is the layers in use plus Layer 1 (a blank layer, such as L2 under a Department, is not counted), and each function in the table shows its tag (Division, Department or Unit) in front of its name.
  - **View Benchmark Framework** (button at the top of the Grade Benchmark section): the boss's grid presented as a pyramid of levels with both bands, and the bands drawn on the grade ladder; **Print / Save as PDF** for sharing.
  - **Size band by hand:** in Admin → Structure & Benchmark, each function's Band can stay **Auto** (from its permanent headcount) or be set to **Under 50** or **50 or more**.
  - **Who may change the benchmark:** the admin login can tick **Change Grade Benchmark** for another administrator (Admin → Users → Edit access; needs Administrator and Grade Benchmark). That administrator then sees Admin → Structure & Benchmark and can change function types, levels and bands.
  - Tags on cards: DIV, DEPT, UNIT, **TL** (Team Lead / SM / Manager) and **TEAMS**.
- **Layer panel** (new **Layers** button on the dashboard organogram, and always beside the reporting line chart that opens when you click a person):
  - the reporting line of the selected person layer by layer from the Group Head, **"–" where a layer is skipped** (for example no Division head above a Department);
  - the layers **below** the person with how many people sit on each, and how deep their part goes ("their part goes down to L6"), so the depth is known before opening anyone;
  - **Edit** switch at the top: when on, set the person's level (Division, Department, Unit, Team Lead / SM / Manager, Teams) and what their direct reports are; the chart and every count update at once.
  - Click a layer count ("32 people") for the list of those employees; the panel also shows in **Full Screen**.
  - A level set by hand carries down from that level: a Department head set to **Division** moves their Units up to Department, and so on.
  - Ticks in Admin → Users → Edit access: **Layer Panel** (sees it; administrators always) and **Edit in Layer Panel** (may use Edit; any administrator can give it).
- **Grade Benchmark view:** the button is **View Benchmark**; the ladder chart, the explanation boxes and the paragraph are removed; **L6 · Teams · No Direct Reports** and a light **L7 · FTCs only (if necessary)** row. The Layers count is the deepest layer again (a blank L2 still counts).
- **Role Overlap:** each activity's volume and frequency is now given to the AI, so it can see when the same task is done at very different volumes. Run the analysis again to use it.

---

## Install

### 1. Copy the zip to the VM

```
scp ops-portal-v2.15-update.zip YOUR_VM_USER@hblassist.domestic.hbl.com:/tmp/
```

### 2. Back up first (do not skip)

```
sudo systemctl stop ops-portal
STAMP=$(date +%Y%m%d_%H%M)
sudo mkdir -p /data/opt/ops-portal/backups
sudo python3 -c "import sqlite3,sys; s=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); d=sqlite3.connect(sys.argv[1]); s.backup(d); d.close(); s.close(); print('database backed up')" /data/opt/ops-portal/backups/portal_before_2.15_$STAMP.db
sudo tar -czf /data/opt/ops-portal/backups/code_before_2.15_$STAMP.tgz -C /data/opt/ops-portal --exclude backend/venv --exclude backend/data --exclude backups .
sudo python3 -c "import sqlite3,glob; f=sorted(glob.glob('/data/opt/ops-portal/backups/portal_before_2.15_*.db'))[-1]; c=sqlite3.connect(f); print(f); print(c.execute('pragma integrity_check').fetchone()[0], c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities')"
```

The last command prints `ok`, then the employee and activity counts. **Write the two numbers down.**

### 3. Install the new code

```
rm -rf /tmp/ops-update && python3 -m zipfile -e /tmp/ops-portal-v2.15-update.zip /tmp/ops-update
ls /tmp/ops-update/ops-portal/backend/app/empsum.py && echo "zip OK"
sudo rsync -a --exclude 'backend/data' --exclude 'backend/venv' --exclude 'backups' --exclude 'wheels' /tmp/ops-update/ops-portal/ /data/opt/ops-portal/
```

Without `rsync`:

```
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo cp -r /tmp/ops-update/ops-portal/backend/app /tmp/ops-update/ops-portal/backend/static /data/opt/ops-portal/backend/
sudo cp -r /tmp/ops-update/ops-portal/deploy /data/opt/ops-portal/
```

### 4. Owner and permissions

```
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 700 /data/opt/ops-portal/backend/data
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backend/data/secret.key
sudo chmod -R a+rX /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo chmod 755 /data/opt/ops-portal/backend/venv/bin/*
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
```

### 5. Start and check

```
sudo systemctl start ops-portal
sleep 8
sudo systemctl status ops-portal --no-pager | head -5
sudo journalctl -u ops-portal -n 30 --no-pager
sudo -u opsportal python3 -c "import sqlite3; c=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); print(c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities'); print('emp_summaries' in [r[0] for r in c.execute("select name from sqlite_master")], 'can_summary' in [r[1] for r in c.execute('pragma table_info(users)')])"
```

The status shows **active (running)**, the log has no `Traceback`, the counts match step 2, and the last line prints `True True`.

---

## In the browser (one time)

1. Sign in as admin, press **Ctrl+F5** once.
2. If 2.14 was not installed before, do its one-time browser steps too (`UPDATE_TO_2.14_VM.md`, "In the browser").
3. **Admin → AI Server → Work Summaries:** click **Write New and Changed**. It runs in the background; all of COSO can take a few hours, so start it after office hours. One function first is a good test (choose it in the Function list).
4. **Admin → Users → Edit access:** tick **Work Summary** for the logins that should see the summary button. Administrators see it already.
5. **Dashboard → Organogram:** the small box button on a card opens the summary. It shows only on employees with recorded activities.
6. **Admin → Users → Edit access:** tick **View Benchmark** for anyone who should see the framework (levels and max grades only, no one's grades). The button sits at the top right of the dashboard. The admin login has it already.
7. **Admin → Structure & Benchmark → Show the size as:** choose *The number* (under 50 / 50 or more) or *Words* (smaller / larger functions), then Save.
8. **Layer panel, Edit on:** if a person's function is not tagged yet, the panel now asks "Function is a" (Division / Department / Unit) first; after that their level can be set.
9. **Contract (DC) and Daily Wagers:** mark people in **Admin → Employees → Edit** (tick Contract or Daily Wagers), or many at once with the **DC** and **Daily Wager** columns in Data Transfer ("Yes" marks; a blank clears only when "apply structure" is ticked). Their cards appear after FTE once anyone is marked. Rename them, and set the order of the four types (FTE, Contract, FTC, Daily Wagers), in **Admin → Labels**.
10. **Admin → Structure & Benchmark:** choose whether Contract (DC) staff count in the permanent headcount (the under 50 / 50 or more size). Default: they count. Daily Wagers never count and are not benchmarked.
11. **Admin → Staff Segmentation:** choose the function (Credit Administration Division is preselected), type the rows, figures and "as of" date, then Save. A button with the table's title appears at the top of that function's dashboard for everyone who can see it.
13. **Vacant positions:** in **Admin → Vacant Positions** each position is now **Replacement** or **New position** (existing ones show as New position; edit them to change). They have different colours in the organogram (blue / amber). Rename the two in **Admin → Labels → Organogram**.
    - **An employee reporting to a vacant position:** in **Admin → Employees → Edit**, under *Reports to*, choose **Or a vacant position…**, or open the vacant position and add employees under *Employees Who Report to This Position*. They show under the vacant box (with To Be Hired on); meanwhile they count under the manager the position reports to. When the position is filled with an employee, they move to that employee.
15. **Vacant position list (main dashboard):** Show To Be Hired → *View List* now has two tabs, Replacement and New.
16. **Vacant positions in Data Transfer:** the export now has a **Vacant positions** sheet. Change a row to update a position, add a row with a blank *Vacancy ID* to add one, or write *Yes* in *Delete* to remove one; then import (Check first shows the counts). Importing the same file twice does not add the new positions twice.
14. **Export HTML** (organogram buttons, for logins with Export): saves the organogram on screen as one HTML file that opens in any browser, with the layer panel on the left, search, zoom and click to open teams. Vacant positions are included when To Be Hired is shown.
12. **HR Dashboard** (replaces the CHRO dashboard): any administrator gives it in **Admin → Users → Edit access → HR Dashboard**.
    - Function filter at the top; six cards: Layers Reduction, Span Reduction, Functions Changed (employees whose function changed), Single-Report Managers Reduced (as in Opportunities: one direct report who manages a team), Functional Titles Changed (position), Taggings Corrected (line managers changed), Headcount Saved = employees marked headcount saved + vacant positions whose hiring was removed (click any for the list).
    - **Benchmark on HR Dashboard** (a separate tick in Admin → Users, any admin can give it): adds Below / At Max / Above Benchmark cards (below the organogram) and a **Show Max Grade** switch on the To Be organogram. People added in the portal and resigned people are reflected on both sides, so only the restructure shows.
    - Organogram with an **As Is / To Be** switch and the layer strip on top (shaded green by how many people sit on each layer, also in full screen); **Vacant Positions** opens the list with two tabs, Replacement and New; **Export Report (PDF)**.
    - **What the As Is is compared from:** by default the **database**: each employee as in the HR master file imported in Admin (HR manager, function, grade, position); it follows a new import there and keeps the corrections made in As Is Data. An administrator can instead click **Upload HR Master File** (top of the dashboard) to compare against another HR file, for this dashboard only; **Use Database** goes back.
    - **Which functions a login sees:** Admin → Users → Edit access → under *HR Dashboard*, **HR Dashboard shows**: *The functions of their dashboard view* (default), *Selected functions only* (tick them) or *All functions*. They see only those functions in the cards, organogram, lists and PDF. Administrators always see all.
    - **As Is Data** corrects the As Is for this dashboard only. **Headcount saved:** Admin → Employees → Edit → Restructure.
    - **Organogram note:** Admin → Employees → Edit → *Organogram note*; shown as a small tab on top of the person's card.
    - **Hiring removed:** Admin → Vacant Positions → *Remove Hiring* (with a reason). The position stays on record, greyed out (organogram: *Show Hiring Removed*), and is no longer counted as to be hired.
    - Grades containing **SEC** (secretaries) are left out of the employee lists and counts automatically (shown under Excluded; tick them back in Admin → Employees if needed).
13. **Vacant positions:** in **Admin → Vacant Positions** each position is now **Replacement** or **New position** (existing ones show as New position; edit them to change). They have different colours in the organogram (blue / amber). Rename the two in **Admin → Labels → Organogram**.
    - **An employee reporting to a vacant position:** in **Admin → Employees → Edit**, under *Reports to*, choose **Or a vacant position…**, or open the vacant position and add employees under *Employees Who Report to This Position*. They show under the vacant box (with To Be Hired on); meanwhile they count under the manager the position reports to. When the position is filled with an employee, they move to that employee.
15. **Vacant positions in Data Transfer:** the export now has a **Vacant positions** sheet. Change a row to update a position, add a row with a blank *Vacancy ID* to add one, or write *Yes* in *Delete* to remove one; then import (Check first shows the counts). Importing the same file twice does not add the new positions twice.
14. **Export HTML** (organogram buttons, for logins with Export): saves the organogram on screen as one HTML file that opens in any browser, with the layer panel on the left, search, zoom and click to open teams. Vacant positions are included when To Be Hired is shown.
12. **CHRO Dashboard:** sign in as **admin**, open **Admin → Users → Edit access** for the CHRO's login and tick **CHRO Dashboard** (only the admin login can give it). It appears in the sidebar under Dashboard.
    - **As Is** starts as the HR master file as it was imported. Fix it from **CHRO Dashboard → As Is Data**: correct a person (click them), **Add Missing Employee**, or **Upload New HR File** (same columns as the HR master file; it shows what will change before replacing). **Export As Is (Excel)** gives the file to correct offline and upload again. None of this changes the rest of the portal.
    - **Headcount saved:** in **Admin → Employees → Edit**, tick **Headcount saved** (role removed in the restructure) with a reason and date, or use the **Headcount saved** column in Data Transfer. Those roles leave the To Be; their direct reports move up to their manager there only.
    - **Export Report (PDF)** gives the executive report for the whole organisation or the function chosen at the top.

---

## If something goes wrong

```
sudo systemctl stop ops-portal
STAMP=PUT_THE_STAMP_HERE
sudo tar -xzf /data/opt/ops-portal/backups/code_before_2.15_$STAMP.tgz -C /data/opt/ops-portal
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo systemctl start ops-portal
```

The database does not need restoring: the new columns are ignored by the older version.
