"""CHRO dashboard: the As Is organisation (the HR master file, which the admin can correct or replace) against the
To Be (the portal as it is now, after every change), with what changed between them.

As Is  = the chro_asis table. It starts as a copy of the HR master file as it was imported (each employee's HR
         manager and HR function), can be edited (add missing employees, fix a manager, function, grade) and can be
         replaced by uploading another HR file. It is used only by the CHRO dashboard.
To Be  = the employees in the portal today, without the resigned and without the roles marked "headcount saved"
         (their direct reports move up to the next manager). Positions to be hired are shown beside it.
Layers here are counted down the reporting line from the top person (L1), the same way for both sides, so the
two can be compared."""
import io
import re
from datetime import datetime
from typing import Dict, List, Optional

from openpyxl import load_workbook
from sqlalchemy.orm import Session

from . import models
from .importer import OPTIONAL, REGION_HEADERS, REQUIRED, _norm_header, clean_name, code_text, grade_label, grade_rank, is_outsourced, strip_prefix
from .logic import shown_grade
from .security import get_setting, set_setting

META = "chro_asis_meta"
BANDS = [("1–2", 1, 2), ("3–5", 3, 5), ("6–10", 6, 10), ("11–15", 11, 15), ("16+", 16, 10 ** 6)]


def _kind(e) -> str:
    return "dw" if getattr(e, "is_dw", False) else "dc" if getattr(e, "is_dc", False) else ""


def _tkey(emp_type: str, kind: str) -> str:
    return kind if kind in ("dc", "dw") else ("fte" if (emp_type or "FTE") == "FTE" else "ftc")


# ------------------------------------------------------------------ the As Is store
def meta(db) -> dict:
    return get_setting(db, META) or {}


def seed_from_hr(db: Session, by: str = "") -> int:
    """(Re)build the As Is from the HR master file as imported: HR manager and HR function of each employee."""
    db.query(models.AsIsEmp).delete()
    fns = {f.id: f.name for f in db.query(models.Function)}
    n = 0
    for e in db.query(models.Employee):
        if e.source == "added":
            continue   # not in the HR file
        hm = e.hr_manager_code
        mgr = e.manager_code if hm == "?" else hm
        hf = e.hr_function_id
        fn = fns.get(hf) if hf not in (None, -1) else None
        db.add(models.AsIsEmp(code=e.code, name=e.name, grade=e.grade or "", grade_raw=e.grade_raw or "", grade_rank=e.grade_rank if e.grade_rank is not None else -1,
                              position=e.position or "", function=fn or fns.get(e.function_id, ""), manager_code=mgr or None, emp_type=e.emp_type or "FTE",
                              kind=_kind(e), gender=e.gender or "", unit=e.unit_name or "", source="file"))
        n += 1
    imp = get_setting(db, "last_import") or {}
    set_setting(db, META, {"source": "hr", "file": imp.get("file") or "HR master file (as imported)", "at": imp.get("at") or "",
                           "loaded_at": datetime.now().strftime("%Y-%m-%d %H:%M"), "by": by, "rows": n, "edits": 0})
    db.commit()
    return n


def ensure(db: Session):
    if not db.query(models.AsIsEmp.code).first():
        seed_from_hr(db, "portal")


def read_hr_file(content: bytes) -> Dict[str, dict]:
    """The employees of an HR master file (same columns as the Admin import)."""
    wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    ws = wb.worksheets[0]
    rows = ws.iter_rows(values_only=True)
    header = [_norm_header(h) for h in next(rows, [])]
    idx = {k: header.index(n) for k, n in {**REQUIRED, **OPTIONAL}.items() if n in header}
    missing = [REQUIRED[k] for k in REQUIRED if k not in idx]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing) + ". Use the HR master file layout (or the As Is export).")
    extra = {k: header.index(k) for k in ("unit", "type", "contract / daily wager") if k in header}
    recs = {}
    for r in rows:
        code = code_text(r[idx["code"]]) if len(r) > idx["code"] else ""
        if not code or code in recs:
            continue
        g = str(r[idx["grade"]] or "").strip()
        typ = str(r[extra["type"]] or "").strip().upper() if "type" in extra else ""
        kd = str(r[extra["contract / daily wager"]] or "").strip().lower() if "contract / daily wager" in extra else ""
        recs[code] = {"code": code, "name": clean_name(r[idx["name"]]) or code, "grade_raw": g, "grade": grade_label(g), "grade_rank": grade_rank(g),
                      "emp_type": "FTC" if (typ == "FTC" or is_outsourced(g)) else "FTE",
                      "kind": "dc" if kd.startswith("contract") or kd == "dc" else "dw" if kd.startswith("daily") else "",
                      "function": str(r[idx["function"]] or "Unassigned").strip() or "Unassigned", "manager_code": code_text(r[idx["manager"]]) or None,
                      "gender": str(r[idx["gender"]] or "").strip().lower()[:1] if "gender" in idx else "",
                      "position": strip_prefix(r[idx["position"]]) if "position" in idx else "",
                      "unit": " ".join(str(r[extra["unit"]] or "").split())[:200] if "unit" in extra else ""}
    for rec in recs.values():
        if rec["manager_code"] == rec["code"]:
            rec["manager_code"] = None
    if not recs:
        raise ValueError("No employee rows found in the first sheet.")
    return recs


def replace_from_file(db: Session, content: bytes, filename: str, by: str, dry_run: bool) -> dict:
    recs = read_hr_file(content)
    portal = {c for (c,) in db.query(models.Employee.code)}
    cur = {c for (c,) in db.query(models.AsIsEmp.code)}
    rep = {"rows": len(recs), "not_in_portal": len([c for c in recs if c not in portal]), "in_portal_not_in_file": len([c for c in portal if c not in recs]),
           "new_vs_current_as_is": len([c for c in recs if c not in cur]), "dropped_vs_current_as_is": len([c for c in cur if c not in recs])}
    if dry_run:
        return rep
    db.query(models.AsIsEmp).delete()
    for rec in recs.values():
        db.add(models.AsIsEmp(source="file", **rec))
    set_setting(db, META, {"source": "upload", "file": filename or "HR file", "at": "", "loaded_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                           "by": by, "rows": len(recs), "edits": 0})
    db.commit()
    return rep


def bump_edits(db: Session):
    m = dict(meta(db))
    m["edits"] = int(m.get("edits") or 0) + 1
    set_setting(db, META, m)


# ------------------------------------------------------------------ the two organisations
def _asis(db) -> Dict[str, dict]:
    ensure(db)
    excluded = {c for (c,) in db.query(models.Employee.code).filter(models.Employee.exclude == True)}  # noqa: E712
    out = {}
    for a in db.query(models.AsIsEmp):
        if a.code in excluded:
            continue
        out[a.code] = {"code": a.code, "name": a.name, "grade": a.grade or "", "rank": a.grade_rank if a.grade_rank is not None else -1, "position": a.position or "",
                       "fn": a.function or "", "mgr": a.manager_code or "", "t": _tkey(a.emp_type, a.kind), "gender": (a.gender or "")[:1].lower(), "unit": a.unit or "",
                       "src": a.source or "file"}
    return out


def _tobe(db) -> (Dict[str, dict], Dict[str, dict]):
    """The To Be people, and the people left out of it (resigned, headcount saved) with why."""
    fns = {f.id: f.name for f in db.query(models.Function)}
    emps = {e.code: e for e in db.query(models.Employee)}
    out_of = {c: ("saved" if e.hc_saved else "resigned") for c, e in emps.items() if e.resigned or e.hc_saved}
    keep = {}
    for c, e in emps.items():
        if c in out_of or e.exclude:
            continue
        m, n = e.manager_code or "", 0
        while m in out_of and n < 40:   # their reports move up to the next manager
            m, n = (emps[m].manager_code or ""), n + 1
        keep[c] = {"code": c, "name": e.name, "grade": e.grade or "", "rank": e.grade_rank if e.grade_rank is not None else -1, "position": e.position or "",
                   "fn": fns.get(e.function_id, ""), "fid": e.function_id, "mgr": m, "t": _tkey(e.emp_type, _kind(e)), "gender": (e.gender or "")[:1].lower(),
                   "unit": e.unit_name or "", "added": e.source == "added"}
    gone = {c: {"why": w, "name": emps[c].name, "reason": emps[c].hc_reason or "", "date": (emps[c].hc_date if w == "saved" else emps[c].resigned_on) or ""}
            for c, w in out_of.items()}
    return keep, gone


def _shape(ps: Dict[str, dict], root: str):
    """Direct reports, depth (L1 = the top person) for one side."""
    kids: Dict[str, List[str]] = {}
    for c, p in ps.items():
        if p["mgr"] and p["mgr"] in ps and c != root:
            kids.setdefault(p["mgr"], []).append(c)
    depth = {}
    if root in ps:
        depth[root] = 1
        stack = [root]
        while stack:
            x = stack.pop()
            for k in kids.get(x, []):
                if k not in depth:
                    depth[k] = depth[x] + 1
                    stack.append(k)
    return kids, depth


def _metrics(ps, kids, depth, only=None) -> dict:
    """Headline figures for a set of people (only: the codes to count; managers by their own function)."""
    codes = [c for c in ps if only is None or c in only]
    mgrs = [c for c in codes if kids.get(c)]
    spans = [len(kids[c]) for c in mgrs]
    lay = {}
    for c in codes:
        if c in depth:
            lay[depth[c]] = lay.get(depth[c], 0) + 1
    typ = {k: 0 for k in ("fte", "dc", "ftc", "dw")}
    gen = {"m": 0, "f": 0, "": 0}
    for c in codes:
        typ[ps[c]["t"]] = typ.get(ps[c]["t"], 0) + 1
        g = ps[c]["gender"]
        gen[g if g in ("m", "f") else ""] += 1
    bands = {b[0]: sum(1 for s in spans if b[1] <= s <= b[2]) for b in BANDS}
    grades: Dict[str, list] = {}
    for c in codes:
        g = ps[c]["grade"] or "Not set"
        r = grades.setdefault(g, [ps[c]["rank"] if ps[c]["rank"] is not None else -1, 0])
        r[1] += 1
    return {"headcount": len(codes), "managers": len(mgrs), "avg_span": round(sum(spans) / len(mgrs), 1) if mgrs else 0,
            "layers": max(lay) if lay else 0, "narrow": sum(1 for s in spans if s <= 2), "wide": sum(1 for s in spans if s > 15),
            "by_layer": {str(k): v for k, v in sorted(lay.items())}, "types": typ, "gender": gen, "bands": bands,
            "not_connected": sum(1 for c in codes if c not in depth),
            "grades": [{"g": g, "rank": r, "n": n} for g, (r, n) in sorted(grades.items(), key=lambda x: (-x[1][0], x[0]))]}


def compare(db: Session, fn: Optional[str] = None) -> dict:
    root = get_setting(db, "root_code") or ""
    A = _asis(db)
    B, gone = _tobe(db)
    ka, da = _shape(A, root)
    kb, db_ = _shape(B, root)
    inf = (lambda p: p["fn"] == fn) if fn else (lambda p: True)
    onlyA = {c for c, p in A.items() if inf(p)}
    onlyB = {c for c, p in B.items() if inf(p)}
    nm = lambda c: (B.get(c) or A.get(c) or {}).get("name", "") if c else ""

    def row(c, **x):
        p = B.get(c) or A.get(c)
        return {"code": c, "name": p["name"], "grade": p["grade"], "position": p["position"], "function": p["fn"], **x}

    both = [c for c in A if c in B and (c in onlyA or c in onlyB)]
    ch = {"line": [], "function": [], "grade": [], "title": [], "span": [], "layer": [], "saved": [], "resigned": [], "added": [], "removed": [], "tbh": []}
    for c in sorted(both, key=lambda c: (B[c]["fn"], B[c]["name"])):
        a, b = A[c], B[c]
        if (a["mgr"] or "") != (b["mgr"] or "") and c != root:
            ch["line"].append(row(c, frm=nm(a["mgr"]) or "—", to=nm(b["mgr"]) or "—", frm_code=a["mgr"], to_code=b["mgr"]))
        if a["fn"] != b["fn"]:
            ch["function"].append(row(c, frm=a["fn"] or "—", to=b["fn"] or "—"))
        if (a["grade"] or "") != (b["grade"] or "") and a["grade"] and b["grade"] and b["grade"] != "-":
            ch["grade"].append(row(c, frm=a["grade"], to=b["grade"], up=(b["rank"] or 0) > (a["rank"] or 0)))
        if (a["position"] or "").strip().lower() != (b["position"] or "").strip().lower() and b["position"]:
            ch["title"].append(row(c, frm=a["position"] or "—", to=b["position"]))
        na, nb = len(ka.get(c, [])), len(kb.get(c, []))
        if na != nb:
            ch["span"].append(row(c, frm=na, to=nb))
        if c in da and c in db_ and da[c] != db_[c]:
            ch["layer"].append(row(c, frm=f"L{da[c]}", to=f"L{db_[c]}"))
    for c, g in sorted(gone.items(), key=lambda x: x[1]["name"]):
        if c in A and c in onlyA:
            ch["saved" if g["why"] == "saved" else "resigned"].append(row(c, reason=g["reason"], date=g["date"], reports=len(ka.get(c, []))))
        elif c not in A and g["why"] == "saved":
            emp = db.get(models.Employee, c)
            if emp and (not fn or B.get(c, {}).get("fn") == fn):
                ch["saved"].append({"code": c, "name": emp.name, "grade": emp.grade or "", "position": emp.position or "", "function": "", "reason": g["reason"], "date": g["date"], "reports": 0})
    portal = {c for (c,) in db.query(models.Employee.code)}
    for c in sorted(onlyB, key=lambda c: (B[c]["fn"], B[c]["name"])):
        if c not in A:
            ch["added"].append(row(c, to=nm(B[c]["mgr"]), why="Added in the portal" if B[c]["added"] else "In the HR data, not in the As Is"))
    for c in sorted(onlyA, key=lambda c: A[c]["name"]):
        if c not in portal:
            ch["removed"].append(row(c, frm=nm(A[c]["mgr"])))
    fnames = {f.id: f.name for f in db.query(models.Function)}
    for v in db.query(models.Vacancy):
        open_ = (v.count or 1) - min(v.filled or 0, v.count or 1)
        if open_ > 0 and (not fn or fnames.get(v.function_id) == fn):
            ch["tbh"].append({"code": "", "name": v.position or "Position", "grade": v.grade or "", "position": v.position or "", "function": fnames.get(v.function_id, ""),
                              "emp_type": v.emp_type, "count": open_, "to": nm(v.manager_code)})
    ma, mb = _metrics(A, ka, da, onlyA), _metrics(B, kb, db_, onlyB)
    tbh_n = sum(x["count"] for x in ch["tbh"])
    # by function
    names = sorted({p["fn"] for p in A.values()} | {p["fn"] for p in B.values()} - {""})
    if fn:
        names = [fn]
    byfn = []
    cnt = lambda key, n: sum(1 for x in ch[key] if x["function"] == n)
    for n in names:
        sa = {c for c, p in A.items() if p["fn"] == n}
        sb = {c for c, p in B.items() if p["fn"] == n}
        x, y = _metrics(A, ka, da, sa), _metrics(B, kb, db_, sb)
        if not (x["headcount"] or y["headcount"]):
            continue
        byfn.append({"function": n, "asis": {k: x[k] for k in ("headcount", "managers", "avg_span", "layers", "narrow")},
                     "tobe": {k: y[k] for k in ("headcount", "managers", "avg_span", "layers", "narrow")},
                     "saved": cnt("saved", n), "line": cnt("line", n), "moved": sum(1 for z in ch["function"] if z["to"] == n or z["frm"] == n),
                     "tbh": sum(z["count"] for z in ch["tbh"] if z["function"] == n)})
    return {"asis": ma, "tobe": mb, "tbh": tbh_n, "changes": ch, "counts": {k: (tbh_n if k == "tbh" else len(v)) for k, v in ch.items()},
            "by_function": byfn, "meta": meta(db), "functions": names if not fn else sorted({p["fn"] for p in A.values()} | {p["fn"] for p in B.values()} - {""}),
            "fn": fn or ""}


# ------------------------------------------------------------------ organogram data (the dashboard's /api/org layout)
def org_payload(db: Session, side: str) -> dict:
    root = get_setting(db, "root_code") or ""
    A = _asis(db)
    B, gone = _tobe(db)
    ps = A if side == "asis" else B
    other = B if side == "asis" else A
    kids, depth = _shape(ps, root)
    fn_rows = db.query(models.Function).order_by(models.Function.name).all()
    names = [f.name for f in fn_rows]
    ids = [f.id for f in fn_rows]
    types = [f.org_type or "" for f in fn_rows]
    for p in ps.values():   # As Is function names not (or no longer) in the portal
        if p["fn"] and p["fn"] not in names:
            names.append(p["fn"])
            ids.append(-1000 - len(names))
            types.append("")
    fidx = {n: i for i, n in enumerate(names)}
    nm = lambda c: (B.get(c) or A.get(c) or {}).get("name", "")
    marks = {}
    for c, p in ps.items():
        o = other.get(c)
        if side == "asis":
            if c in gone:
                marks[c] = {"c": "gone", "t": "Headcount saved" if gone[c]["why"] == "saved" else "Resigned"}
            elif not o:
                marks[c] = {"c": "gone", "t": "Not in the portal"}
            elif (o["mgr"] or "") != (p["mgr"] or "") and c != root:
                marks[c] = {"c": "mv", "t": "Moves to " + (nm(o["mgr"]) or "—")}
            elif o["fn"] != p["fn"]:
                marks[c] = {"c": "mv", "t": "Moves to " + o["fn"]}
        else:
            if not o:
                marks[c] = {"c": "new", "t": "Added" if p.get("added") else "Not in the As Is"}
            elif (o["mgr"] or "") != (p["mgr"] or "") and c != root:
                marks[c] = {"c": "mv", "t": "Was under " + (nm(o["mgr"]) or "—")}
            elif o["fn"] != p["fn"]:
                marks[c] = {"c": "mv", "t": "Was in " + (o["fn"] or "—")}
    rows = []
    hide_top = not get_setting(db, "show_top_grade")   # the top person's grade is hidden on the charts, as on the dashboard
    for c, p in ps.items():
        t = p["t"]
        g = "-" if hide_top and c == root else p["grade"]
        rows.append([c, p["name"], g, fidx.get(p["fn"], -1), p["mgr"] if p["mgr"] in ps else "", p["position"], 1 if t in ("fte", "dc") else 0,
                     p["gender"], p["rank"], 0, 0, 1 if p.get("added") else 0, 0, "", "", 0, p["unit"], depth.get(c), 1 if t == "dc" else 0, 1 if t == "dw" else 0])
    return {"functions": names, "function_ids": ids, "function_types": types,
            "fields": ["code", "name", "grade", "f", "manager", "position", "fte", "gender", "rank", "external", "exclude", "added", "context",
                       "region", "service_type", "resigned", "unit", "layer", "dc", "dw"],
            "people": rows, "root_code": root, "group_label": get_setting(db, "group_label") or "COSO", "import": {}, "scoped": False, "unit_scoped": False,
            "marks": marks}


def asis_export(db: Session) -> bytes:
    """The As Is in the HR master file layout, to correct in Excel and upload again."""
    from openpyxl import Workbook
    ensure(db)
    wb = Workbook()
    ws = wb.active
    ws.title = "As Is"
    ws.append(["N Employee No", "N Employee Name", "N Employee Grade", "N Function", "N-1 Manager Number", "N Position Name", "N Gender", "Unit", "Type", "Contract / Daily Wager", "Source", "Note"])
    for a in db.query(models.AsIsEmp).order_by(models.AsIsEmp.function, models.AsIsEmp.name):
        ws.append([a.code, a.name, a.grade_raw or a.grade, a.function, a.manager_code or "", a.position, {"m": "Male", "f": "Female"}.get((a.gender or "")[:1], ""),
                   a.unit, a.emp_type, {"dc": "Contract", "dw": "Daily Wager"}.get(a.kind or "", ""), a.source, a.note])
    for col, w in zip("ABCDEFGHIJKL", (14, 30, 16, 32, 16, 34, 9, 24, 7, 18, 9, 30)):
        ws.column_dimensions[col].width = w
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
