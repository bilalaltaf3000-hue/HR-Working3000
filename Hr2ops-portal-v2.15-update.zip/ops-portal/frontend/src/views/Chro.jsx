import React, { useEffect, useMemo, useState } from 'react'
import { api, download } from '../api.js'
import { buildOrg, fmt, scopeData } from '../org.js'
import { L } from '../prefs.js'
import { Modal, PeopleModal } from '../ui.jsx'
import { Classic } from './Organogram.jsx'
import { Bridge, Dumbbell, Grouped, Legend, Mix100, PairH, Pyramid, Segments, StackH } from './ChroCharts.jsx'

// The CHRO dashboard: the As Is organisation (the HR master file, which the admin can correct or replace) against
// the To Be (the portal today), with every change between them, both organograms side by side, and a PDF report.
const n1 = v => v === null || v === undefined ? '–' : Number(v).toLocaleString('en-US', { maximumFractionDigits: 1 })
const CHANGES = [
  ['line', 'Reporting line changes', 'mv'], ['function', 'Function changes', 'mv'], ['span', 'Span of control changes', 'mv'],
  ['layer', 'Layer changes', 'mv'], ['grade', 'Grade changes', 'mv'], ['title', 'Title changes', 'mv'],
  ['saved', 'Headcount saved', 'gone'], ['resigned', 'Resigned', 'gone'], ['removed', 'In As Is, not in the portal', 'gone'],
  ['added', 'Added (not in the As Is)', 'new'], ['tbh', 'Positions to be hired', 'new'],
]
const COLS = {   // the columns of each change list: [heading, field]
  line: [['As Is manager', 'frm'], ['To Be manager', 'to']], function: [['From', 'frm'], ['To', 'to']], span: [['As Is direct reports', 'frm'], ['To Be', 'to']],
  layer: [['As Is', 'frm'], ['To Be', 'to']], grade: [['From', 'frm'], ['To', 'to']], title: [['As Is title', 'frm'], ['To Be title', 'to']],
  saved: [['Reason', 'reason'], ['Date', 'date'], ['Direct reports (As Is)', 'reports']], resigned: [['Resigned on', 'date']],
  removed: [['As Is manager', 'frm']], added: [['Reports to', 'to'], ['Why', 'why']], tbh: [['Type', 'emp_type'], ['Open', 'count'], ['Reports to', 'to']],
}

function Delta({ a, b, low, digits }) {
  if (a === undefined || b === undefined || a === b) return <em className="ch-d">no change</em>
  const d = Math.round((b - a) * 10) / 10
  const good = low ? d < 0 : d > 0
  return <em className={'ch-d ' + (good ? 'good' : 'bad')}>{(d > 0 ? '+' : '') + (digits ? d.toFixed(1) : fmt(d) === '-' ? d : d.toLocaleString('en-US'))}</em>
}

function Kpi({ label, a, b, low, digits, sub }) {
  return <div className="ch-k"><span>{label}</span>
    <div className="v">{a !== undefined && <s>{n1(a)}</s>}<b>{n1(b)}</b>{a !== undefined && <Delta a={a} b={b} low={low} digits={digits} />}</div>{sub && <small>{sub}</small>}</div>
}

function ChangeList({ k, title, rows, onPerson, onClose }) {
  const [q, setQ] = useState('')
  const ql = q.trim().toLowerCase()
  const list = rows.filter(r => !ql || (r.name + ' ' + r.code + ' ' + r.function + ' ' + (r.frm || '') + ' ' + (r.to || '')).toLowerCase().includes(ql))
  const cols = COLS[k] || []
  return <Modal wide title={title} sub={`${fmt(rows.length)} ${k === 'tbh' ? 'positions' : 'employees'}`} onClose={onClose}>
    <div className="kvline" style={{ marginBottom: 8 }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} /></div>
    <div className="tw scroll" style={{ maxHeight: 480 }}><table>
      <thead><tr><th>{k === 'tbh' ? 'Position' : 'Employee'}</th><th>Grade</th><th>Function</th>{cols.map(c => <th key={c[1]}>{c[0]}</th>)}</tr></thead>
      <tbody>{list.slice(0, 1000).map((r, i) => <tr key={r.code || i} className={r.code && onPerson ? 'click' : ''} onClick={r.code && onPerson ? () => onPerson(r) : undefined} title={r.code ? 'Show in the organograms' : ''}>
        <td><b>{r.name}</b>{r.code && <div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div>}</td><td>{r.grade}</td><td>{r.function}</td>
        {cols.map(c => <td key={c[1]} className={c[1] === 'to' && k === 'grade' ? (r.up ? 'ch-up' : 'ch-dn') : ''}>{String(r[c[1]] ?? '')}</td>)}</tr>)}
        {!list.length && <tr><td colSpan={3 + cols.length} className="formula">None.</td></tr>}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={() => {
      const csv = [[k === 'tbh' ? 'Position' : 'Employee', 'Code', 'Grade', 'Function', ...cols.map(c => c[0])], ...list.map(r => [r.name, r.code, r.grade, r.function, ...cols.map(c => r[c[1]] ?? '')])]
        .map(x => x.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n')
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' })); a.download = title + '.csv'; a.click()
    }}>Download List</button></div>
  </Modal>
}

// ---------------------------------------------------------------- the As Is data: corrections and a new HR file
function AsIsData({ notify, canEdit, onChanged, onClose }) {
  const [d, setD] = useState(null)
  const [q, setQ] = useState('')
  const [show, setShow] = useState('')
  const [ed, setEd] = useState(null)   // the row being edited / added
  const [up, setUp] = useState(null)   // {file, rep}
  const load = () => api(`/api/chro/asis?q=${encodeURIComponent(q)}&show=${show}`).then(setD).catch(e => notify(e.message, true))
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [q, show])
  const save = async () => {
    try {
      const body = { name: ed.name, grade_raw: ed.grade_raw, position: ed.position, function: ed.function, manager_code: ed.manager_code, emp_type: ed.emp_type, kind: ed.kind, unit: ed.unit, note: ed.note }
      if (ed.isNew) await api('/api/chro/asis', { method: 'POST', body: { code: ed.code, ...body } })
      else await api('/api/chro/asis/' + encodeURIComponent(ed.code), { method: 'PATCH', body })
      notify(ed.isNew ? 'Added to the As Is.' : 'As Is corrected.'); setEd(null); load(); onChanged()
    } catch (e) { notify(e.message, true) }
  }
  const remove = async r => {
    if (!window.confirm(`Remove ${r.name} from the As Is? Their team in the As Is will report to their manager.`)) return
    try { await api('/api/chro/asis/' + encodeURIComponent(r.code), { method: 'DELETE' }); notify('Removed from the As Is.'); setEd(null); load(); onChanged() } catch (e) { notify(e.message, true) }
  }
  const upload = async (file, dry) => {
    const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false')
    try {
      const rep = await api('/api/chro/asis/upload', { method: 'POST', form: fd })
      if (dry) setUp({ file, rep }); else { setUp(null); notify(`As Is replaced: ${fmt(rep.rows)} employees from ${file.name}.`); load(); onChanged() }
    } catch (e) { notify(e.message, true) }
  }
  const reset = async () => {
    if (!window.confirm('Rebuild the As Is from the HR master file imported in Admin? Every correction made here is lost.')) return
    try { const r = await api('/api/chro/asis/reset', { method: 'POST' }); notify(`As Is rebuilt: ${fmt(r.rows)} employees.`); load(); onChanged() } catch (e) { notify(e.message, true) }
  }
  const m = d?.meta || {}
  return <Modal wide title="As Is Data" sub={d ? `${m.file || 'HR master file'} · ${fmt(d.total)} employees${d.edited ? ` · ${fmt(d.edited)} corrected or added` : ''}${m.loaded_at ? ' · loaded ' + m.loaded_at : ''}` : ''} onClose={onClose}>
    <p className="formula" style={{ marginTop: 0 }}>The As Is is used only on this dashboard. Correcting it, or replacing it with a new HR file, does not change anything else in the portal.</p>
    {canEdit && <div className="row-actions" style={{ gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
      <label className="btn pri" style={{ cursor: 'pointer' }}>Upload New HR File<input type="file" accept=".xlsx" hidden onChange={e => { const f = e.target.files[0]; e.target.value = ''; if (f) upload(f, true) }} /></label>
      <button className="btn" onClick={() => setEd({ isNew: true, code: '', name: '', grade_raw: '', position: '', function: '', manager_code: '', emp_type: 'FTE', kind: '', unit: '', note: '' })}>Add Missing Employee</button>
      <button className="btn" onClick={() => download('/api/chro/asis/export', 'As Is.xlsx').catch(e => notify(e.message, true))}>Export As Is (Excel)</button>
      <button className="btn" onClick={reset}>Rebuild from HR Master File</button></div>}
    {up && <div className="ch-card" style={{ marginBottom: 10, borderColor: 'var(--amber)' }}>
      <b>{up.file.name}</b>: {fmt(up.rep.rows)} employees. {fmt(up.rep.new_vs_current_as_is)} not in the current As Is, {fmt(up.rep.dropped_vs_current_as_is)} of the current As Is not in the file; {fmt(up.rep.not_in_portal)} not in the portal.
      <div className="row-actions" style={{ marginTop: 8, gap: 8 }}><button className="btn pri" onClick={() => upload(up.file, false)}>Replace the As Is</button><button className="btn" onClick={() => setUp(null)}>Cancel</button></div></div>}
    {ed && <div className="ch-card" style={{ marginBottom: 10 }}><h3>{ed.isNew ? 'Add a missing employee' : `Correct ${ed.name}`}</h3>
      <div className="ch-form">
        <label className="fld"><span className="fl">Employee code</span><input className="inp" value={ed.code} disabled={!ed.isNew} onChange={e => setEd({ ...ed, code: e.target.value })} placeholder="A portal code fills the rest" /></label>
        <label className="fld"><span className="fl">Name</span><input className="inp" value={ed.name} onChange={e => setEd({ ...ed, name: e.target.value })} /></label>
        <label className="fld"><span className="fl">Grade (as in the HR file)</span><input className="inp" value={ed.grade_raw} onChange={e => setEd({ ...ed, grade_raw: e.target.value })} placeholder="e.g. 068-SM I" /></label>
        <label className="fld"><span className="fl">Position</span><input className="inp" value={ed.position} onChange={e => setEd({ ...ed, position: e.target.value })} /></label>
        <label className="fld"><span className="fl">Function</span><input className="inp" list="ch-fns" value={ed.function} onChange={e => setEd({ ...ed, function: e.target.value })} /></label>
        <label className="fld"><span className="fl">Manager code (N-1)</span><input className="inp" value={ed.manager_code} onChange={e => setEd({ ...ed, manager_code: e.target.value })} /></label>
        <label className="fld"><span className="fl">Type</span><select className="inp" value={ed.kind || ed.emp_type} onChange={e => { const v = e.target.value; setEd({ ...ed, emp_type: v === 'FTC' || v === 'dw' ? 'FTC' : 'FTE', kind: v === 'dc' || v === 'dw' ? v : '' }) }}>
          <option value="FTE">FTE</option><option value="dc">{L('dash.dc')}</option><option value="FTC">FTC</option><option value="dw">{L('dash.dw')}</option></select></label>
        <label className="fld"><span className="fl">Unit</span><input className="inp" value={ed.unit} onChange={e => setEd({ ...ed, unit: e.target.value })} /></label>
        <label className="fld" style={{ gridColumn: 'span 3' }}><span className="fl">Note</span><input className="inp" value={ed.note} onChange={e => setEd({ ...ed, note: e.target.value })} placeholder="Why it was corrected" /></label>
      </div>
      <datalist id="ch-fns">{(d?.functions || []).map(f => <option key={f} value={f} />)}</datalist>
      <div className="row-actions" style={{ marginTop: 10, justifyContent: 'space-between' }}>
        <span>{!ed.isNew && <button className="linkbtn" onClick={() => remove(ed)}>Remove from As Is</button>}</span>
        <span style={{ display: 'flex', gap: 8 }}><button className="btn" onClick={() => setEd(null)}>Cancel</button><button className="btn pri" onClick={save}>Save</button></span></div></div>}
    <div className="kvline" style={{ marginBottom: 8 }}>
      <input className="inp" placeholder="Search by name, code or position" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} />
      <select className="inp" value={show} onChange={e => setShow(e.target.value)} style={{ maxWidth: 200 }}><option value="">Everyone</option><option value="edited">Corrected</option><option value="added">Added</option></select></div>
    <div className="tw scroll" style={{ maxHeight: 400 }}><table>
      <thead><tr><th>Employee</th><th>Grade</th><th>Function</th><th>Manager (As Is)</th><th>Source</th></tr></thead>
      <tbody>{(d?.rows || []).map(r => <tr key={r.code} className={canEdit ? 'click' : ''} onClick={canEdit ? () => setEd({ ...r }) : undefined} title={canEdit ? 'Correct' : ''}>
        <td><b>{r.name}</b><div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div></td><td>{r.grade}</td><td>{r.function}</td>
        <td>{r.manager_name || r.manager_code || '–'}</td><td>{r.source === 'file' ? 'HR file' : r.source === 'added' ? <span className="pill p-ok">Added</span> : <span className="pill p-warn" title={r.note}>Corrected</span>}</td></tr>)}
        {d && d.rows.length >= 400 && <tr><td colSpan={5} className="formula">The first 400 are shown. Search to narrow down.</td></tr>}</tbody></table></div>
  </Modal>
}

// ---------------------------------------------------------------- the page
export default function Chro({ notify, theme }) {
  const [fn, setFn] = useState('')
  const [d, setD] = useState(null)
  const [raw, setRaw] = useState({ asis: null, tobe: null })
  const [ver, setVer] = useState(0)
  const [list, setList] = useState(null)       // the change list open
  const [focus, setFocus] = useState(null)     // the person shown in both organograms
  const [asIs, setAsIs] = useState(false)
  const [plist, setPlist] = useState(null)
  const [busy, setBusy] = useState(false)
  useEffect(() => { setD(null); api('/api/chro/summary?fn=' + encodeURIComponent(fn)).then(setD).catch(e => notify(e.message, true)) }, [fn, ver])
  useEffect(() => { Promise.all([api('/api/chro/org?side=asis'), api('/api/chro/org?side=tobe')]).then(([a, b]) => setRaw({ asis: a, tobe: b })).catch(e => notify(e.message, true)) }, [ver])
  const orgOf = data => {
    if (!data) return null
    const i = fn ? data.functions.indexOf(fn) : -1
    const scoped = i >= 0 ? scopeData(data, [data.function_ids[i]]) : data
    return scoped.people.length ? buildOrg(scoped, true) : null
  }
  const oa = useMemo(() => orgOf(raw.asis), [raw.asis, fn])
  const ob = useMemo(() => orgOf(raw.tobe), [raw.tobe, fn])
  const changed = () => setVer(v => v + 1)
  const pdf = async () => { setBusy(true); try { await download('/api/chro/pdf?fn=' + encodeURIComponent(fn), 'CHRO Report.pdf') } catch (e) { notify(e.message, true) } finally { setBusy(false) } }
  const pick = r => { setList(null); setFocus(r.code) }
  const a = d?.asis, b = d?.tobe, cnt = d?.counts || {}, m = d?.meta || {}
  const chart = (o, side) => {
    if (!o) return <p className="formula">No one {fn ? 'in this function ' : ''}on this side.</p>
    const R = o.ROOT
    // the person, or (when they are not on this side, e.g. a saved role) their manager on the other side, upwards
    let f = focus && o.byId.get(focus)
    if (focus && !f) {
      const rows = new Map([...(raw.asis?.people || []), ...(raw.tobe?.people || [])].map(r => [r[0], r]))
      let c = rows.get(focus)?.[4], n = 0
      while (c && !o.byId.get(c) && n++ < 30) c = rows.get(c)?.[4]
      f = c ? o.byId.get(c) : null
    }
    return <div className="orgchart wide"><Classic simple root={R} top={R} focus={f || null} onFocus={p => setFocus(p ? p.id : null)} org={o} theme={theme} largeTeam={40} onReroot={() => {}}
      onOpenList={x => setPlist({ title: `${x.n}: direct reports (${side})`, people: x.kids.filter(o.counted), org: o })} marks={(side === 'As Is' ? raw.asis : raw.tobe).marks} /></div>
  }
  const TY = [['fte', 'FTE', 'var(--c1)'], ['dc', L('dash.dc'), 'var(--c2)'], ['ftc', 'FTC', 'var(--c3)'], ['dw', L('dash.dw'), 'var(--c4)']]
  return <section className="view on ch-page chv">
    <div className="ch-hero">
      <div className="ch-hero-top"><div><span className="ch-eyebrow">CHRO Dashboard · {fn || L('dash.title')}</span><h1>Organisation: As Is → To Be</h1>
        <div className="ch-hero-sub">As Is: {m.file || 'HR master file'}{m.edits ? ` (${fmt(m.edits)} corrections)` : ''} · To Be: the portal today</div></div>
        <div className="ch-tools">
          <select className="inp" value={fn} onChange={e => { setFn(e.target.value); setFocus(null) }} style={{ minWidth: 240 }}>
            <option value="">All functions</option>{(d?.functions || []).map(f => <option key={f} value={f}>{f}</option>)}</select>
          <button className="btn ch-ghost" onClick={() => setAsIs(true)}>As Is Data</button>
          <button className="btn ch-light" disabled={busy || !d} onClick={pdf}>{busy ? 'Preparing…' : 'Export Report (PDF)'}</button></div></div>
      {d && <div className="ch-hk">
        <HeroK label="Headcount" a={a.headcount} b={b.headcount} low sub={d.tbh ? `+ ${fmt(d.tbh)} positions to be hired` : 'To Be, without saved roles and leavers'} />
        <HeroK label="Headcount saved" b={cnt.saved} sub="roles removed in the restructure" big />
        <HeroK label="Managers" a={a.managers} b={b.managers} low />
        <HeroK label="Average span of control" a={a.avg_span} b={b.avg_span} digits />
        <HeroK label="Layers" a={a.layers} b={b.layers} low sub="down the reporting line" />
        <HeroK label="Managers with 1–2 reports" a={a.narrow} b={b.narrow} low />
      </div>}
    </div>
    {!d ? <div className="loading">Loading…</div> : <>
      <div className="ch-row r21">
        <div className="ch-card"><div className="ch-ct"><h3>Headcount bridge</h3><span>How the As Is headcount becomes the To Be</span></div>
          <Bridge steps={bridge(d, fn)} />
          <div className="chv-leg"><span><i style={{ background: 'var(--before)' }} />Headcount</span><span><i style={{ background: 'var(--c2)' }} />Reduces</span><span><i style={{ background: 'var(--c1)' }} />Adds</span></div></div>
        <div className="ch-card ch-ins"><div className="ch-ct"><h3>Key messages</h3></div>
          <ul>{insights(d, fn).map((t, i) => <li key={i}>{t}</li>)}</ul></div>
      </div>
      <div className="ch-row r11">
        <div className="ch-card"><div className="ch-ct"><h3>Span of control</h3><span>Managers by number of direct reports</span></div>
          <Grouped cats={Object.keys(a.bands)} a={Object.values(a.bands)} b={Object.keys(a.bands).map(k => b.bands[k])} />
          <Legend items={[{ label: 'As Is', color: 'var(--before)' }, { label: 'To Be', color: 'var(--after)' }]} /></div>
        <div className="ch-card"><div className="ch-ct"><h3>Layer pyramid</h3><span>People on each layer from the top (L1)</span></div>
          <Pyramid rows={[...new Set([...Object.keys(a.by_layer), ...Object.keys(b.by_layer)])].sort((x, y) => x - y).map(k => ({ l: 'L' + k, a: a.by_layer[k] || 0, b: b.by_layer[k] || 0 }))} /></div>
      </div>
      {!fn && d.by_function.length > 1 && <div className="ch-row r11">
        <div className="ch-card"><div className="ch-ct"><h3>Where the changes are</h3><span>Changes by function · click one to focus</span></div>
          <StackH onRow={r => { setFn(r.label); setFocus(null) }} keys={[{ k: 'line', label: 'Reporting line changes', color: 'var(--c1)' }, { k: 'moved', label: 'Function moves', color: 'var(--c3)' }, { k: 'saved', label: 'Headcount saved', color: 'var(--c2)' }, { k: 'tbh', label: 'To be hired', color: 'var(--c4)' }]}
            rows={d.by_function.map(f => ({ label: f.function, parts: { line: f.line, moved: f.moved, saved: f.saved, tbh: f.tbh } })).filter(r => Object.values(r.parts).some(Boolean))
              .sort((x, y) => Object.values(y.parts).reduce((s, v) => s + v, 0) - Object.values(x.parts).reduce((s, v) => s + v, 0)).slice(0, 10)} />
          <Legend items={[{ label: 'Reporting line changes', color: 'var(--c1)' }, { label: 'Function moves', color: 'var(--c3)' }, { label: 'Headcount saved', color: 'var(--c2)' }, { label: 'To be hired', color: 'var(--c4)' }]} />
          {!d.by_function.some(f => f.line || f.moved || f.saved || f.tbh) && <p className="formula">No changes yet.</p>}</div>
        <div className="ch-card"><div className="ch-ct"><h3>Average span by function</h3><span>As Is → To Be · click one to focus</span></div>
          <Dumbbell onRow={r => { setFn(r.label); setFocus(null) }} rows={d.by_function.filter(f => f.tobe.managers || f.asis.managers).map(f => ({ label: f.function, a: f.asis.avg_span, b: f.tobe.avg_span })).sort((x, y) => y.b - x.b)} />
          <Legend items={[{ label: 'As Is', color: 'var(--before)' }, { label: 'To Be', color: 'var(--after)' }]} /></div>
      </div>}
      <div className={'ch-row ' + (d.benchmark ? 'r111' : 'r11')}>
        <div className="ch-card"><div className="ch-ct"><h3>Workforce mix</h3><span>By employee type and gender</span></div>
          <Mix100 keys={TY.map(([k, l, c]) => ({ k, label: l, color: c })).filter(t => a.types[t.k] || b.types[t.k])} rows={[{ label: 'As Is', parts: a.types }, { label: 'To Be', parts: b.types }]} />
          <Legend items={TY.filter(([k]) => a.types[k] || b.types[k]).map(([, l, c]) => ({ label: l, color: c }))} />
          <div className="ch-gender">
            <Mix100 keys={[{ k: 'f', label: 'Women', color: 'var(--c3)' }, { k: 'm', label: 'Men', color: 'var(--c1)' }]} rows={[{ label: 'As Is', parts: a.gender }, { label: 'To Be', parts: b.gender }]} />
            <Legend items={[{ label: 'Women', color: 'var(--c3)' }, { label: 'Men', color: 'var(--c1)' }]} /></div></div>
        <div className="ch-card"><div className="ch-ct"><h3>Grade mix</h3><span>People by grade, senior first</span></div>
          <div className="ch-scroll"><PairH rows={gradeRows(a, b)} /></div>
          <Legend items={[{ label: 'As Is', color: 'var(--before)' }, { label: 'To Be', color: 'var(--after)' }]} /></div>
        {d.benchmark && <div className="ch-card"><div className="ch-ct"><h3>Grade benchmark</h3><span>To Be, permanent staff against the max grade of their level</span></div>
          <Segments parts={[{ label: 'Above max grade', v: d.benchmark.above, color: 'var(--c2)' }, { label: 'At max grade', v: d.benchmark.at, color: 'var(--c3)' }, { label: 'Opportunity to grow', v: d.benchmark.room, color: 'var(--c1)' }]} />
          {d.benchmark.extra > 0 && <p className="formula" style={{ marginTop: 12 }}><b>{fmt(d.benchmark.extra)}</b> permanent staff sit on a layer beyond Teams.</p>}</div>}
      </div>
      <div className="ch-cap">Changes done <span>· click any to see the people</span></div>
      <div className="ch-chg">{CHANGES.map(([k, t, c]) => <button key={k} type="button" className={'ch-c ' + c} disabled={!cnt[k]} onClick={() => setList({ k, title: t })}><b>{fmt(cnt[k] || 0)}</b><span>{t}</span></button>)}</div>
      <div className="ch-cap">As Is and To Be organograms</div>
      <div className="ch-leg"><span><i style={{ background: 'var(--amber-soft)', borderColor: 'var(--amber)' }} />Moved (new manager or function)</span>
        <span><i style={{ background: 'color-mix(in srgb,#2E8B57 12%,var(--surface))', borderColor: '#2E8B57' }} />Added</span>
        <span><i style={{ background: 'var(--coral-soft)', borderColor: 'var(--coral)', borderStyle: 'dashed' }} />Headcount saved / resigned (As Is)</span>
        <span>Click anyone: both charts open their reporting line.</span>
        {focus && <button className="linkbtn" onClick={() => setFocus(null)}>Back to the top</button>}</div>
      <div className="ch-orgs">
        <div className="ch-card"><h3>As Is <span className="formula" style={{ fontWeight: 400 }}>{m.file || 'HR master file'}</span></h3>{chart(oa, 'As Is')}</div>
        <div className="ch-card"><h3>To Be <span className="formula" style={{ fontWeight: 400 }}>the portal today</span></h3>{chart(ob, 'To Be')}</div>
      </div>
      {!fn && <><div className="ch-cap">By function</div>
        <div className="ch-card"><div className="tw scroll" style={{ maxHeight: 420 }}><table>
          <thead><tr><th>Function</th><th className="num">Headcount</th><th className="num">Managers</th><th className="num">Avg span</th><th className="num">Layers</th><th className="num">Saved</th><th className="num">Line changes</th><th className="num">To hire</th></tr></thead>
          <tbody>{d.by_function.map(f => <tr key={f.function} className="click-fn" onClick={() => { setFn(f.function); setFocus(null) }}>
            <td>{f.function}</td>
            <td className="num"><span className="ch-arrow">{fmt(f.asis.headcount)} →</span> {fmt(f.tobe.headcount)}</td>
            <td className="num"><span className="ch-arrow">{fmt(f.asis.managers)} →</span> {fmt(f.tobe.managers)}</td>
            <td className="num"><span className="ch-arrow">{n1(f.asis.avg_span)} →</span> {n1(f.tobe.avg_span)}</td>
            <td className="num"><span className="ch-arrow">{f.asis.layers} →</span> {f.tobe.layers}</td>
            <td className="num">{f.saved ? <b>{fmt(f.saved)}</b> : '–'}</td>
            <td className="num">{f.line ? fmt(f.line) : '–'}</td><td className="num">{f.tbh ? fmt(f.tbh) : '–'}</td></tr>)}</tbody></table></div></div></>}
    </>}
    {list && d && <ChangeList k={list.k} title={list.title} rows={d.changes[list.k] || []} onPerson={pick} onClose={() => setList(null)} />}
    {asIs && <AsIsData notify={notify} canEdit={d?.can_edit} onChanged={changed} onClose={() => setAsIs(false)} />}
    {plist && <PeopleModal title={plist.title} people={plist.people} F={plist.org.F} heads={plist.org.headIds} initial="people" onPerson={x => { setPlist(null); setFocus(x.id) }} onClose={() => setPlist(null)} />}
  </section>
}

function HeroK({ label, a, b, low, digits, sub, big }) {
  return <div className={'ch-hkc' + (big ? ' big' : '')}><span>{label}</span>
    <div className="v">{a !== undefined && <s>{n1(a)}<em>→</em></s>}<b>{n1(b)}</b>{a !== undefined && <Delta a={a} b={b} low={low} digits={digits} />}</div>{sub && <small>{sub}</small>}</div>
}

// the steps from the As Is headcount to the To Be (and the planned headcount with the positions to be hired)
function bridge(d, fn) {
  const c = d.counts, ch = d.changes
  const movedIn = fn ? ch.function.filter(x => x.to === fn).length : 0, movedOut = fn ? ch.function.filter(x => x.frm === fn).length : 0
  const steps = [{ label: 'As Is', v: d.asis.headcount, kind: 'total' },
    { label: 'Headcount saved', v: -c.saved, note: 'Roles removed in the restructure' }, { label: 'Resigned', v: -c.resigned },
    { label: 'Not in the portal', v: -c.removed, note: 'In the As Is, no longer in the portal' }]
  if (fn) steps.push({ label: 'Moved out', v: -movedOut }, { label: 'Moved in', v: movedIn })
  steps.push({ label: 'Added', v: c.added, note: 'Not in the As Is' })
  const sum = steps.reduce((a, s) => a + (s.kind === 'total' ? s.v : s.v), 0)
  if (sum !== d.tobe.headcount) steps.push({ label: 'Other changes', v: d.tobe.headcount - sum, note: 'e.g. marked excluded from counts' })
  steps.push({ label: 'To Be', v: d.tobe.headcount, kind: 'total' })
  if (d.tbh) steps.push({ label: 'To be hired', v: d.tbh, note: 'Open positions' }, { label: 'Planned headcount', v: d.tobe.headcount + d.tbh, kind: 'total' })
  return steps.filter(s => s.kind === 'total' || s.v)
}

function gradeRows(a, b) {
  const m = new Map()
  a.grades.forEach(g => m.set(g.g, { l: g.g, rank: g.rank, a: g.n, b: 0 }))
  b.grades.forEach(g => { const r = m.get(g.g) || { l: g.g, rank: g.rank, a: 0, b: 0 }; r.b = g.n; m.set(g.g, r) })
  // the bank grades (AM I and above) one by one; FTC, scales, external and the rest together
  const all = [...m.values()]
  const main = all.filter(r => (r.rank ?? -1) >= 52).sort((x, y) => y.rank - x.rank)
  const rest = all.filter(r => !((r.rank ?? -1) >= 52))
  const other = rest.reduce((o, r) => ({ ...o, a: o.a + r.a, b: o.b + r.b }), { l: 'Other grades', a: 0, b: 0 })
  return other.a || other.b ? [...main, other] : main
}

// a few plain sentences an executive can read first
function insights(d, fn) {
  const a = d.asis, b = d.tobe, c = d.counts, out = []
  const dh = b.headcount - a.headcount
  out.push(dh ? `Headcount ${dh < 0 ? 'falls' : 'rises'} from ${fmt(a.headcount)} to ${fmt(b.headcount)} (${dh > 0 ? '+' : ''}${dh.toLocaleString('en-US')})${c.saved ? `, with ${fmt(c.saved)} roles saved in the restructure` : ''}.` : `Headcount stays at ${fmt(b.headcount)}.`)
  if (a.avg_span !== b.avg_span) out.push(`Average span of control ${b.avg_span > a.avg_span ? 'widens' : 'narrows'} from ${n1(a.avg_span)} to ${n1(b.avg_span)}.`)
  if (a.narrow !== b.narrow) out.push(`Managers with only 1–2 direct reports: ${fmt(a.narrow)} → ${fmt(b.narrow)}.`)
  if (a.managers !== b.managers) out.push(`${fmt(Math.abs(b.managers - a.managers))} ${b.managers < a.managers ? 'fewer' : 'more'} managers (${fmt(a.managers)} → ${fmt(b.managers)}).`)
  if (a.layers !== b.layers) out.push(`The deepest layer moves from L${a.layers} to L${b.layers}.`)
  if (c.line) out.push(`${fmt(c.line)} reporting lines changed${c.function ? ` and ${fmt(c.function)} people moved function` : ''}.`)
  if (!fn) {
    const top = [...d.by_function].sort((x, y) => (y.line + y.saved + y.moved) - (x.line + x.saved + x.moved))[0]
    if (top && top.line + top.saved + top.moved) out.push(`Most change is in ${top.function} (${fmt(top.line + top.saved + top.moved)} changes).`)
  }
  if (d.tbh) out.push(`${fmt(d.tbh)} positions are to be hired, taking the planned headcount to ${fmt(b.headcount + d.tbh)}.`)
  if (d.benchmark && d.benchmark.above) out.push(`${fmt(d.benchmark.above)} people are above the max grade of their level.`)
  if (out.length === 1 && !c.line && !c.saved) out.push('No changes have been made yet against the As Is.')
  return out
}

function Compare({ head, rows, note, one }) {
  return <><div className="tw"><table><thead><tr><th>{head}</th>{!one && <th className="num">As Is</th>}<th className="num">{one ? 'People' : 'To Be'}</th>{!one && <th className="num">Change</th>}</tr></thead>
    <tbody>{rows.map(([l, x, y]) => <tr key={l}><td>{l}</td>{!one && <td className="num">{fmt(x)}</td>}<td className="num">{fmt(y)}</td>
      {!one && <td className="num">{x === y ? '–' : <b>{(y - x > 0 ? '+' : '') + (y - x).toLocaleString('en-US')}</b>}</td>}</tr>)}</tbody></table></div>
    {note && <p className="formula">{note}</p>}</>
}
