import React, { useEffect, useState } from 'react'
import { api, download } from '../api.js'
import { fmt } from '../org.js'
import { Dot, Modal, useLive } from '../ui.jsx'

// Employee Changes: everything that differs from the HR master sheet, function by function, for HR to update their record
const TABS = [
  ['reporting', 'Reporting Line Changes', 'Employees whose manager here differs from the HR record.'],
  ['function', 'Function Changes', 'Employees moved to another function here than in the HR record.'],
  ['added', 'Not in HR Record', 'Working employees added on request of functions; not in the HR master sheet.'],
  ['resigned', 'Marked Resigned', 'Employees marked as resigned here who are still in the HR master sheet.'],
  ['tbh', 'To Be Hired', 'Vacant and to be hired positions (open ones).'],
]
const nz = n => n ? n.toLocaleString('en-US') : '0'

// Admin: keep the HR master sheet as the reference to compare with. It is not an import: nothing in the portal changes.
export function ReferenceModal({ notify, onClose, onDone }) {
  const [file, setFile] = useState(null)
  const [rep, setRep] = useState(null)
  const [busy, setBusy] = useState(false)
  const send = async apply => {
    const fd = new FormData(); fd.append('file', file); fd.append('apply', apply ? 'true' : 'false')
    setBusy(true)
    try { const r = await api('/api/hr/reference', { method: 'POST', form: fd }); setRep(r); if (apply) { notify(`HR values kept for ${nz(r.matched)} employees. Nothing else changed.`); onDone(); onClose() } }
    catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  return <Modal title="Load HR Sheet for Reference" sub="Not an import: no employee is added, removed or changed" onClose={onClose}>
    <p className="formula" style={{ marginTop: 0 }}>The portal reads HR's manager, function and full row for each employee already here, to compare with and for the Full Export. Employees, activities, flags and every change made in the portal stay exactly as they are. Employees in the sheet who are not in the portal are ignored.</p>
    <input type="file" accept=".xlsx,.xlsm" onChange={e => { setFile(e.target.files[0] || null); setRep(null) }} />
    {rep && <div className="panel" style={{ marginTop: 12 }}>
      <div className="kvline"><span>Employees matched</span><b>{nz(rep.matched)} of {nz(rep.portal_employees)}</b></div>
      <div className="kvline"><span>Reporting line differs from HR</span><b>{nz(rep.reporting_differences)}</b></div>
      <div className="kvline"><span>Function differs from HR</span><b>{nz(rep.function_differences)}</b></div>
      {rep.portal_not_in_sheet > 0 && <div className="kvline"><span>In the portal, not in this sheet (left as they are)</span><b>{nz(rep.portal_not_in_sheet)}</b></div>}
      {rep.not_in_portal > 0 && <div className="kvline"><span>In this sheet, not in the portal (ignored)</span><b>{nz(rep.not_in_portal)}</b></div>}
    </div>}
    <div className="row-actions" style={{ marginTop: 12 }}>
      {!rep ? <button className="btn pri" disabled={!file || busy} onClick={() => send(false)}>{busy ? 'Reading…' : 'Check the Sheet'}</button>
        : <button className="btn pri" disabled={busy} onClick={() => send(true)}>{busy ? 'Saving…' : 'Keep as HR Reference'}</button>}
      <button className="btn" onClick={onClose}>Cancel</button></div>
  </Modal>
}

export default function HrChanges({ notify }) {
  const [fid, setFid] = useState('')
  const [tab, setTab] = useState('reporting')
  const [q, setQ] = useState('')
  const [d, busy] = useLive(() => api('/api/hr/changes' + (fid ? `?function_id=${fid}` : '')).catch(e => { notify(e.message, true); return null }), [fid])
  const ql = q.trim().toLowerCase()
  const rows = !d ? [] : d[tab].filter(r => !ql || Object.values(r).join(' ').toLowerCase().includes(ql))
  const emp = r => <td><b>{r.name}</b><div className="formula">{[r.position, r.grade, r.code].filter(Boolean).join(' · ')}</div></td>
  const head = { reporting: ['Employee', 'Function', 'Manager as per HR', 'Manager Now'], function: ['Employee', 'Function as per HR', 'Function Now'],
    added: ['Employee', 'Type', 'Function', 'Unit', 'Manager', 'Added On'], resigned: ['Employee', 'Type', 'Function', 'Manager', 'Resigned On'],
    tbh: ['Position', 'Type', 'Grade', 'Function', 'Reports To', 'Open', 'Note'] }[tab]
  const cells = r => ({
    reporting: <>{emp(r)}<td>{r.function}</td><td>{r.hr_manager || <span className="formula">None (top)</span>}<div className="formula">{r.hr_manager_code}</div></td>
      <td><b>{r.manager || '-'}</b><div className="formula">{r.manager_code}</div>{r.resigned && <div><span className="pill p-bad">Resigned</span></div>}</td></>,
    function: <>{emp(r)}<td>{r.hr_function}</td><td><b>{r.function}</b></td></>,
    added: <>{emp(r)}<td><Dot fte={r.emp_type === 'FTE'} />{r.emp_type}</td><td>{r.function}</td><td>{r.unit || '-'}</td><td>{r.manager || '-'}</td><td className="formula">{r.added_at || '-'}{r.resigned && <div><span className="pill p-bad">Resigned</span></div>}</td></>,
    resigned: <>{emp(r)}<td><Dot fte={r.emp_type === 'FTE'} />{r.emp_type}</td><td>{r.function}</td><td>{r.manager || '-'}</td><td>{r.resigned_on || '-'}</td></>,
    tbh: <><td><b>{r.position}</b></td><td>{r.emp_type}</td><td>{r.grade || '-'}</td><td>{r.function}</td><td>{r.reports_to}</td><td className="num">{nz(r.open)}</td><td className="formula">{r.note}</td></>,
  }[tab])
  const t = TABS.find(x => x[0] === tab)
  return <section className={'view on' + (busy && d ? ' stale' : '')}>
    <header className="pghead"><h1>Employee Changes</h1>
      <div className="pg-side"><button className="btn" disabled={!d} title="The full employee list in the HR master sheet's own columns, as it is in the portal now, with a Portal Change column saying what changed" onClick={() => download('/api/hr/changes/master' + (fid ? `?function_id=${fid}` : ''), 'employee_list.xlsx').catch(e => notify(e.message, true))}>Full Export (HR Sheet Format)</button>
        <button className="btn" disabled={!d} onClick={() => download('/api/hr/changes/export' + (fid ? `?function_id=${fid}` : ''), 'employee_changes.xlsx').catch(e => notify(e.message, true))}>Download Lists</button></div></header>
    {!d ? <div className="loading">Loading…</div> : <>
      <div className="kvline" style={{ marginBottom: 12 }}>
        <select value={fid} onChange={e => setFid(e.target.value)}><option value="">All functions</option>{d.functions.map(f => <option key={f.id} value={String(f.id)}>{f.name}</option>)}</select>
        <input className="inp" type="search" placeholder="Search names, codes, positions" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 260 }} />
      </div>
      <div className="hr-cards">{TABS.map(([k, l]) => <button key={k} type="button" className={'hr-card' + (tab === k ? ' on' : '') + (k === 'tbh' ? ' tbh' : '')} onClick={() => setTab(k)}>
        <b>{nz(k === 'tbh' ? d.tbh.reduce((a, r) => a + r.open, 0) : d[k].length)}</b><span>{l}</span></button>)}</div>
      <div className="panel" style={{ padding: '10px 14px' }}>
        <div className="rhead"><div><h3>{t[1]}</h3><span className="formula">{t[2]}</span></div><span className="formula">{fmt(rows.length) === '-' ? 'None' : `${rows.length} ${tab === 'tbh' ? 'positions' : 'employees'}`}</span></div>
        {!rows.length ? <div className="empty">Nothing here{fid ? ' for this function' : ''}.</div>
          : <div className="tw"><table><thead><tr>{head.map(h => <th key={h} className={h === 'Open' ? 'num' : ''}>{h}</th>)}</tr></thead>
            <tbody>{rows.map((r, i) => <tr key={r.code || r.id || i}>{cells(r)}</tr>)}</tbody></table></div>}
      </div>
    </>}
  </section>
}
