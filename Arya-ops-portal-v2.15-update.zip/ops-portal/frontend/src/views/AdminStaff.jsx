import React, { useEffect, useMemo, useState } from 'react'
import { api, download, getToken } from '../api.js'
import { fmt, TYPE_COL } from '../org.js'
import { Dot } from '../ui.jsx'
import { L } from '../prefs.js'

const FIELD_NAMES = { name: 'name', grade: 'grade', emp_type: 'type', position: 'position', gender: 'gender', manager: 'reporting line', function: 'function', region: 'region', service_role: 'service / support' }

// ================================================================== employees
export function EmployeesTab({ notify, reloadOrg, lookups, showLine }) {
  const [fns, setFns] = useState([])
  const [fid, setFid] = useState('')
  const [q, setQ] = useState('')
  const [show, setShow] = useState('')
  const [rows, setRows] = useState(null)
  const [edit, setEdit] = useState(null)
  const [adding, setAdding] = useState(false)
  const load = () => api(`/api/admin/employees?q=${encodeURIComponent(q)}${fid ? `&function_id=${fid}` : ''}${show ? `&show=${show}` : ''}`).then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { api('/api/capture/functions').then(r => setFns([...r].sort((a, b) => a.name.localeCompare(b.name)))).catch(() => {}) }, [])
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [q, fid, show])
  return <>
    <p className="sub">Correct any employee's details: name, position, grade, type, function, who they report to, unit, region and service or support. Mark employees who have left as resigned: they drop out of every count and list, and their records are kept. Changes take effect immediately on every dashboard. Changes to master-sheet fields are kept when the master sheet is imported again, until you choose to follow the sheet again.</p>
    {adding ? <EmployeeAdd fns={fns} lookups={lookups} notify={notify} close={saved => { setAdding(false); if (saved) { load(); reloadOrg() } }} />
      : edit ? <EmployeeEditor code={edit} fns={fns} lookups={lookups} notify={notify} showLine={showLine} close={saved => { setEdit(null); if (saved) { load(); reloadOrg() } }} />
      : show === 'removed' ? <><div className="kvline"><select value={show} onChange={e => setShow(e.target.value)}><option value="">Everyone</option><option value="resigned">Resigned</option><option value="excluded">Marked exclude from count</option><option value="dc">{L('dash.dc')}</option><option value="dw">{L('dash.dw')}</option><option value="saved">Headcount saved</option><option value="trade">Trade Staff Realignment</option><option value="edited">Edited by admin</option><option value="removed">Removed by admin</option></select></div>
        <RemovedList notify={notify} /></> : <>
      <div className="kvline">
        <input className="inp" placeholder="Search by name, code or position" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 300 }} autoFocus />
        <select value={fid} onChange={e => setFid(e.target.value)}><option value="">All functions</option>{fns.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select>
        <select value={show} onChange={e => setShow(e.target.value)}><option value="">Everyone</option><option value="resigned">Resigned</option><option value="excluded">Marked exclude from count</option><option value="dc">{L('dash.dc')}</option><option value="dw">{L('dash.dw')}</option><option value="saved">Headcount saved</option><option value="trade">Trade Staff Realignment</option><option value="edited">Edited by admin</option><option value="removed">Removed by admin</option></select>
        <button className="btn pri" style={{ marginLeft: 'auto' }} onClick={() => setAdding(true)}>Add Employee</button>
        {rows && <span className="formula">{rows.length >= 300 ? 'First 300 shown; search to narrow down' : `${fmt(rows.length)} employees`}</span>}
      </div>
      <div className="panel" style={{ padding: '8px 12px' }}><div className="tw scroll" style={{ maxHeight: 620 }}><table>
        <thead><tr><th>Name</th><th>Grade</th><th>Type</th><th>Function</th><th>Reports to</th><th>Unit</th><th>Region</th><th>Service / Support</th><th className="num">Direct Reports</th><th></th></tr></thead>
        <tbody>{(rows || []).map(e => <tr key={e.code} className="click" onClick={() => setEdit(e.code)}>
          <td><b>{e.name}</b><div className="formula">{[e.position, e.code].filter(Boolean).join(' · ')}</div></td><td style={{ whiteSpace: 'nowrap' }}>{e.grade}</td>
          <td style={{ whiteSpace: 'nowrap' }}><Dot fte={e.emp_type === 'FTE'} dc={e.dc} dw={e.dw} />{e.dw ? L('dash.dw') : e.dc ? L('dash.dc') : e.emp_type}</td><td>{e.function}</td>
          <td>{e.manager_name}<div className="formula">{e.manager_code}</div></td><td>{e.unit}</td><td>{e.region}</td>
          <td>{e.service_role && <span className="tpill" style={{ '--tc': TYPE_COL[e.service_role] }}>{e.service_role}</span>}</td>
          <td className="num">{e.direct_reports || ''}</td>
          <td style={{ whiteSpace: 'nowrap' }}>{e.resigned && <span className="pill p-bad" title={e.resigned_on ? 'Since ' + e.resigned_on : ''}>Resigned</span>} {e.exclude && <span className="pill p-warn">Excluded</span>} {e.hc_saved && <span className="pill p-bad" title={e.hc_reason}>Headcount saved</span>} {e.overrides.length > 0 && <span className="pill p-ok" title={'Changed by admin: ' + e.overrides.map(f => FIELD_NAMES[f] || f).join(', ')}>Edited</span>}</td></tr>)}
          {rows && !rows.length && <tr><td colSpan={10} className="formula">No one matches.</td></tr>}
          {!rows && <tr><td colSpan={10} className="formula">Loading…</td></tr>}</tbody></table></div></div>
    </>}
  </>
}

function PersonPicker({ value, valueName, onPick, exclude }) {
  const [q, setQ] = useState('')
  const [hits, setHits] = useState([])
  useEffect(() => {
    if (q.trim().length < 2) { setHits([]); return }
    const t = setTimeout(() => api(`/api/admin/employees?q=${encodeURIComponent(q)}`).then(r => setHits(r.filter(x => x.code !== exclude).slice(0, 12))).catch(() => {}), 250)
    return () => clearTimeout(t)
  }, [q])
  return <div className="search" style={{ maxWidth: 'none' }}>
    <div className="chosen" style={{ marginTop: 0 }}><span><b>{valueName || 'No manager'}</b><small>{value || ''}</small></span></div>
    <input className="inp" style={{ width: '100%', marginTop: 6 }} placeholder="Type a name or employee code to change" value={q} onChange={e => setQ(e.target.value)} />
    {hits.length > 0 && <div className="results" style={{ display: 'block' }}>{hits.map(h => <button key={h.code} type="button" onClick={() => { onPick(h); setQ(''); setHits([]) }}>
      {h.name} <small>{[h.code, h.grade, h.position, h.function].filter(Boolean).join(' · ')}</small></button>)}</div>}
  </div>
}

function EmployeeEditor({ code, fns, lookups, notify, close, showLine }) {
  const [e, setE] = useState(null)
  const [f, setF] = useState(null)
  const [grades, setGrades] = useState([])
  const [moveTeam, setMoveTeam] = useState(true)
  const [busy, setBusy] = useState(false)
  const [vacs, setVacs] = useState([])   // open vacant positions of the function (one can be the line manager)
  useEffect(() => {
    api(`/api/admin/employees?q=${encodeURIComponent(code)}`).then(r => { const x = r.find(y => y.code === code); const y = x && { ...x, vac_manager_id: x.vac_manager_id || 0 }; setE(y); setF(y)
      if (x) api('/api/admin/vacancies?function_id=' + x.function_id).then(v => setVacs(v.filter(z => z.open > 0 || z.id === x.vac_manager_id))).catch(() => {}) }).catch(err => notify(err.message, true))
    api('/api/admin/grades').then(setGrades).catch(() => {})
  }, [code])
  if (!e || !f) return <div className="loading">Loading…</div>
  const set = (k, v) => setF(s => ({ ...s, [k]: v }))
  const fnChanged = +f.function_id !== e.function_id
  const diff = ['name', 'position', 'grade_raw', 'emp_type', 'gender', 'function_id', 'manager_code', 'unit', 'region', 'service_role', 'external', 'exclude', 'dc', 'dw', 'vac_manager_id', 'org_note', 'hc_saved', 'hc_reason', 'hc_date', 'replace', 'replace_position', 'replace_grade', 'replace_type', 'replace_manager', 'trade_realign', 'geo_to', 'resigned', 'resigned_on'].filter(k => String(f[k] ?? '') !== String(e[k] ?? ''))
  const save = async () => {
    setBusy(true)
    try {
      const body = Object.fromEntries(diff.map(k => [k, k === 'function_id' ? +f[k] : f[k]]))
      if (fnChanged) body.move_team = moveTeam
      const r = await api(`/api/admin/employees/${encodeURIComponent(code)}`, { method: 'PATCH', body })
      notify(r.changed.length ? `Saved: ${r.changed.join(', ')}${r.moved_team ? `; ${r.moved_team} team members moved with them` : ''}.` : 'No changes.')
      close(true)
    } catch (err) { notify(err.message, true) } finally { setBusy(false) }
  }
  const remove = async () => {
    const msg = `Remove ${e.name} (${e.code}) from the portal?\n\n` +
      `Their recorded activities are deleted.` + (e.direct_reports ? ` Their ${e.direct_reports} direct reports will report to ${e.manager_name || 'their manager'}.` : '') +
      `\nThey stay removed when the master sheet is imported again (you can allow them back under Removed by admin).\n\nTo keep their records instead, mark them Resigned.`
    if (!confirm(msg)) return
    setBusy(true)
    try {
      const r = await api(`/api/admin/employees/${encodeURIComponent(code)}`, { method: 'DELETE' })
      notify(`${e.name} removed${r.activities ? `, ${r.activities} activities deleted` : ''}${r.moved ? `; ${r.moved} direct reports now report to ${r.to}` : ''}.`)
      close(true)
    } catch (err) { notify(err.message, true) } finally { setBusy(false) }
  }
  const revert = async () => {
    if (!confirm('Follow the master sheet again for this employee? Their details will be set from the sheet at the next import.')) return
    try { await api(`/api/admin/employees/${encodeURIComponent(code)}/revert`, { method: 'POST' }); notify('This employee will follow the master sheet at the next import.'); close(true) } catch (err) { notify(err.message, true) }
  }
  const gradeOpts = grades.some(g => g.raw === f.grade_raw) || !f.grade_raw ? grades : [{ raw: f.grade_raw, grade: f.grade }, ...grades]
  return <div className="panel" style={{ borderColor: 'var(--teal)' }}>
    <div className="rhead"><div><h2>{e.name}</h2><div className="formula">{e.code} · {e.source === 'added' ? 'Added in the portal' : 'From the master sheet'}{e.direct_reports ? ` · ${e.direct_reports} direct reports` : ''}</div></div>
      <div className="row-actions">{showLine && <button className="btn" onClick={() => showLine(code)}>Reporting Line</button>}<button className="btn" onClick={() => close(false)}>Back to the list</button></div></div>
    <div className="fgrid" style={{ padding: '6px 0 0' }}>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Name</span><input className="inp" value={f.name} onChange={x => set('name', x.target.value)} /></label>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Position</span><input className="inp" value={f.position} onChange={x => set('position', x.target.value)} /></label>
      <label className="fld" style={{ gridColumn: 'span 2' }}><span className="fl">Grade</span><select value={f.grade_raw} onChange={x => { const g = x.target.value; set('grade_raw', g); if (g.toLowerCase().includes('outsourc')) set('emp_type', 'FTC') }}>
        {gradeOpts.map(g => <option key={g.raw} value={g.raw}>{g.grade}</option>)}</select></label>
      <label className="fld" style={{ gridColumn: 'span 2' }}><span className="fl">Type</span><select value={f.emp_type} onChange={x => set('emp_type', x.target.value)}><option value="FTE">FTE</option><option value="FTC">FTC</option></select></label>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Function</span><select value={f.function_id} onChange={x => set('function_id', +x.target.value)}>{fns.map(fn => <option key={fn.id} value={fn.id}>{fn.name}</option>)}</select>
        {fnChanged && e.direct_reports > 0 && <label className="chk"><input type="checkbox" checked={moveTeam} onChange={x => setMoveTeam(x.target.checked)} />Move everyone below them in {e.function} too</label>}</label>
      <div className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Reports to</span>
        {f.vac_manager_id ? <div className="chosen"><span><b>{(vacs.find(v => v.id === f.vac_manager_id) || {}).position || 'Vacant position'}</b><small>Vacant position · meanwhile {f.manager_name || f.manager_code}</small></span>
            <button type="button" className="linkbtn" onClick={() => set('vac_manager_id', 0)}>Change</button></div>
          : <PersonPicker value={f.manager_code} valueName={f.manager_name} exclude={code} onPick={h => setF(s => ({ ...s, manager_code: h.code, manager_name: h.name }))} />}
        {!f.vac_manager_id && vacs.some(v => v.open > 0) && <select className="inp" value="" onChange={x => x.target.value && set('vac_manager_id', +x.target.value)} style={{ marginTop: 6 }}>
          <option value="">Or a vacant position…</option>{vacs.filter(v => v.open > 0).map(v => <option key={v.id} value={v.id}>{v.position}{v.grade ? ` (${v.grade})` : ''} · {v.parent_id ? 'under ' + v.parent_position : v.manager_name || 'function head'}</option>)}</select>}</div>
      <label className="fld" style={{ gridColumn: 'span 2' }}><span className="fl">Gender</span><select value={f.gender} onChange={x => set('gender', x.target.value)}><option value="">Not set</option><option value="m">Male</option><option value="f">Female</option></select></label>
      <label className="fld" style={{ gridColumn: 'span 2' }}><span className="fl">Region</span><select value={f.region} onChange={x => set('region', x.target.value)}><option value="">Not set</option>{(lookups?.regions || []).map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Unit</span><input className="inp" value={f.unit} onChange={x => set('unit', x.target.value)} /></label>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Service / support</span><select value={f.service_role || ''} onChange={x => set('service_role', x.target.value)}><option value="">Not yet marked</option><option>Service</option><option>Support</option></select></label>
      <div className="fld" style={{ gridColumn: 'span 8' }}><span className="fl">Counting</span>
        <div className="kvline" style={{ margin: 0, gap: 18 }}>
          <label className="chk"><input type="checkbox" checked={f.external} onChange={x => set('external', x.target.checked)} />External (shown with a marker)</label>
          <label className="chk"><input type="checkbox" checked={f.exclude} onChange={x => set('exclude', x.target.checked)} />Exclude from span and employee count</label>
          <label className="chk" title="DC: retired and rehired on contract. Its own type on the dashboard"><input type="checkbox" checked={!!f.dc} onChange={x => setF(s => ({ ...s, dc: x.target.checked, dw: x.target.checked ? false : s.dw }))} /><b>{L('dash.dc')}</b>&nbsp;(DC)</label>
          <label className="chk" title="Its own type on the dashboard"><input type="checkbox" checked={!!f.dw} onChange={x => setF(s => ({ ...s, dw: x.target.checked, dc: x.target.checked ? false : s.dc }))} /><b>{L('dash.dw')}</b></label></div></div>
      <label className="fld" style={{ gridColumn: 'span 12' }}><span className="fl">Organogram note (optional)</span>
        <input className="inp" value={f.org_note || ''} maxLength={300} onChange={x => set('org_note', x.target.value)} placeholder='Shown on top of their organogram card, e.g. "Card Production services to be transitioned here from Jan 26"' /></label>
      <div className={'fld resign' + (f.hc_saved ? ' on' : '')} style={{ gridColumn: 'span 12' }}><span className="fl">Restructure</span>
        <div className="kvline" style={{ margin: 0, gap: 12, flexWrap: 'wrap' }}>
          <label className="chk"><input type="checkbox" checked={!!f.hc_saved} onChange={x => setF(s => ({ ...s, hc_saved: x.target.checked, hc_date: x.target.checked && !s.hc_date ? new Date().toISOString().slice(0, 10) : s.hc_date }))} /><b>Headcount saved</b>&nbsp;(role removed in the restructure)</label>
          {f.hc_saved && <><input className="inp" value={f.hc_reason || ''} onChange={x => set('hc_reason', x.target.value)} placeholder="Reason, e.g. merged with Recovery team" style={{ minWidth: 300, flex: 1 }} />
            <input className="inp" type="date" value={f.hc_date || ''} onChange={x => set('hc_date', x.target.value)} style={{ width: 170 }} /></>}
          <span className="formula">{f.hc_saved ? 'Shown cut on the organogram, with their team still under them; not counted in the Proposed State of the HR Dashboard.' : 'Surrender: shown on the HR Dashboard as headcount saved.'}</span></div>
        {f.hc_saved && <div className="kvline" style={{ margin: '8px 0 0', gap: 12, flexWrap: 'wrap' }}>
          <label className="chk"><input type="checkbox" checked={!!f.replace} onChange={x => setF(s => ({ ...s, replace: x.target.checked, replace_position: s.replace_position || e.position || '', replace_grade: s.replace_grade || e.grade || '', replace_type: s.replace_type || e.emp_type || 'FTE' }))} /><b>Replace with a vacant position</b></label>
          {f.replace && <><input className="inp" value={f.replace_position || ''} onChange={x => set('replace_position', x.target.value)} placeholder="Position" style={{ minWidth: 240, flex: 1 }} />
            <input className="inp" value={f.replace_grade || ''} onChange={x => set('replace_grade', x.target.value)} placeholder="Grade" style={{ width: 120 }} />
            <select className="inp" value={f.replace_type || 'FTE'} onChange={x => set('replace_type', x.target.value)} style={{ width: 90 }}><option>FTE</option><option>FTC</option></select>
            <div style={{ flexBasis: '100%' }}><span className="fl">Replacement reports to</span>
              <PersonPicker value={f.replace_manager || f.manager_code} valueName={f.replace_manager_name || (f.replace_manager ? '' : f.manager_name)} exclude={code}
                onPick={h => setF(s => ({ ...s, replace_manager: h.code, replace_manager_name: h.name }))} /></div></>}
          <span className="formula">{f.replace ? 'Special Replacement' + (f.dc ? ' (PR)' : '') + ': shown cut on the organogram, with their team as is; the Replacement vacant position reports to the person chosen.' : 'No replacement: Staff Exit Candidate.'}</span></div>}</div>
      <div className={'fld resign' + (f.trade_realign ? ' on' : '')} style={{ gridColumn: 'span 12' }}><span className="fl">Trade Staff Realignment</span>
        <label className="chk"><input type="checkbox" checked={!!f.trade_realign} onChange={x => set('trade_realign', x.target.checked)} /><b>Marked for Trade Staff Realignment</b></label></div>
      <div className={'fld resign' + (f.geo_to ? ' on' : '')} style={{ gridColumn: 'span 12' }}><span className="fl">Geographic Consolidation</span>
        <div className="kvline" style={{ margin: 0, gap: 12, flexWrap: 'wrap' }}><span>This unit (they and their team) moves to</span>
          <select className="inp" value={f.geo_to || ''} onChange={x => set('geo_to', x.target.value)} style={{ maxWidth: 220 }}><option value="">Not marked</option>{(lookups?.regions || []).map(r => <option key={r}>{r}</option>)}</select></div></div>
      <div className={'fld resign' + (f.resigned ? ' on' : '')} style={{ gridColumn: 'span 12' }}><span className="fl">Employment</span>
        <div className="kvline" style={{ margin: 0, gap: 14 }}>
          <label className="chk"><input type="checkbox" checked={!!f.resigned} onChange={x => { set('resigned', x.target.checked); if (x.target.checked && !f.resigned_on) set('resigned_on', new Date().toISOString().slice(0, 10)) }} /><b>Resigned</b></label>
          {f.resigned && <><span className="formula">Last working day</span><input className="inp" type="date" value={f.resigned_on || ''} onChange={x => set('resigned_on', x.target.value)} style={{ width: 170 }} /></>}
          <span className="formula">{f.resigned ? `Not counted anywhere and hidden from data capture.${e.direct_reports && !e.resigned ? ` When you save, their ${e.direct_reports} direct reports will report to ${e.manager_name || 'their line manager'}.` : ''}` : 'Mark an employee who has left. They stop being counted; their records are kept and can be restored by unticking.'}</span>
        </div></div>
    </div>
    {e.overrides.length > 0 && <div className="msg ok">Changed by admin and kept at every master sheet import: <b>{e.overrides.map(x => FIELD_NAMES[x] || x).join(', ')}</b>. <button className="linkbtn" onClick={revert}>Follow the master sheet again</button></div>}
    <div className="row-actions" style={{ marginTop: 16 }}>
      <button className="btn danger" style={{ marginRight: 'auto' }} disabled={busy} onClick={remove}>Remove Employee</button>
      <button className="btn pri" disabled={busy || !diff.length} onClick={save}>{busy ? 'Saving…' : diff.length ? `Save ${diff.length} change${diff.length === 1 ? '' : 's'}` : 'No changes'}</button>
      <button className="btn" onClick={() => close(false)}>Cancel</button></div>
  </div>
}

// a new employee who is not in the master sheet
function EmployeeAdd({ fns, lookups, notify, close }) {
  const [f, setF] = useState({ code: '', name: '', position: '', grade: '', emp_type: 'FTE', function_id: fns[0]?.id || '', manager_code: '', manager_name: '', region: '', unit: '', service_role: '', gender: '' })
  const [grades, setGrades] = useState([])
  const [busy, setBusy] = useState(false)
  useEffect(() => { api('/api/admin/grades').then(setGrades).catch(() => {}) }, [])
  const set = (k, v) => setF(s => ({ ...s, [k]: v }))
  const ok = f.code.trim() && f.name.trim() && f.function_id && f.manager_code
  const save = async () => {
    setBusy(true)
    try {
      const r = await api('/api/admin/employees', { method: 'POST', body: { ...f, function_id: +f.function_id } })
      notify(`${r.name} added to ${r.function}.`); close(true)
    } catch (err) { notify(err.message, true) } finally { setBusy(false) }
  }
  return <div className="panel" style={{ borderColor: 'var(--teal)' }}>
    <div className="rhead"><div><h2>Add Employee</h2><div className="formula">For someone not in the master sheet. They are kept when the master sheet is imported again.</div></div>
      <div className="row-actions"><button className="btn" onClick={() => close(false)}>Back to the List</button></div></div>
    <div className="fgrid" style={{ padding: '6px 0 0' }}>
      <label className="fld" style={{ gridColumn: 'span 3' }}><span className="fl">Employee Code *</span><input className="inp" value={f.code} onChange={x => set('code', x.target.value)} autoFocus /></label>
      <label className="fld" style={{ gridColumn: 'span 5' }}><span className="fl">Name *</span><input className="inp" value={f.name} onChange={x => set('name', x.target.value)} /></label>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Position</span><input className="inp" value={f.position} onChange={x => set('position', x.target.value)} /></label>
      <label className="fld" style={{ gridColumn: 'span 2' }}><span className="fl">Grade</span><select value={f.grade} onChange={x => { const g = x.target.value; set('grade', g); if (g.toLowerCase().includes('outsourc')) set('emp_type', 'FTC') }}>
        <option value="">Not set</option>{grades.map(g => <option key={g.raw} value={g.raw}>{g.grade}</option>)}</select></label>
      <label className="fld" style={{ gridColumn: 'span 2' }}><span className="fl">Type</span><select value={f.emp_type} onChange={x => set('emp_type', x.target.value)}><option value="FTE">FTE</option><option value="FTC">FTC</option></select></label>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Function *</span><select value={f.function_id} onChange={x => set('function_id', x.target.value)}>{fns.map(fn => <option key={fn.id} value={fn.id}>{fn.name}</option>)}</select></label>
      <div className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Reports To *</span>
        <PersonPicker value={f.manager_code} valueName={f.manager_name || 'Choose the manager'} onPick={h => setF(s => ({ ...s, manager_code: h.code, manager_name: h.name }))} /></div>
      <label className="fld" style={{ gridColumn: 'span 2' }}><span className="fl">Gender</span><select value={f.gender} onChange={x => set('gender', x.target.value)}><option value="">Not set</option><option value="m">Male</option><option value="f">Female</option></select></label>
      <label className="fld" style={{ gridColumn: 'span 2' }}><span className="fl">Region</span><select value={f.region} onChange={x => set('region', x.target.value)}><option value="">Not set</option>{(lookups?.regions || []).map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Unit</span><input className="inp" value={f.unit} onChange={x => set('unit', x.target.value)} /></label>
      <label className="fld" style={{ gridColumn: 'span 4' }}><span className="fl">Service / Support</span><select value={f.service_role} onChange={x => set('service_role', x.target.value)}><option value="">Not yet marked</option><option>Service</option><option>Support</option></select></label>
    </div>
    <div className="row-actions" style={{ marginTop: 16 }}>
      <button className="btn pri" disabled={busy || !ok} onClick={save}>{busy ? 'Adding…' : 'Add Employee'}</button>
      <button className="btn" onClick={() => close(false)}>Cancel</button>
      {!ok && <span className="formula">Code, name, function and manager are needed.</span>}</div>
  </div>
}

// employees the admin removed: skipped at every master sheet import until allowed back
function RemovedList({ notify }) {
  const [rows, setRows] = useState(null)
  const load = () => api('/api/admin/removed-employees').then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [])
  const back = r => {
    if (!confirm(`Allow ${r.name} back? If they are in the master sheet, the next import adds them again.`)) return
    api(`/api/admin/removed-employees/${encodeURIComponent(r.code)}`, { method: 'DELETE' }).then(() => { notify(`${r.name} will come back at the next import if they are in the master sheet.`); load() }).catch(e => notify(e.message, true))
  }
  return <div className="panel" style={{ padding: '8px 12px' }}><div className="tw"><table>
    <thead><tr><th>Name</th><th>Function</th><th>Removed</th><th>By</th><th></th></tr></thead>
    <tbody>{(rows || []).map(r => <tr key={r.code}><td><b>{r.name}</b><div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div></td><td>{r.function}</td><td>{r.at}</td><td>{r.by}</td>
      <td><button className="btn" onClick={() => back(r)}>Allow Back</button></td></tr>)}
      {rows && !rows.length && <tr><td colSpan={5} className="formula">No one has been removed.</td></tr>}
      {!rows && <tr><td colSpan={5} className="formula">Loading…</td></tr>}</tbody></table></div></div>
}

// ================================================================== data transfer
export function TransferTab({ notify, reloadOrg }) {
  const [fns, setFns] = useState([])
  const [sel, setSel] = useState(() => new Set())
  const [busy, setBusy] = useState(false)
  const [file, setFile] = useState(null)
  const [structure, setStructure] = useState(true)
  const [rep, setRep] = useState(null)
  useEffect(() => { api('/api/capture/functions').then(r => setFns([...r].sort((a, b) => a.name.localeCompare(b.name)))).catch(() => {}) }, [])
  const exp = async ids => {
    setBusy(true)
    try { await download(`/api/admin/transfer/export?functions=${ids.join(',')}`, 'portal_data.xlsx'); notify('Export ready. Check your downloads.') }
    catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const run = async dry => {
    if (!file) return
    if (!dry && !confirm('Import this file? The activities of every employee in the file replace their current activities here.')) return
    setBusy(true)
    try {
      const fd = new FormData(); fd.append('file', file); fd.append('apply_structure', structure ? 'true' : 'false'); fd.append('dry_run', dry ? 'true' : 'false')
      const r = await api('/api/admin/transfer/import', { method: 'POST', form: fd }); setRep(r)
      if (!dry) { notify('Import complete.'); reloadOrg() }
    } catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const toggle = id => setSel(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })
  return <div className="grid g2">
    <div className="panel"><h2>1. Export</h2>
      <p className="sub">Downloads an Excel workbook with each employee's unit and region, every activity and the calculation settings, for the chosen functions. Import it on another installation (for example, from your PC to the VM). It also works as a readable backup.</p>
      <div className="row-actions" style={{ marginBottom: 10 }}><button className="btn pri" disabled={busy} onClick={() => exp([])}>Export all functions</button>
        <button className="btn" disabled={busy || !sel.size} onClick={() => exp([...sel])}>Export the {sel.size} ticked</button>
        <button className="btn" onClick={() => setSel(sel.size ? new Set() : new Set(fns.map(f => f.id)))}>{sel.size ? 'Clear' : 'Tick all'}</button></div>
      <div className="pick tall">{fns.map(f => <label key={f.id} className="chk"><input type="checkbox" checked={sel.has(f.id)} onChange={() => toggle(f.id)} />
        <span><b>{f.name}</b><small>{fmt(f.headcount)} employees · {fmt(f.activities)} activities · {f.status}</small></span>
        <button type="button" className="btn" onClick={e => { e.preventDefault(); exp([f.id]) }} disabled={busy}>Export</button></label>)}</div>
    </div>
    <div className="panel"><h2>2. Import</h2>
      <p className="sub">On the installation that receives the data, import the same employee master sheet first (Admin, Import), then upload the exported workbook here. Check the file first, then import.</p>
      <label className="btn" style={{ display: 'inline-block' }}>{file ? file.name : 'Choose the exported workbook'}<input type="file" accept=".xlsx,.xlsm" style={{ display: 'none' }} onChange={e => { setFile(e.target.files[0] || null); setRep(null); e.target.value = '' }} /></label>
      <label className="chk" style={{ marginTop: 12 }}><input type="checkbox" checked={structure} onChange={e => setStructure(e.target.checked)} />
        <span>Also apply function, reporting line, title (position) and resigned changes from the file, and create employees that functions added</span></label>
      <div className="msg warn">The activities of every employee who has rows in the file <b>replace</b> that employee's current activities. Employees with no rows in the file are left as they are. Units and regions in the file are applied.</div>
      <div className="row-actions" style={{ marginTop: 12 }}><button className="btn" disabled={!file || busy} onClick={() => run(true)}>Check the file (no changes)</button>
        <button className="btn pri" disabled={!file || busy} onClick={() => run(false)}>{busy ? 'Working…' : 'Import'}</button></div>
      {rep && <div className="checks" style={{ marginTop: 16 }}>
        <b>{rep.dry_run ? 'Check result: nothing has been changed yet' : 'Imported'}</b>
        {[`${fmt(rep.activities)} activities for ${fmt(rep.employees_replaced)} employees.`,
          `${fmt(rep.staff_updated)} of ${fmt(rep.staff_rows)} employee rows change a unit, region, title, function, reporting line or resigned${rep.moved ? ` (${fmt(rep.moved)} function changes)` : ''}${rep.positions ? `; ${fmt(rep.positions)} titles (positions) change` : ''}.`,
          rep.created ? `${fmt(rep.created)} employees added by functions created.` : null,
          rep.vacancies && (rep.vacancies.added + rep.vacancies.updated + rep.vacancies.deleted) ? `Vacant positions: ${rep.vacancies.added} added, ${rep.vacancies.updated} changed, ${rep.vacancies.deleted} deleted.` : null,
          rep.settings?.length ? `Settings: ${rep.settings.join('; ')}.` : null].filter(Boolean).map((t, i) => <div key={i} className="check"><i style={{ background: 'var(--teal)' }}>✓</i><span>{t}</span></div>)}
        {rep.not_found.length > 0 && <div className="check"><i style={{ background: 'var(--amber)' }}>i</i><span>{fmt(rep.not_found.length)} employee codes in the file are not in this installation's master data and were skipped: {rep.not_found.slice(0, 20).join(', ')}{rep.not_found.length > 20 ? '…' : ''}</span></div>}
        {rep.problems.map((t, i) => <div key={i} className="check"><i style={{ background: 'var(--amber)' }}>i</i><span>{t}</span></div>)}
      </div>}
    </div>
  </div>
}
