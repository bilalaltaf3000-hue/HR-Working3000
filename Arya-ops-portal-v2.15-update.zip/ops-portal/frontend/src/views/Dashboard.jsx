import React, { useEffect, useMemo, useRef, useState } from 'react'
import { api, unitQS, download } from '../api.js'
import { canBench, canExport, canLayers, canSummary } from '../rights.js'
import LayerPanel from './LayerPanel.jsx'
import { exportOrgHtml } from '../exportHtml.js'
import { SummaryModal, useSumCodes } from './Summary.jsx'
import { SegModal, useSegTables } from './Segments.jsx'
import { ThemeCatBrowser, VolPair } from './Insights.jsx'
import { fmt, hrs, pct, short, TYPE_COL, typeLabel, pcs, vfmt } from '../org.js'
import { PeopleModal, ChartBox, css, Dot, Expand, Modal, Kpi, Ring, Split, Steps, useLive, types } from '../ui.jsx'
import { Classic } from './Organogram.jsx'
import { BenchFramework, BenchLegend, BenchSection, useBench } from './Benchmark.jsx'
import Opportunities from './Opportunities.jsx'
import { prefs, L, themeColor, vacKindL, vacPillC } from '../prefs.js'

const SECTIONS = [['org', 'Organogram', 'Reporting Structure'], ['layers', 'Layers and Spans', 'Depth of the Structure'], ['work', 'Service or Support', 'Type of Work'], ['acts', 'Activities', 'Activity Themes'], ['opps', 'Opportunities', 'Structure Findings'], ['bench', 'Grade Benchmark', 'Grade against the Max']]
const TYPES = ['Service', 'Support']   // employees not yet marked are not shown on the dashboard
// writes each bar's value above it
const barValues = { id: 'barValues', afterDatasetsDraw(chart) {
  const { ctx } = chart
  chart.data.datasets.forEach((ds, di) => chart.getDatasetMeta(di).data.forEach((bar, i) => {
    const v = ds.data[i]; if (!v) return
    ctx.save(); ctx.fillStyle = css('--ink-2'); ctx.font = '700 12px Manrope, Segoe UI, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'
    ctx.fillText(Number(v).toLocaleString('en-US'), bar.x, bar.y - 4); ctx.restore()
  }))
} }
const byType = et => p => !et || (et === 'FTE' ? p.fte : !p.fte)
// FTE / FTC filter shown on the right of a section heading
export function TypeFilter({ value, onChange, all = 'All Employees' }) {
  return <span className="seg sm" role="group" aria-label="Filter by employee type">
    {[['', all], ['FTE', 'FTE'], ['FTC', 'FTC']].map(([v, l]) => <button key={v} type="button" aria-pressed={value === v} onClick={() => onChange(v)}>{l}</button>)}</span>
}

// ------------------------------------------------------------------ function filter (drop-down)
export function FilterBar({ fns, sel, setSel, label, scoped, total }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const ref = useRef(null)
  useEffect(() => {
    if (!open) return
    const out = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    const esc = e => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', out); document.addEventListener('keydown', esc)
    return () => { document.removeEventListener('mousedown', out); document.removeEventListener('keydown', esc) }
  }, [open])
  const toggle = id => setSel(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id])
  const all = scoped ? 'All my functions' : label
  const picked = fns.filter(f => sel.includes(f.id))
  const count = picked.length ? picked.reduce((a, f) => a + f.hc, 0) : total
  const ql = q.trim().toLowerCase()
  const shown = fns.filter(f => !ql || f.name.toLowerCase().includes(ql))
  return <div className="fpick" ref={ref}>
    <button type="button" className="fpick-btn" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(o => !o)}>
      {picked.length > 0 && <span className="fp-label">{picked.length === 1 ? "Function" : "Functions"}</span>}
      <span className="fp-val">{!picked.length ? <b>{all}</b> : picked.length === 1 ? <><i style={{ background: picked[0].color }} /><b>{picked[0].name}</b></> : <><span className="fp-dots">{picked.slice(0, 5).map(f => <i key={f.id} style={{ background: f.color }} />)}</span><b>{picked.length} functions</b></>}</span>
      <small>{fmt(count)}</small><span className="fp-caret">▾</span>
    </button>
    {picked.length > 1 && <span className="fp-names">{picked.map(f => f.name).join(' · ')}</span>}
    {picked.length > 0 && <button type="button" className="linkbtn" onClick={() => setSel([])}>Show {all}</button>}
    {open && <div className="fpick-pop" role="listbox" aria-multiselectable="true">
      <input className="inp" placeholder="Find a function" value={q} onChange={e => setQ(e.target.value)} autoFocus />
      <button type="button" className={'fp-row grp' + (!picked.length ? ' on' : '')} onClick={() => { setSel([]); setOpen(false) }}>
        <span className="fp-check">{!picked.length ? '✓' : ''}</span><b>{all}</b><small>{fmt(total)}</small></button>
      <div className="fp-list">{shown.map(f => { const on = sel.includes(f.id)
        return <button type="button" key={f.id} className={'fp-row' + (on ? ' on' : '')} role="option" aria-selected={on} onClick={() => toggle(f.id)}>
          <span className="fp-check">{on ? '✓' : ''}</span><i style={{ background: f.color }} /><span className="fp-name">{f.name}</span><small>{fmt(f.hc)}</small></button> })}
        {!shown.length && <div className="formula" style={{ padding: 10 }}>No function matches.</div>}</div>
      <div className="fp-foot"><span className="formula">{picked.length ? `${picked.length} selected` : ''}</span>
        <button type="button" className="btn" onClick={() => setSel([])} disabled={!picked.length}>Clear</button>
        <button type="button" className="btn pri" onClick={() => setOpen(false)}>Done</button></div>
    </div>}
  </div>
}

// unit filter: shown next to the function filter when the selected functions use units
export function UnitFilter({ units, sel, setSel }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const ref = useRef(null)
  useEffect(() => {
    if (!open) return
    const out = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    const esc = e => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', out); document.addEventListener('keydown', esc)
    return () => { document.removeEventListener('mousedown', out); document.removeEventListener('keydown', esc) }
  }, [open])
  const toggle = u => setSel(s => s.includes(u) ? s.filter(x => x !== u) : [...s, u])
  const ql = q.trim().toLowerCase()
  const shown = units.filter(u => !ql || u.toLowerCase().includes(ql))
  return <div className="fpick" ref={ref}>
    <button type="button" className="fpick-btn" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(o => !o)}>
      {sel.length > 0 && <span className="fp-label">{sel.length === 1 ? 'Unit' : 'Units'}</span>}
      <span className="fp-val"><b>{!sel.length ? 'All Units' : sel.length === 1 ? sel[0] : `${sel.length} units`}</b></span><span className="fp-caret">▾</span>
    </button>
    {sel.length > 1 && <span className="fp-names">{sel.join(', ')}</span>}
    {sel.length > 0 && <button type="button" className="linkbtn" onClick={() => setSel([])}>Show All Units</button>}
    {open && <div className="fpick-pop" role="listbox" aria-multiselectable="true">
      {units.length > 8 && <input className="inp" placeholder="Find a unit" value={q} onChange={e => setQ(e.target.value)} autoFocus />}
      <button type="button" className={'fp-row grp' + (!sel.length ? ' on' : '')} onClick={() => { setSel([]); setOpen(false) }}>
        <span className="fp-check">{!sel.length ? '✓' : ''}</span><b>All Units</b></button>
      <div className="fp-list">{shown.map(u => { const on = sel.includes(u)
        return <button type="button" key={u} className={'fp-row u' + (on ? ' on' : '')} role="option" aria-selected={on} onClick={() => toggle(u)}>
          <span className="fp-check">{on ? '✓' : ''}</span><span className="fp-name">{u}</span></button> })}
        {!shown.length && <div className="formula" style={{ padding: 10 }}>No unit matches.</div>}</div>
      <div className="fp-foot"><span className="formula">{sel.length ? `${sel.length} selected` : ''}</span>
        <button type="button" className="btn" onClick={() => setSel([])} disabled={!sel.length}>Clear</button>
        <button type="button" className="btn pri" onClick={() => setOpen(false)}>Done</button></div>
    </div>}
  </div>
}

function Sec({ id, n, title, sub, right, children, busy }) {
  return <section id={'sec-' + id} className={'dsec' + (busy ? ' busy' : '')}>
    <div className="dsec-h"><div><span className="dbul" /><h2>{title}</h2></div>{right}</div>
    {children}
  </section>
}

function Tile({ label, value, sub, tone, onClick, foot }) {
  const El = onClick ? 'button' : 'div'
  return <El className={'tile' + (onClick ? ' click' : '')} onClick={onClick} style={{ '--tc': tone || 'var(--teal)' }}>
    <span className="tl">{label}</span><b className="tv">{value}</b>{sub && <span className="ts">{sub}</span>}{foot}
    {onClick && <span className="tgo">View breakdown ›</span>}</El>
}

const HeadCard = ({ p, org, onOpen, big }) => <button className={'head' + (big ? ' big' : '')} style={{ '--fc': org.FCOL[p.f] }} onClick={() => onOpen(p)}>
  <span className="nm">{p.n}</span><span className="ps">{p.pos || '-'}</span>
  <span className="hk"><span><b>{fmt(p.nk)}</b> direct reports</span><span><b>{fmt(p.team)}</b> total team</span></span></button>

export default function Dashboard({ org, orgFor, orgSpan, go, theme, user, includeFlagged, setIncludeFlagged, sel, units, titleUnits, showLine, notify, reloadOrg }) {
  const { C, P, F, ROOT, fstats, FCOL } = org
  const [modal, setModal] = useState(null)
  const [croot, setCroot] = useState(null)
  const selKey = (sel || []).join(',')

  const fsorted = useMemo(() => [...fstats].sort((a, b) => a.name.localeCompare(b.name)), [fstats])
  const single = fsorted.length === 1
  const heads = useMemo(() => {
    if (!sel?.length) return [ROOT]
    return fsorted.map(s => s.head).filter(Boolean)
  }, [org])
  const chartRoot = single && heads[0] ? heads[0] : ROOT
  // section 1 can be limited to FTE or FTC staff
  const O = org   // the dashboard organogram shows all staff (no FTE / FTC filter)
  const H1 = heads.map(h => O.byId.get(h.id)).filter(Boolean)
  const R1 = O.byId.get(chartRoot.id) || O.ROOT
  const headSet = useMemo(() => new Set([ROOT.i, ...fstats.map(s => s.head?.i).filter(i => i !== undefined)]), [org])
  useEffect(() => setCroot(null), [org])
  const people = (title, list, sub, initial) => setModal({ kind: 'people', title, list, sub, initial })
  const openP = p => { if (showLine) showLine(p.id); else { setModal(null); go('org', p.i) } }

  // the title: the functions on show (by name), with the units when the unit filter is on
  const fnNames = [...fsorted].map(s => s.name).sort((a, b) => a.localeCompare(b))
  const fnTitle = !sel?.length && !org.scoped ? L('dash.title') : fnNames.length <= 4 ? fnNames.join(', ') : `${fnNames.length} Functions`
  const tu = titleUnits?.length ? titleUnits : units
  const title = tu?.length ? `${fnTitle}: ${tu.length <= 3 ? tu.join(', ') : tu.length + ' Units'}` : fnTitle
  // one card per employee type, in the admin's order; Contract (DC) and Daily Wagers show once anyone is marked
  const typeCards = types().filter(t => t.k === 'fte' || t.k === 'ftc' || O.P.some(t.test)).map(t => ({ ...t, ps: C.filter(t.test) }))
  const mgrsAll = C.filter(p => p.nk > 0 && p !== ROOT)
  const avgSpan = mgrsAll.length ? mgrsAll.reduce((a, m) => a + m.nk, 0) / mgrsAll.length : 0
  const nLayers = C.length ? Math.max(0, ...C.map(p => p.ly)) : 0   // the deepest layer (a blank layer above it still counts)   // the deepest layer; the Group Head is Layer 1
  const allGrades = useMemo(() => { const m = new Map(); C.forEach(p => { if (!m.has(p.g)) m.set(p.g, { g: p.g, rk: p.rk ?? -9, ps: [] }); m.get(p.g).ps.push(p) }); return [...m.values()].sort((a, b) => b.rk - a.rk || String(a.g).localeCompare(String(b.g))) }, [org])
  // outsourced and ungraded staff are shown apart, so they do not dwarf the graded structure
  const grades = allGrades.filter(g => g.rk > 0), ungraded = allGrades.filter(g => !(g.rk > 0))
  const svcN = C.filter(p => p.st === 'Service').length, supN = C.filter(p => p.st === 'Support').length

  const [openSec, setOpenSec] = useState(null)
  const [focusP, setFocusP] = useState(null)
  useEffect(() => setFocusP(f => (f && org.byId.get(f) ? f : null)), [org])   // keep the person in focus when the data reloads (e.g. a level set in the layer panel)
  const toggleSec = k => { setOpenSec(o => o === k ? null : k); setTimeout(() => document.getElementById('sec-' + k)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60) }
  const fp = focusP ? O.byId.get(focusP) : null
  // vacant / to be hired positions: in the organogram of one function only (not the whole organisation)
  const oneFid = single && org.fids ? org.fids[fsorted[0].f] : null
  const [vac, setVac] = useState([])
  const [showTbh, setShowTbh] = useState(false)   // to be hired positions are hidden from the chart until asked for
  // one function: the reporting line view (as for the whole of COSO) or the open teams view; remembered in this browser
  const [orgView, setOrgView0] = useState(() => { try { return localStorage.getItem('org.view') === 'teams' ? 'teams' : 'line' } catch { return 'line' } })
  const [benchOn, setBenchOn0] = useState(() => { try { return localStorage.getItem('org.bench') === '1' } catch { return false } })
  const setBenchOn = v => { setBenchOn0(v); try { localStorage.setItem('org.bench', v ? '1' : '0') } catch { /* no storage */ } }
  const sums = useSumCodes(canSummary(user) && openSec === 'org')
  const [sumCode, setSumCode] = useState(null)
  const layOk = canLayers(user)
  const [layOn, setLayOn0] = useState(() => { try { return localStorage.getItem('org.layers') === '1' } catch { return false } })
  const setLayOn = v => { setLayOn0(v); try { localStorage.setItem('org.layers', v ? '1' : '0') } catch { /* no storage */ } }
  const [selP, setSelP] = useState(null)
  const benchOk = canBench(user)
  const segs = useSegTables()
  const [segOpen, setSegOpen] = useState(false)
  const [fw, setFw] = useState(null)   // the benchmark framework (View Benchmark)
  const openFw = () => api('/api/bm/framework').then(setFw).catch(e => notify && notify(e.message, true))
  const bench = useBench(benchOk && benchOn && openSec === 'org', org)
  const benchCounts = useMemo(() => { if (!bench) return null; const c = { room: 0, at: 0, above: 0 }; C.forEach(p => { const b = bench.people[p.id]; if (b && b.t) c[b.t]++ }); return c }, [bench, org])
  const setOrgView = v => { setOrgView0(v); setFocusP(null); try { localStorage.setItem('org.view', v) } catch { /* no storage */ } }
  useEffect(() => { if (!oneFid) { setVac([]); return } api('/api/vacancies?functions=' + oneFid).then(r => setVac((units || []).length ? r.filter(v => !v.unit || units.includes(v.unit)) : r)).catch(() => setVac([])) }, [oneFid, (units || []).join('|')])
  const openVac = vac.filter(v => v.open > 0)
  const [showRemoved, setShowRemoved] = useState(false)   // positions whose hiring was removed, greyed out
  const removedVac = vac.filter(v => v.removed && v.removed_open > 0).map(v => ({ ...v, open: v.removed_open }))
  const shownVac = showRemoved ? [...openVac, ...removedVac] : openVac
  const vacN = t => openVac.filter(v => !t || v.emp_type === t).reduce((a, v) => a + v.open, 0).toLocaleString('en-US')
  const vacK = k => openVac.filter(v => (v.kind === 'replacement' || v.kind === 'pending' ? v.kind : 'new') === k).reduce((a, v) => a + v.open, 0).toLocaleString('en-US')
  const vacMap = useMemo(() => {
    // where each open position sits: under the open position it reports to; if that one is filled, under the employee
    // who filled it; otherwise under its manager (the function head when the manager is not on show)
    const byId = new Map(vac.map(v => [v.id, v])), byMgr = new Map(), byParent = new Map()
    const add = (m, k, v) => m.set(k, [...(m.get(k) || []), v])
    if (!showTbh) return { byMgr, byParent }
    shownVac.forEach(v => {
      let p = v, n = 0
      while (p.parent_id && byId.has(p.parent_id) && n++ < 30) {
        const pv = byId.get(p.parent_id)
        if (pv.open > 0 || (showRemoved && pv.removed)) { add(byParent, pv.id, v); return }
        const who = [...(pv.filled_log || [])].reverse().find(x => x.code && O.byId.get(x.code))
        if (who) { add(byMgr, who.code, v); return }
        p = pv
      }
      add(byMgr, p.manager_code && O.byId.get(p.manager_code) ? p.manager_code : R1.id, v)
    })
    // employees who report to an open vacant position show under it
    const byVacEmp = new Map(), underVac = new Set()
    openVac.forEach(v => (v.reports || []).forEach(r => { const p = O.byId.get(r.code); if (p && O.counted(p)) { add(byVacEmp, v.id, p); underVac.add(p.id) } }))
    return { byMgr, byParent, byVacEmp, underVac }
  }, [vac, O, R1, showTbh, showRemoved])
  const orgTools = <span className="org-right">
        {canExport(user) && <button type="button" className="btn" onClick={() => { try { exportOrgHtml(O, { root: R1, title, vacancies: showTbh ? vacMap : null }); notify('Organogram saved as an HTML file.') } catch (e) { notify(e.message, true) } }}
          title="Save the organogram as one HTML file that opens in any browser: click to open teams, search, layers on the left">Export HTML</button>}
        {layOk && <button type="button" className={'btn bm-btn' + (layOn ? ' on' : '')} aria-pressed={layOn} onClick={() => setLayOn(!layOn)} title="Show the layers of the reporting line beside the chart">Layers</button>}
        {benchOk && <button type="button" className={'btn bm-btn' + (benchOn ? ' on' : '')} aria-pressed={benchOn} onClick={() => setBenchOn(!benchOn)} title="Colour every card by its grade against the max grade for its level">
          <span className="bm-key" />Grade Benchmark</button>}
        {single && <><span className="seg sm" role="group" aria-label="Organogram view">
          <button type="button" aria-pressed={orgView === 'line'} onClick={() => setOrgView('line')} title="Click anyone to see the line from the function head down to them and their team">Reporting Line</button>
          <button type="button" aria-pressed={orgView === 'teams'} onClick={() => setOrgView('teams')} title="Open several teams side by side">Open Teams</button></span>
        {(openVac.length > 0 || removedVac.length > 0) && <button type="button" className={'btn tbh-btn' + (showTbh ? ' on' : '')} aria-pressed={showTbh} onClick={() => setShowTbh(x => !x)}>
        <span className="vac-key" />{showTbh ? 'Hide' : 'Show'} To Be Hired ({vacN('')})</button>}
        {showTbh && removedVac.length > 0 && <button type="button" className={'btn' + (showRemoved ? ' on' : '')} aria-pressed={showRemoved} onClick={() => setShowRemoved(x => !x)}
          title="Positions whose hiring was removed, greyed out">{showRemoved ? 'Hide' : 'Show'} Hiring Removed ({removedVac.reduce((a, v) => a + v.open, 0)})</button>}</>}</span>
  // the layer panel beside the organogram (also inside the full-screen chart)
  const panel = layOk && layOn ? <LayerPanel org={O} p={fp || (selP && O.byId.get(selP)) || R1} user={user} notify={notify} onChanged={reloadOrg}
    onPick={x => {   // open the picked person's hierarchy in the chart
      setSelP(x.id)
      if (single && orgView === 'teams') setCroot(x === R1 ? null : x)
      else setFocusP(x === R1 ? null : x.id)
    }} /> : null
  return <section className="view on dash">
    <header className="pghead">
      <h1>{title}</h1>
      <div className="pg-side">
      {(org.excluded.length > 0 || org.resigned.length > 0) && <div className="exnote pg-side">
        {org.excluded.length > 0 && <span>{fmt(org.excluded.length)} Excluded{includeFlagged ? ' (Counted)' : ''}
          <button className="linkbtn" onClick={() => people('Excluded from Count', org.excluded, '', 'people')}>View</button>
          {setIncludeFlagged && <button className="linkbtn" onClick={() => setIncludeFlagged(!includeFlagged)}>{includeFlagged ? 'Do Not Count' : 'Count Them'}</button>}</span>}
        {org.resigned.length > 0 && <span>{fmt(org.resigned.length)} Resigned<button className="linkbtn" onClick={() => people('Resigned', org.resigned, '', 'people')}>View</button></span>}
      </div>}
      {oneFid && segs.find(s => s.function_id === oneFid) && <button type="button" className="btn pri" onClick={() => setSegOpen(true)}>{segs.find(s => s.function_id === oneFid).title}</button>}
      {user && user.can_bm_view && <button type="button" className="btn bm-btn" onClick={openFw} title="The grade benchmark framework: levels and max grades">View Benchmark</button>}
      {SHOW_SUMMARY && canExport(user) && <SummaryButton sel={sel} units={units} includeFlagged={includeFlagged} />}
      </div>
    </header>
    <div className={'kpis six' + (typeCards.length > 2 ? ' n' + (4 + typeCards.length) : '')}>
      <Kpi icon="people" label={L('dash.total')} value={fmt(C.length)} sub={fsorted.length > 1 ? `${fmt(fsorted.length)} Functions` : fsorted[0]?.name} onClick={() => people('Total Employees by Grade', C)} />
      {typeCards.map(t => <Kpi key={t.k} icon={t.icon} tone={t.tone || undefined} label={t.label} value={fmt(t.ps.length)} onClick={() => people(`${t.label} by Grade`, t.ps)}
        viz={<Ring value={pct(t.ps.length, C.length)} color={t.k === 'ftc' ? 'var(--ftc-ink)' : t.color} track={t.k === 'ftc' ? 'color-mix(in srgb, var(--ftc) 30%, var(--surface))' : undefined} />} />)}
      <Kpi icon="layers" label={L('dash.layers')} value={fmt(nLayers)} viz={<Steps n={nLayers} />} onClick={() => toggleSec('layers')} />
      <Kpi icon="managers" label={L('dash.managers')} value={fmt(mgrsAll.length)} sub={`Average Span ${fmt(Math.round(avgSpan))}`} onClick={() => people('Managers by Grade', mgrsAll, 'employees with direct reports', 'people')} />
      <Kpi icon="work" label={L('dash.svc')} value={<span className="kpi-pair"><span>{fmt(svcN)}</span><small>/</small><span>{fmt(supN)}</span></span>} onClick={() => toggleSec('work')}
        foot={<><Split parts={[{ v: svcN, color: TYPE_COL.Service, label: 'Service' }, { v: supN, color: TYPE_COL.Support, label: 'Support' }]} />
          <span className="klegend"><span><i style={{ background: TYPE_COL.Service }} />Service <b>{pcs(svcN, svcN + supN)}</b></span><span><i style={{ background: TYPE_COL.Support }} />Support <b>{pcs(supN, svcN + supN)}</b></span></span></>} />
    </div>

    <div className="seclaunch" role="group" aria-label="Dashboard sections">{SECTIONS.filter(([k]) => k !== 'bench' || benchOk).map(([k, l, d]) => <button key={k} type="button" aria-pressed={openSec === k} onClick={() => toggleSec(k)}>
      <i className="sl-dot" /><span><b>{L('sec.' + k)}</b></span><em className="sl-go">{openSec === k ? '–' : '+'}</em></button>)}</div>

    {openSec === 'org' && <Sec id="org" title={L('sec.org')}
      right={orgTools}>
      {bench && <BenchLegend counts={benchCounts} />}
      {showTbh && openVac.length > 0 && <div className="vac-note"><span className="vac-key" /><span><b>{vacN('')}</b> vacant / to be hired positions ({vacN('FTE')} FTE, {vacN('FTC')} FTC · {vacK('replacement')} {L('vac.repl')}, {vacK('new')} {L('vac.new')}{openVac.some(v => v.kind === 'pending') ? `, ${vacK('pending')} ${L('vac.pend')}` : ''})</span>
        <button className="linkbtn" onClick={() => setModal({ kind: 'vac' })}>View List</button></div>}
      <div className={layOk && layOn ? 'lp-wrap' : ''}>{layOk && layOn && panel}
      <div className="orgchart wide">{single && orgView === 'line'
        ? <Classic simple root={R1} top={R1} focus={fp} onFocus={p => setFocusP(p ? p.id : null)} org={O} theme={theme} largeTeam={40} onReroot={() => {}}
            onOpenList={x => people(`${x.n}: direct reports`, x.kids.filter(O.counted), '', 'people')} vacancies={vacMap} onVacancy={v => setModal({ kind: 'vacjd', v })} bench={bench} tools={orgTools} sums={sums} onSummary={p => setSumCode(p.id)} onSelect={p => setSelP(p.id)} side={panel} />
        : single
        ? <Classic root={(croot && O.byId.get(croot.id)) || R1} org={O} theme={theme} largeTeam={40} onReroot={p => { let x = R1; while (x) { if (x === p) { setCroot(null); return } x = x.m >= 0 ? O.P[x.m] : null } setCroot(p) }}
            onOpenList={x => people(`${x.n}: direct reports`, x.kids.filter(O.counted), '', 'people')} vacancies={vacMap} onVacancy={v => setModal({ kind: 'vacjd', v })} top={R1} bench={bench} tools={orgTools} sums={sums} onSummary={p => setSumCode(p.id)} onSelect={p => setSelP(p.id)} side={panel} />
        : <Classic simple root={R1} focus={fp} onFocus={p => setFocusP(p ? p.id : null)} org={O} theme={theme} largeTeam={40} onReroot={() => {}} onOpenList={x => people(`${x.n}: direct reports`, x.kids.filter(O.counted), '', 'people')} bench={bench} tools={orgTools} sums={sums} onSummary={p => setSumCode(p.id)} onSelect={p => setSelP(p.id)} side={panel} />}</div></div>
    </Sec>}

    {segOpen && oneFid && <SegModal fid={oneFid} notify={notify} onClose={() => setSegOpen(false)} />}
    {fw && <BenchFramework settings={fw.settings} ladder={fw.ladder} onClose={() => setFw(null)} />}
    {openSec === 'layers' && <Layers org={org} fsorted={fsorted} single={single} theme={theme} people={people} />}

    {openSec === 'work' && <Roles org={org} fsorted={fsorted} people={people} />}



    {openSec === 'acts' && <ActsSection sel={sel} units={units} includeFlagged={includeFlagged} theme={theme} />}
    {openSec === 'opps' && <OppsSection org={org} orgSpan={orgSpan} go={go} showLine={showLine} />}
    {sumCode && <SummaryModal code={sumCode} onClose={() => setSumCode(null)} />}
    {openSec === 'bench' && benchOk && <Sec id="bench" title={L('sec.bench')}><BenchSection sel={sel} user={user} showLine={showLine} /></Sec>}

    {modal?.kind === 'vac' && (() => {
      const tabs = [['replacement', L('vac.repl'), openVac.filter(v => v.kind === 'replacement')], ['new', L('vac.new'), openVac.filter(v => v.kind !== 'replacement' && v.kind !== 'pending')], ['pending', L('vac.pend'), openVac.filter(v => v.kind === 'pending')]].filter((t, i) => i < 2 || t[2].length)
      const tab = tabs.find(t => t[0] === (modal.tab || 'replacement')) || tabs[0]
      const n = rows => rows.reduce((a, v) => a + (v.open || 0), 0)
      return <Modal wide title="Vacant / To Be Hired Positions" sub={`${fsorted[0]?.name || ''} · not counted as employees`} onClose={() => setModal(null)}>
        <div className="tabs" style={{ marginBottom: 10 }}>{tabs.map(([k, t, rows]) => <button key={k} aria-current={tab[0] === k} onClick={() => setModal({ ...modal, tab: k })}>{t} ({fmt(n(rows)) === '-' ? 0 : fmt(n(rows))})</button>)}</div>
        <div className="tw scroll" style={{ maxHeight: 460 }}><table><thead><tr><th>Position</th><th>Vacancy</th><th>Reports To</th><th>Type</th><th>Grade</th><th>Unit</th><th className="num">{tab[0] === 'removed' ? 'Positions' : 'Open'}</th><th>{tab[0] === 'removed' ? 'Reason' : 'Note'}</th></tr></thead>
          <tbody>{tab[2].map(v => <tr key={v.id} className={'click' + (tab[0] === 'removed' ? ' vac-done' : '')} onClick={() => setModal({ kind: 'vacjd', v, back: true, tab: tab[0] })}><td><b>{v.position}</b>{v.jd && <div className="formula">View JD ›</div>}</td>
            <td><span className={'vk-pill ' + vacPillC(v.kind)}>{vacKindL(v.kind)}</span></td>
            <td>{v.parent_position ? `${v.parent_position} (vacant)` : v.manager_name || 'Function head'}</td><td>{v.emp_type}</td><td>{v.grade || '-'}</td><td>{v.unit || '-'}</td><td className="num">{fmt(v.open)}{v.filled && tab[0] !== 'removed' ? <div className="formula">{v.filled} of {v.count} filled</div> : null}</td><td className="formula">{tab[0] === 'removed' ? [v.removed_reason, v.removed_on].filter(Boolean).join(' · ') : v.note || ''}</td></tr>)}
            {!tab[2].length && <tr><td colSpan={8} className="formula">None.</td></tr>}</tbody></table></div></Modal>
    })()}
    {modal?.kind === 'vacjd' && <Modal title={modal.v.position} sub={['Vacant / to be hired', modal.v.emp_type, modal.v.grade, modal.v.unit].filter(Boolean).join(' · ')} onClose={() => setModal(modal.back ? { kind: 'vac', tab: modal.tab } : null)}>
      <div className="facts">
        <div><span>Reports To</span><b>{modal.v.parent_position ? `${modal.v.parent_position} (vacant)` : modal.v.manager_name || 'Function head'}</b></div>
        <div><span>Open Positions</span><b>{fmt(modal.v.open)}{modal.v.count > 1 ? ` of ${fmt(modal.v.count)}` : ''}</b></div>
        <div><span>Type</span><b>{modal.v.emp_type}</b></div>
      </div>
      <h3 style={{ margin: '14px 0 6px', fontSize: 15 }}>Job Description</h3>
      {modal.v.jd ? <div className="jd-text">{modal.v.jd}</div> : <p className="formula">No job description written yet. The admin adds it in Admin, Vacant Positions.</p>}
      {modal.v.note && <p className="formula" style={{ marginTop: 12 }}>Note: {modal.v.note}</p>}
    </Modal>}
    {modal?.kind === 'people' && <PeopleModal title={modal.title} sub={modal.sub} people={modal.list} F={F} heads={org.headIds} onPerson={openP} initial={modal.initial} onClose={() => setModal(null)} />}
  </section>
}

const SHOW_SUMMARY = false   // the one-page summary PDF button, hidden for now (set to true to show it)
// the one-page summary PDF of what is on show (the functions, units and the excluded setting of the dashboard)
function SummaryButton({ sel, units, includeFlagged }) {
  const [busy, setBusy] = useState(false)
  const go = async () => {
    const q = new URLSearchParams({ include_flagged: includeFlagged ? 'true' : 'false' })
    if (sel?.length) q.set('functions', sel.join(','))
    ;(units || []).forEach(u => q.append('units', u))
    setBusy(true)
    try { await download('/api/export/summary?' + q, 'summary.pdf') } catch (e) { alert(e.message) } finally { setBusy(false) }
  }
  return <button type="button" className="btn pg-sum" onClick={go} disabled={busy} title="One page with the headline figures, top activity themes, functions and structure findings">{busy ? 'Preparing…' : 'Summary PDF'}</button>
}

// executive view: the activity themes (or the main categories until themes are on), each with its activities and
// employees, for all activities or only volume based / non volume based ones; every bar opens its activities
const MAXT = 10
const share = (n, t) => !n || !t ? '-' : n / t < 0.01 ? '<1%' : Math.round(n / t * 100) + '%'
export function ActsSection({ sel, units, includeFlagged, theme, staff }) {   // staff: the HR Dashboard's wording (staff, not employees)
  const [vol, setVol] = useState('')
  const [et, setEt] = useState('')        // FTE / FTC filter
  const [open, setOpen] = useState(null)
  const [all, setAll] = useState(false)   // the pop-up with every theme (or category)
  const fq = `functions=${(sel || []).join(',')}&include_flagged=${includeFlagged}&emp_type=${et}&groups=true&limit=0${staff ? '&hr=true' : unitQS()}`
  const [d, dBusy] = useLive(() => Promise.all(['', '&volume=true', '&novolume=true'].map(x => api('/api/dashboard/activities?' + fq + x)))
    .then(([all, w, wo]) => ({ all, w, wo })).catch(() => ({ error: true })), [fq])
  const cur = !d || d.error ? null : vol === 'with' ? d.w : vol === 'without' ? d.wo : d.all
  const byTheme = !!cur && prefs.showThemes && (d.all.groups?.themes || []).some(t => t.name !== 'No Theme')
  const allRows = !cur ? [] : (byTheme ? cur.groups.themes : cur.groups.categories.filter(c => c.name !== 'Not categorised'))
  const rows = allRows.slice(0, MAXT)
  const nVol = d && !d.error ? d.w.total : 0, nAll = d && !d.error ? d.all.total : 0, nNo = nAll - nVol
  const vf = { ...(staff ? { hr: 'true' } : {}), ...(vol === 'with' ? { volume: 'true' } : vol === 'without' ? { novolume: 'true' } : {}), ...(et ? { emp_type: et } : {}) }
  const seg = <span className="dsec-right"><TypeFilter value={et} onChange={setEt} all={staff ? 'All Staff' : undefined} /><span className="seg sm" role="group">{[['', 'All Activities'], ['with', L('ins.volbased')], ['without', L('ins.nonvol')]].map(([k, l]) =>
    <button key={k} type="button" aria-pressed={vol === k} onClick={() => setVol(k)}>{l}</button>)}</span></span>
  const what = byTheme ? 'Themes' : 'Categories'
  return <Sec id="acts" title={L('dash.actshead')} right={seg} busy={dBusy && !!d}>
    {!d ? <div className="loading">Loading activities…</div> : d.error ? <div className="empty">Could not load the activities.</div> : !nAll ? <div className="empty">No activities recorded yet for this selection.</div> : <>
      <div className="ex-top" style={{ gridTemplateColumns: `repeat(3, minmax(120px, 1fr))${cur.groups.per_day > 0 ? ' minmax(230px, 1.5fr)' : ''}` }}>
        <div className="ex-fig"><span>{staff ? 'Staff' : L('ins.employees')}</span><b>{fmt(cur.groups.staff)}</b></div>
        <div className="ex-fig"><span>{L('ins.activities')}</span><b>{fmt(cur.total)}</b></div>
        <div className="ex-fig"><span>{byTheme ? L('ins.themes') : L('ins.categories')}</span><b>{fmt(byTheme ? cur.groups.themes.filter(t => t.name !== 'No Theme').length : cur.groups.categories.filter(c => c.name !== 'Not categorised').length)}</b></div>
        {cur.groups.per_day > 0 && <div className="ex-fig vol"><span>{L('ins.volume')}</span><VolPair total={cur.groups.per_day} file={cur.groups.file_per_day || 0} /></div>}
      </div>
      <div className="panel ex-panel">
        {!rows.length ? <p className="formula">No activities in this selection.</p> : <ExecRows rows={rows} showVol={cur.groups.per_day > 0} onPick={r => setOpen(r.name)} byTheme={byTheme} multi={(cur.groups.functions || []).length > 1} staff={staff} />}
        {allRows.length > MAXT && <div className="pfoot"><span className="formula">The {MAXT} largest of {fmt(allRows.length)} {what.toLowerCase()}.</span>
          <button type="button" className="linkbtn" onClick={() => setAll(true)}>View All {fmt(allRows.length)} {what} ›</button></div>}
      </div>
      {all && <Modal wide title={byTheme ? L('ins.themepanel') : 'Activity Categories'} sub={[`${fmt(allRows.length)} ${what.toLowerCase()}`, et, vol === 'with' ? L('ins.volbased') : vol === 'without' ? L('ins.nonvol') : ''].filter(Boolean).join(' · ')} onClose={() => setAll(false)}>
        <ExecRows rows={allRows} showVol={cur.groups.per_day > 0} onPick={r => { setAll(false); setOpen(r.name) }} byTheme={byTheme} multi={(cur.groups.functions || []).length > 1} staff={staff} /></Modal>}
      {open && <Modal wide title={open} sub={[et, vol === 'with' ? L('ins.volbased') : vol === 'without' ? L('ins.nonvol') : ''].filter(Boolean).join(' · ') || undefined} onClose={() => setOpen(null)}>
        <ThemeCatBrowser key={open + vol + et} filter={vf} sel={sel} includeFlagged={includeFlagged} initTheme={byTheme ? open : null} initCat={byTheme ? '*' : open} filterBar />
      </Modal>}
    </>}
  </Sec>
}

// one row per theme: activities, employees and average daily volume as bars on their own scales; the headings sort
function ExecRows({ rows, showVol, onPick, byTheme, multi, staff }) {
  const [by, setBy] = useState('staff')
  const list = [...rows].sort((a, b) => (b[by] || 0) - (a[by] || 0) || b.staff - a.staff || b.activities - a.activities)
  const mx = k => Math.max(1, ...rows.map(r => r[k] || 0))
  const ma = mx('activities'), ms = mx('staff'), mv = mx('per_day')
  const tot = rows.reduce((t, r) => t + (r.per_day || 0), 0)
  const H = ({ k, children }) => <button type="button" className={'ex-h' + (by === k ? ' on' : '')} onClick={() => setBy(k)}>{children}{by === k ? ' ▾' : ''}</button>
  return <div className={'ex-rows' + (showVol ? '' : ' novol') + (multi ? ' multi' : '')}>
    <div className="ex-row ex-head"><span className="ex-rank">#</span><span>{byTheme ? 'Activity Theme' : 'Activity Category'}</span>
      {multi && <H k="functions">Functions</H>}<H k="staff">{staff ? 'Staff' : 'Employees'} (FTE / FTC)</H><H k="activities">Activities</H>{showVol && <H k="per_day">Avg Daily Volume</H>}<span /></div>
    {list.map((r, i) => <button type="button" key={r.name} className="ex-row" onClick={() => onPick(r)}>
      <span className="ex-rank">{i + 1}</span>
      <span className="ex-name">{byTheme && <i style={{ background: themeColor(r.name) }} />}<b>{r.name}</b></span>
      {multi && <span className="ex-fn"><b>{fmt(r.functions)}</b></span>}
      <span className="ex-cell"><span className="ex-bar" title={`FTE ${r.fte_staff || 0} · FTC ${r.ftc_staff || 0}`}><i style={{ width: (r.fte_staff || 0) / ms * 100 + '%', background: 'var(--fte)' }} /><i style={{ width: (r.ftc_staff || 0) / ms * 100 + '%', background: 'var(--ftc)' }} /></span>
        <span className="ex-snums"><b>{fmt(r.staff)}</b><small>{r.fte_staff || 0} / {r.ftc_staff || 0}</small></span></span>
      <span className="ex-cell"><span className="ex-bar"><i style={{ width: r.activities / ma * 100 + '%', background: 'var(--x-act)' }} /></span><b>{fmt(r.activities)}</b></span>
      {showVol && <span className="ex-cell">{r.per_day > 0 ? <><span className="ex-bar">
        <i className="ex-vol" style={{ width: (r.per_day - (r.file_per_day || 0)) / mv * 100 + '%' }} />{r.file_per_day > 0 && <i className="ex-vfile" style={{ width: r.file_per_day / mv * 100 + '%' }} />}</span>
        <span className="ex-vnums">{r.per_day - (r.file_per_day || 0) > 0 && <span title={L('vol.txn')}><i className="t" />{vfmt(r.per_day - (r.file_per_day || 0))}</span>}
          {r.file_per_day > 0 && <span title={L('vol.file')}><i className="f" />{vfmt(r.file_per_day)}</span>}</span></> : <span className="ex-none">No volume</span>}</span>}
      <span className="ex-go">›</span></button>)}
  </div>
}

function OppsSection({ org, orgSpan, go, showLine }) {
  const [et, setEt] = useState('')
  const O = et && orgSpan ? orgSpan(et) : org
  return <Sec id="opps" title={L('dash.oppshead')} right={<TypeFilter value={et} onChange={setEt} />}>
    <Opportunities org={O} et={et} go={go} showLine={showLine} embedded />
  </Sec>
}

// ------------------------------------------------------------------ layers and spans
function Layers({ org, fsorted, single, theme, people }) {
  const { ROOT, F } = org
  const [et, setEt] = useState('')     // the function-wise layer table
  const [cet, setCet] = useState('')   // the span of control chart, filtered on its own
  const C = org.C.filter(byType(et))
  // span of control by type of direct report: with FTE or FTC selected, a manager's span counts only
  // their FTE or FTC direct reports, so it shows whether wide spans come from contract staff
  const reports = (m, t) => m.kids.filter(k => org.counted(k) && byType(t)(k)).length
  const sp = m => reports(m, et)
  const allM = org.MGR.filter(m => m !== ROOT && !m.ctx)
  const mgrs = allM.filter(m => sp(m) > 0)
  const avg = (ms, t) => { const x = ms.filter(m => reports(m, t) > 0); return x.length ? x.reduce((a, m) => a + reports(m, t), 0) / x.length : 0 }
  const fmg = f => mgrs.filter(m => m.f === f)
  const csp = m => reports(m, cet), cm = allM.filter(m => csp(m) > 0)
  const fspan = f => { const ms = fmg(f); return ms.length ? ms.reduce((t, m) => t + sp(m), 0) / ms.length : 0 }
  const wide = allM.filter(m => m.nk > 15), wideK = wide.reduce((a, m) => a + m.nk, 0), wideC = wide.reduce((a, m) => a + reports(m, 'FTC'), 0)
  const wideFteOk = wide.filter(m => reports(m, 'FTE') <= 15).length
  const depths = C.filter(p => p.ld >= 0).map(p => p.ld)
  const lo = Math.min(...depths, 1), hi = Math.max(...depths, 1)
  const LYR = []; for (let l = lo; l <= hi; l++) LYR.push(l)
  const cell = (f, l) => C.filter(p => p.f === f && p.ld === l)
  const hiL = row => { let h = -1; row.forEach((r, i) => { if (r.length) h = i }); return h >= 0 ? LYR[h] + 1 : 0 }   // the deepest layer in use
  const bins = [['1', 1, 1], ['2', 2, 2], ['3–5', 3, 5], ['6–10', 6, 10], ['11–15', 11, 15], ['16–30', 16, 30], ['31+', 31, 1e9]]
  const lname = l => l === 0 ? `Layer 1 (${short(ROOT.n, 18)})` : `Layer ${l + 1}`   // the Group Head is Layer 1
  return <Sec id="layers" title={L('dash.layerhead')}
    right={<TypeFilter value={et} onChange={setEt} />}>
    <div className="panel" style={{ padding: '10px 14px' }}><div className="tw"><table className="heat">
      <thead><tr><th>Function</th>{LYR.map(l => <th key={l} className="num">{'L' + (l + 1)}</th>)}<th className="num">Employees</th><th className="num">Layers</th><th className="num">{et ? `${et}'s Managers` : 'Managers'}</th><th className="num">{et ? `${et}'s Avg Span` : 'Avg Span'}</th></tr></thead>
      <tbody>{fsorted.length > 1 && <tr className="tot top"><td>Total</td>{LYR.map(l => { const r = C.filter(p => p.ld === l); return <td key={l} className="num">{r.length ? <button className="cellbtn" onClick={() => people(lname(l), r)}>{fmt(r.length)}</button> : ''}</td> })}
          <td className="num">{fmt(C.length)}</td><td className="num">{fmt(C.length ? Math.max(...C.map(p => p.ld)) + 1 : 0)}</td><td className="num">{fmt(mgrs.length)}</td><td className="num">{fmt(Math.round(mgrs.length ? mgrs.reduce((t, m) => t + sp(m), 0) / mgrs.length : 0))}</td></tr>}
        {fsorted.map(s => { const row = LYR.map(l => cell(s.f, l)); const mx = Math.max(1, ...row.map(r => r.length)); const used = hiL(row);   // the deepest layer of the function (the Group Head is Layer 1)
        const lo = row.findIndex(r => r.length), hi = row.length - 1 - [...row].reverse().findIndex(r => r.length)
        return <tr key={s.f}><td><span className="dot" style={{ background: org.FCOL[s.f] }} />{org.FT && org.FT[s.f] ? <span className="ft-type">{{ division: 'Function', department: 'Department', unit: 'Unit' }[org.FT[s.f]]}</span> : null}{s.name}</td>
          {row.map((r, i) => <td key={i} className={'num hc' + (r.length / mx > 0.6 ? ' dk' : '')} style={{ '--h': r.length ? 0.12 + 0.78 * r.length / mx : 0 }}>
            {r.length ? <button className="cellbtn" onClick={() => people(`${s.name}: ${lname(LYR[i])}`, r)}>{fmt(r.length)}</button> : i < hi ? <span className="dash">-</span> : ''}</td>)}
          <td className="num"><b>{fmt(C.filter(p => p.f === s.f).length)}</b></td><td className="num"><b>{fmt(used)}</b></td><td className="num">{fmt(fmg(s.f).length)}</td><td className="num">{fmt(Math.round(fspan(s.f)))}</td></tr> })}
      </tbody></table></div></div>
    <div className="grid" style={{ marginTop: 14 }}>
      <div className="panel"><div className="rhead"><h3>{L('dash.span')}{cet ? ` · ${cet} Direct Reports` : ''}</h3><TypeFilter value={cet} onChange={setCet} /></div>
        <ChartBox deps={[org, theme, cet]} config={() => ({ type: 'bar', plugins: [barValues], data: { labels: bins.map(b => b[0]), datasets: [{ data: bins.map(b => cm.filter(m => csp(m) >= b[1] && csp(m) <= b[2]).length), backgroundColor: bins.map((b, i) => i < 2 ? css('--amber') : i > 4 ? css('--coral') : css('--teal')), borderRadius: 5 }] },
          options: { onClick: (e, el) => { if (el.length) { const b = bins[el[0].index]; people(`Managers with ${b[0]} ${cet ? cet + ' ' : ''}direct reports`, cm.filter(m => csp(m) >= b[1] && csp(m) <= b[2]), '', 'people') } },
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => c.raw + ' managers' } } }, scales: { x: { title: { display: true, text: 'Direct Reports' }, grid: { display: false } }, y: { grace: '12%', title: { display: true, text: 'Managers' } } } } })} /></div>
    </div>
  </Sec>
}

// ------------------------------------------------------------------ service and support (the employee's type of work)
const ROLE_LABEL = { Service: 'Service Employees', Support: 'Support Employees', '': 'Not Yet Marked' }
function Roles({ org, fsorted, people }) {
  const [et, setEt] = useState('')
  // only employees marked Service or Support; those not yet marked are left out, so the two make 100%
  const C = org.C.filter(byType(et)).filter(p => TYPES.includes(p.st || ''))
  const groups = TYPES.map(t => ({ t, ps: C.filter(p => (p.st || '') === t) }))
  const n = C.length
  const scope = et === 'FTE' ? ' (FTE)' : et === 'FTC' ? ' (FTC)' : ''
  return <Sec id="work" title={L('sec.work')}
    right={<TypeFilter value={et} onChange={setEt} />}>
    <div className="panel roles">
      <div className="split big" role="img" aria-label="Service and support employees">{groups.map(g => g.ps.length ? <i key={g.t} style={{ width: g.ps.length / n * 100 + '%', background: TYPE_COL[g.t] }} title={`${ROLE_LABEL[g.t]}: ${g.ps.length}`} /> : null)}</div>
      <div className="rolefig r2">{groups.map(g => <button key={g.t} className="rf" style={{ '--tc': TYPE_COL[g.t] }} disabled={!g.ps.length}
        onClick={() => people(`${ROLE_LABEL[g.t]}${scope} by grade`, g.ps)}>
        <span className="rl"><i />{ROLE_LABEL[g.t]}{scope}</span><b>{fmt(g.ps.length)}</b><span className="rp">{pcs(g.ps.length, n)} of marked {et ? et + ' ' : ''}employees</span></button>)}</div>
    </div>
    {fsorted.length > 1 && <div className="panel" style={{ marginTop: 14 }}>
      <div className="rhead"><h3>By Function</h3><span className="legend">{TYPES.map(t => <span key={t}><i style={{ background: TYPE_COL[t] }} />{ROLE_LABEL[t]}</span>)}</span></div>
      <div className="tw"><table><thead><tr><th>Function</th><th className="num">Employees</th><th className="num">Service</th><th className="num">Support</th><th style={{ width: '30%' }}></th></tr></thead>
        <tbody><tr className="tot top"><td>Total</td><td className="num">{fmt(C.length)}</td>{TYPES.map(t => { const x = C.filter(p => (p.st || '') === t); return <td key={t} className="num">{x.length ? <button className="cellbtn" onClick={() => people(`${ROLE_LABEL[t]}${scope}`, x)}>{fmt(x.length)}</button> : '-'}</td> })}
          <td><div className="bar">{TYPES.map(t => <i key={t} style={{ width: pct(C.filter(p => (p.st || '') === t).length, C.length) + '%', background: TYPE_COL[t] }} />)}</div></td></tr>
        {fsorted.map(s => { const ps = C.filter(p => p.f === s.f)
          return <tr key={s.f}><td><span className="dot" style={{ background: org.FCOL[s.f] }} />{org.FT && org.FT[s.f] ? <span className="ft-type">{{ division: 'Function', department: 'Department', unit: 'Unit' }[org.FT[s.f]]}</span> : null}{s.name}</td><td className="num"><b>{fmt(ps.length)}</b></td>
            {TYPES.map(t => { const x = ps.filter(p => (p.st || '') === t); return <td key={t} className="num">{x.length ? <button className="cellbtn" onClick={() => people(`${s.name}: ${ROLE_LABEL[t]}${scope}`, x)}>{fmt(x.length)}</button> : '-'}</td> })}
            <td><div className="bar">{TYPES.map(t => <i key={t} style={{ width: pct(ps.filter(p => (p.st || '') === t).length, ps.length) + '%', background: TYPE_COL[t] }} />)}</div></td></tr> })}</tbody></table></div></div>}
  </Sec>
}

// ------------------------------------------------------------------ activities
