import React, { useEffect, useMemo, useState } from 'react'
import { api, download } from '../api.js'
import { buildOrg, fmt, pct, pcs, scopeData, TYPE_COL, unitData } from '../org.js'
import { L, vacKindL, vacPillC } from '../prefs.js'
import { Icon, Kpi, Modal, PeopleModal, Ring, Split, Steps, types, typeKey, typeName } from '../ui.jsx'
import { Classic, vacMapOf } from './Organogram.jsx'
import { ActsSection } from './Dashboard.jsx'
import { BenchFramework } from './Benchmark.jsx'

// The HR Dashboard: the restructure, As Is (the HR master file, which the admin can correct or replace) against To Be
// (the portal today). People added in the portal and resigned people are already reflected on both sides, so only the
// restructuring shows: layers, spans, functions, single-report managers, taggings and headcount saved.
const n1 = v => v === null || v === undefined ? '–' : Number(v).toLocaleString('en-US', { maximumFractionDigits: 1 })
const CHANGES = [
  ['line', 'Reporting line changes', 'mv'], ['function', 'Function changes', 'mv'], ['span', 'Span of control changes', 'mv'],
  ['layer', 'Layer changes', 'mv'], ['grade', 'Grade changes', 'mv'], ['title', 'Title changes', 'mv'],
  ['saved', 'Headcount saved', 'gone'], ['resigned', 'Resigned', 'gone'], ['removed', 'In As Is, not in the portal', 'gone'],
  ['added', 'Added (not in the As Is)', 'new'], ['tbh', 'Positions to be hired', 'new'],
]
const COLS = {   // the columns of each change list: [heading, field]
  line: [['As Is manager', 'frm'], ['To Be manager', 'to']], function: [['From', 'frm'], ['To', 'to']], span: [['As Is direct reports', 'frm'], ['To Be', 'to']],
  layer: [['As Is', 'frm'], ['To Be', 'to']], grade: [['From', 'frm'], ['To', 'to']], title: [['As Is title', 'frm'], ['To Be title', 'to']],
  saved: [['Reason', 'reason'], ['Date', 'date'], ['Direct reports (As Is)', 'reports']], resigned: [['Resigned on', 'date']],
  removed: [['As Is manager', 'frm']], added: [['Reports to', 'to'], ['Why', 'why']], tbh: [['Vacancy', 'kind'], ['Type', 'emp_type'], ['Open', 'count'], ['Reports to', 'to']],
  single: [['As Is direct reports', 'frm'], ['To Be direct reports', 'to']], fn_added: [['As Is people', 'frm'], ['To Be people', 'to']], fn_removed: [['As Is people', 'frm'], ['To Be people', 'to']],
  tagging: [['As Is', 'frm'], ['To Be', 'to']], bm_room: [['Level', 'level'], ['Max grade', 'max']], bm_at: [['Level', 'level'], ['Max grade', 'max']], bm_above: [['Level', 'level'], ['Max grade', 'max']],
  hiring_removed: [['Vacancy', 'kind'], ['Positions', 'count'], ['Reason', 'reason'], ['Removed on', 'date']],
  delayering: [['Layer', 'lay'], ['Direct reports (Current)', 'frm']], units: [['Unit', 'unit'], ['Current function', 'frm'], ['Proposed function', 'to'], ['Staff', 'staff']],
  exit: [['Reason', 'reason'], ['Date', 'date']], geo: [['Unit', 'unit'], ['Staff', 'staff'], [L('hr.cur'), 'frm'], [L('hr.pro'), 'to']], pr: [['Replacement position', 'to'], ['Replacement grade', 'to_grade']], trade: [],
  saved_all: [['Saved as', 'what'], ['Headcount', 'n'], ['Reason', 'reason'], ['Date', 'date']],
}

function ChangeList({ k, title, rows, onPerson, onClose, extra }) {
  const [q, setQ] = useState('')
  const ql = q.trim().toLowerCase()
  const sorted = rows.some(r => r.rank !== undefined) ? [...rows].sort((a, b) => (b.rank ?? -9) - (a.rank ?? -9)) : rows   // the highest grade first
  const list = sorted.filter(r => !ql || (r.name + ' ' + r.code + ' ' + r.function + ' ' + (r.frm || '') + ' ' + (r.to || '')).toLowerCase().includes(ql))
  const cols = COLS[k] || []
  return <Modal wide title={title} sub={k === 'units' ? `${fmt(rows.length)} units` : `${fmt(rows.length)} ${k === 'tbh' ? 'positions' : 'staff'}`} onClose={onClose}>
    {extra}
    <div className="kvline" style={{ marginBottom: 8 }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} /></div>
    <div className="tw scroll" style={{ maxHeight: 480 }}><table>
      <thead><tr><th>{k === 'tbh' ? 'Position' : k === 'saved_all' ? 'Staff / position' : 'Staff'}</th><th>Grade</th><th>Function</th>{cols.map(c => <th key={c[1]}>{c[0]}</th>)}</tr></thead>
      <tbody>{list.slice(0, 1000).map((r, i) => <tr key={r.code || i} className={r.code && onPerson ? 'click' : ''} onClick={r.code && onPerson ? () => onPerson(r) : undefined} title={r.code ? 'Show in the organograms' : ''}>
        <td><b>{r.name}</b>{r.code && <div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div>}</td><td>{r.grade}</td><td>{r.function}</td>
        {cols.map(c => <td key={c[1]} className={c[1] === 'to' && k === 'grade' ? (r.up ? 'ch-up' : 'ch-dn') : ''}>{String(r[c[1]] ?? '')}</td>)}</tr>)}
        {!list.length && <tr><td colSpan={3 + cols.length} className="formula">None.</td></tr>}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={() => {
      const csv = [[k === 'tbh' ? 'Position' : 'Employee', 'Code', 'Grade', 'Function', ...cols.map(c => c[0])], ...list.map(r => [r.name, r.code, r.grade, r.function, ...cols.map(c => r[c[1]] ?? '')])]
        .map(x => x.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n')
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' })); a.download = title + '.csv'; a.click()
    }}>Download List</button></div>
  </Modal>
}

// ---------------------------------------------------------------- vacant / to be hired positions, Replacement and New apart
function VacList({ tbh, onClose }) {
  const tabs = [['replacement', L('vac.repl'), tbh.filter(v => v.vk === 'replacement')], ['new', L('vac.new'), tbh.filter(v => v.vk !== 'replacement' && v.vk !== 'pending')], ['pending', L('vac.pend'), tbh.filter(v => v.vk === 'pending')]].filter((t, i) => i < 2 || t[2].length)
  const [tab, setTab] = useState(tabs[0][2].length || !tabs[1][2].length ? 'replacement' : 'new')
  const [q, setQ] = useState('')
  const cur = tabs.find(t => t[0] === tab)
  const ql = q.trim().toLowerCase()
  const rows = cur[2].filter(r => !ql || [r.name, r.function, r.to, r.unit, r.grade].join(' ').toLowerCase().includes(ql))
  const n = rs => rs.reduce((a, r) => a + (r.count || 0), 0)
  const rem = tab === 'removed'
  return <Modal wide title="Vacant / To Be Hired Positions" sub="To Be · not counted as employees" onClose={onClose}>
    <div className="tabs" style={{ marginBottom: 10 }}>{tabs.map(([k, t, rs]) => <button key={k} aria-current={tab === k} onClick={() => setTab(k)}>{t} ({fmt(n(rs)) === '-' ? 0 : fmt(n(rs))})</button>)}</div>
    <div className="kvline" style={{ marginBottom: 8 }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} /></div>
    <div className="tw scroll" style={{ maxHeight: 440 }}><table>
      <thead><tr><th>Position</th><th>Vacancy</th><th>Function</th><th>Reports To</th><th>Type</th><th>Grade</th><th className="num">{rem ? 'Positions' : 'Open'}</th><th>{rem ? 'Reason' : 'Note'}</th></tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i} className={rem ? 'vac-done' : ''}><td><b>{r.name}</b>{r.unit && <div className="formula">{r.unit}</div>}</td>
        <td><span className={'vk-pill ' + vacPillC(r.vk)}>{vacKindL(r.vk)}</span></td>
        <td>{r.function}</td><td>{r.to || 'Function head'}</td><td>{r.emp_type}</td><td>{r.grade || '-'}</td><td className="num">{fmt(r.count)}</td>
        <td className="formula">{rem ? [r.reason, r.date].filter(Boolean).join(' · ') : r.note || ''}</td></tr>)}
        {!rows.length && <tr><td colSpan={8} className="formula">None.</td></tr>}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={() => {
      const csv = [['Position', 'Vacancy', 'Function', 'Reports To', 'Type', 'Grade', rem ? 'Positions' : 'Open', rem ? 'Reason' : 'Note'], ...rows.map(r => [r.name, vacKindL(r.vk), r.function, r.to, r.emp_type, r.grade, r.count, rem ? [r.reason, r.date].filter(Boolean).join(' · ') : r.note || ''])]
        .map(x => x.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n')
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' })); a.download = cur[1] + ' positions.csv'; a.click()
    }}>Download List</button></div>
  </Modal>
}

// ---------------------------------------------------------------- the As Is data: corrections and a new HR file
// search the As Is (Current State) by name, code or position and pick one person
function AsIsPick({ value, valueName, onPick, exclude, placeholder }) {
  const [q, setQ] = useState('')
  const [res, setRes] = useState([])
  const [open, setOpen] = useState(false)
  useEffect(() => {
    if (q.trim().length < 2) { setRes([]); return }
    const t = setTimeout(() => api(`/api/chro/asis?q=${encodeURIComponent(q)}`).then(d => setRes(d.rows.filter(r => r.code !== exclude).slice(0, 8))).catch(() => setRes([])), 250)
    return () => clearTimeout(t)
  }, [q])
  return <div className="cm-pick">
    <input className="inp" value={open ? q : (value ? `${valueName || value} · ${value}` : '')} placeholder={placeholder || 'Search by name, code or position'}
      onFocus={() => { setOpen(true); setQ('') }} onBlur={() => setTimeout(() => setOpen(false), 180)} onChange={e => setQ(e.target.value)} />
    {open && res.length > 0 && <div className="cm-res">{res.map(r => <button key={r.code} type="button" onMouseDown={() => { onPick(r); setOpen(false) }}>
      <b>{r.name}</b><span>{[r.position, r.grade, r.function, r.code].filter(Boolean).join(' · ')}</span></button>)}</div>}
  </div>
}

// Admin → Current State Line Managers: change who someone reports to in the Current State (As Is) only, without
// editing the HR file. The Proposed State and the rest of the portal do not change.
export function CurrentManagersTab({ notify }) {
  const [emp, setEmp] = useState(null)
  const [mgr, setMgr] = useState(null)
  const [note, setNote] = useState('')
  const [takeFn, setTakeFn] = useState(true)
  const [teamToo, setTeamToo] = useState(false)   // their direct reports report to the new manager too
  const [pt, setPt] = useState(null)               // their direct reports in the portal: [{code, name, ...}]
  const [bring, setBring] = useState(new Set())    // the ones to bring along (with their teams), as in the portal
  useEffect(() => { setPt(null); setBring(new Set()); if (!emp) return
    api('/api/chro/asis/' + encodeURIComponent(emp.code) + '/portal-team').then(r => setPt(r)).catch(() => setPt([])) }, [emp?.code])
  useEffect(() => { if (pt) setBring(new Set(pt.filter(r => r.in_hr_team || !mgr || r.hr_manager_code !== mgr.code).map(r => r.code))) }, [pt, mgr?.code])   // a manager in another function: take their function, with the team
  const [d, setD] = useState(null)
  const otherFn = emp && mgr && mgr.function && mgr.function !== emp.function
  const load = () => api('/api/chro/asis?show=moved').then(setD).catch(e => notify(e.message, true))
  useEffect(load, [])
  const save = async () => {
    if (!emp || !mgr) return
    try {
      await api('/api/chro/asis/' + encodeURIComponent(emp.code), { method: 'PATCH', body: { manager_code: mgr.code, ...(note.trim() ? { note } : {}), ...(otherFn && takeFn ? { function: mgr.function, team_function: true } : {}), ...(teamToo && emp.directs ? { team_too: true } : {}), ...(pt && pt.length ? { bring: [...bring] } : {}) } })
      notify(`${emp.name} now reports to ${mgr.name} in the Current State${teamToo && emp.directs ? `, with their ${emp.directs} direct reports` : ''}${otherFn && takeFn ? ` (${mgr.function})` : ''}.`); setEmp(null); setMgr(null); setNote(''); setTakeFn(true); setTeamToo(false); load()
    } catch (e) { notify(e.message, true) }
  }
  const undo = async r => {
    try { await api('/api/chro/asis/' + encodeURIComponent(r.code) + '/undo-manager', { method: 'POST' }); notify(`${r.name}: back to the HR file's line manager.`); load() } catch (e) { notify(e.message, true) }
  }
  const m = d?.meta || {}
  return <div>
    <p className="formula" style={{ marginTop: 0 }}>Change a line manager in the Current State of the Dashboard (HR Dashboard) without editing the HR file. It changes only the Current State: the Proposed State and the rest of the portal stay as they are. Current State: {m.file || 'HR master file'}{m.loaded_at ? ' · loaded ' + m.loaded_at : ''}. Uploading a new HR file, or rebuilding from the database, clears these changes.</p>
    <div className="ch-card" style={{ marginBottom: 14 }}>
      <h3 style={{ marginTop: 0 }}>Change a line manager</h3>
      <div className="cm-form">
        <label className="fld"><span className="fl">Employee</span><AsIsPick value={emp?.code} valueName={emp?.name} onPick={r => setEmp(r)} /></label>
        <label className="fld"><span className="fl">Current line manager</span><input className="inp" disabled value={emp ? (emp.manager_name ? `${emp.manager_name} · ${emp.manager_code}` : emp.manager_code || '–') : ''} /></label>
        <label className="fld"><span className="fl">New line manager</span><AsIsPick value={mgr?.code} valueName={mgr?.name} exclude={emp?.code} onPick={r => setMgr(r)} /></label>
        <label className="fld"><span className="fl">Note</span><input className="inp" value={note} onChange={e => setNote(e.target.value)} placeholder="Optional" /></label>
      </div>
      <div className="row-actions" style={{ marginTop: 10, justifyContent: 'flex-end', gap: 8 }}>
        <button className="btn" onClick={() => { setEmp(null); setMgr(null); setNote('') }}>Clear</button>
        <button className="btn pri" disabled={!emp || !mgr} onClick={save}>Save</button></div>
      {emp && mgr && emp.directs > 0 && <label style={{ display: 'flex', gap: 8, alignItems: 'flex-start', fontSize: 13.5, marginTop: 8 }}><input type="checkbox" checked={teamToo} onChange={e => setTeamToo(e.target.checked)} />
        <span>Whole team: {emp.name}'s {fmt(emp.directs)} direct report{emp.directs === 1 ? '' : 's'} also report to <b>{mgr.name}</b> in the Current State<br /><span className="formula">For a flat HR file: the team sits beside them under {mgr.name}. The Proposed State does not change. Undo puts the team back under {emp.name}.</span></span></label>}
      {pt && pt.length > 0 && <div className="cm-bring"><b>Bring their team as in the portal</b><span className="formula" style={{ margin: 0 }}> (each with everyone below them; unticked ones stay where the HR file has them)</span>
        <div className="cm-bl">{pt.map(r => <label key={r.code}><input type="checkbox" checked={bring.has(r.code)} onChange={e => setBring(s => { const n = new Set(s); e.target.checked ? n.add(r.code) : n.delete(r.code); return n })} />
          <span><b>{r.name}</b>{r.team ? ` · team ${r.team}` : ''}<small>HR file: {r.in_hr_team ? 'already in their team' : `${r.hr_manager || '–'}${r.hr_function ? ' · ' + r.hr_function : ''}`}</small></span></label>)}</div></div>}
      {otherFn && <label style={{ display: 'flex', gap: 8, alignItems: 'flex-start', fontSize: 13.5, marginTop: 8 }}><input type="checkbox" checked={takeFn} onChange={e => setTakeFn(e.target.checked)} />
        <span>Move {emp.name} and their team (as in the portal) to <b>{mgr.function}</b> in the Current State (now <b>{emp.function || '–'}</b>)<br /><span className="formula">Needed for Unit Transition Opportunity: it lists heads whose function in the Current State differs from the Proposed State.</span></span></label>}
      {!teamToo && <p className="formula" style={{ marginBottom: 0 }}>Their own team stays under them.</p>}
    </div>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}><h3>Line managers changed ({d?.rows?.length || 0})</h3>
      {d?.rows?.length > 0 && <button className="btn" onClick={async () => {
        if (!window.confirm('Undo every line manager change and function move made here? The Current State goes back to the HR file.')) return
        try { const r = await api('/api/chro/asis/undo-all', { method: 'POST' }); notify(`${r.rows} changes undone: the Current State is as in the HR file.`); load() } catch (e) { notify(e.message, true) }
      }}>Undo All</button>}</div>
    <div className="tw"><table>
      <thead><tr><th>Employee</th><th>Function (Current State)</th><th>HR file line manager</th><th>Current State line manager</th><th>Changed</th><th></th></tr></thead>
      <tbody>{(d?.rows || []).map(r => <tr key={r.code}>
        <td><b>{r.name}</b><div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div></td><td>{r.function}</td>
        <td>{r.orig_manager_name || r.orig_manager_code || '–'}</td><td><b>{r.manager_name || r.manager_code || '–'}</b></td>
        <td>{r.edited_by}{r.edited_at ? ' · ' + r.edited_at : ''}{r.note ? <div className="formula">{r.note}</div> : null}</td>
        <td><button className="linkbtn" onClick={() => undo(r)}>Undo</button></td></tr>)}
        {d && !d.rows.length && <tr><td colSpan={6} className="formula">No line manager changed yet.</td></tr>}</tbody></table></div>
  </div>
}

function AsIsData({ notify, canEdit, onChanged, onClose }) {
  const [d, setD] = useState(null)
  const [q, setQ] = useState('')
  const [show, setShow] = useState('')
  const [ed, setEd] = useState(null)   // the row being edited / added
  const [up, setUp] = useState(null)   // {file, rep}
  const load = () => api(`/api/chro/asis?q=${encodeURIComponent(q)}&show=${show}`).then(setD).catch(e => notify(e.message, true))
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [q, show])
  const save = async () => {
    try {
      const body = { name: ed.name, grade_raw: ed.grade_raw, position: ed.position, function: ed.function, manager_code: ed.manager_code, emp_type: ed.emp_type, kind: ed.kind, unit: ed.unit, note: ed.note, ...(ed.withTeam !== false && !ed.isNew ? { team_function: true } : {}) }
      if (ed.isNew) await api('/api/chro/asis', { method: 'POST', body: { code: ed.code, ...body } })
      else await api('/api/chro/asis/' + encodeURIComponent(ed.code), { method: 'PATCH', body })
      notify(ed.isNew ? 'Added to the As Is.' : 'As Is corrected.'); setEd(null); load(); onChanged()
    } catch (e) { notify(e.message, true) }
  }
  const remove = async r => {
    if (!window.confirm(`Remove ${r.name} from the As Is? Their team in the As Is will report to their manager.`)) return
    try { await api('/api/chro/asis/' + encodeURIComponent(r.code), { method: 'DELETE' }); notify('Removed from the As Is.'); setEd(null); load(); onChanged() } catch (e) { notify(e.message, true) }
  }
  const upload = async (file, dry) => {
    const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false')
    try {
      const rep = await api('/api/chro/asis/upload', { method: 'POST', form: fd })
      if (dry) setUp({ file, rep }); else { setUp(null); notify(`As Is replaced: ${fmt(rep.rows)} employees from ${file.name}.`); load(); onChanged() }
    } catch (e) { notify(e.message, true) }
  }
  const reset = async () => {
    if (!window.confirm('Rebuild the As Is from the database (the HR master file imported in Admin)? An uploaded HR file stops being used and every correction made here is lost.')) return
    try { const r = await api('/api/chro/asis/reset', { method: 'POST' }); notify(`As Is rebuilt: ${fmt(r.rows)} employees.`); load(); onChanged() } catch (e) { notify(e.message, true) }
  }
  const m = d?.meta || {}
  return <Modal wide title="As Is Data" sub={d ? `${m.file || 'HR master file'} · ${fmt(d.total)} employees${d.edited ? ` · ${fmt(d.edited)} corrected or added` : ''}${m.loaded_at ? ' · loaded ' + m.loaded_at : ''}` : ''} onClose={onClose}>
    <p className="formula" style={{ marginTop: 0 }}>The As Is is used only on this dashboard. {m.source === 'upload' ? 'It comes from an HR file uploaded for this dashboard.' : 'It comes from the database: each employee as in the HR master file imported in Admin (HR manager, function, grade and position), and it follows a new import there.'} Correcting it, or replacing it with a new HR file, does not change anything else in the portal.</p>
    {canEdit && <div className="row-actions" style={{ gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
      <label className="btn pri" style={{ cursor: 'pointer' }}>Upload New HR File<input type="file" accept=".xlsx" hidden onChange={e => { const f = e.target.files[0]; e.target.value = ''; if (f) upload(f, true) }} /></label>
      <button className="btn" onClick={() => setEd({ isNew: true, code: '', name: '', grade_raw: '', position: '', function: '', manager_code: '', emp_type: 'FTE', kind: '', unit: '', note: '' })}>Add Missing Employee</button>
      <button className="btn" onClick={() => download('/api/chro/asis/export', 'As Is.xlsx').catch(e => notify(e.message, true))}>Export As Is (Excel)</button>
      <button className="btn" onClick={reset}>Use Database (rebuild)</button></div>}
    {up && <div className="ch-card" style={{ marginBottom: 10, borderColor: 'var(--amber)' }}>
      <b>{up.file.name}</b>: {fmt(up.rep.rows)} employees. {fmt(up.rep.new_vs_current_as_is)} not in the current As Is, {fmt(up.rep.dropped_vs_current_as_is)} of the current As Is not in the file; {fmt(up.rep.not_in_portal)} not in the portal.
      <div className="row-actions" style={{ marginTop: 8, gap: 8 }}><button className="btn pri" onClick={() => upload(up.file, false)}>Replace the As Is</button><button className="btn" onClick={() => setUp(null)}>Cancel</button></div></div>}
    {ed && <div className="ch-card" style={{ marginBottom: 10 }}><h3>{ed.isNew ? 'Add a missing employee' : `Correct ${ed.name}`}</h3>
      <div className="ch-form">
        <label className="fld"><span className="fl">Employee code</span><input className="inp" value={ed.code} disabled={!ed.isNew} onChange={e => setEd({ ...ed, code: e.target.value })} placeholder="A portal code fills the rest" /></label>
        <label className="fld"><span className="fl">Name</span><input className="inp" value={ed.name} onChange={e => setEd({ ...ed, name: e.target.value })} /></label>
        <label className="fld"><span className="fl">Grade (as in the HR file)</span><input className="inp" value={ed.grade_raw} onChange={e => setEd({ ...ed, grade_raw: e.target.value })} placeholder="e.g. 068-SM I" /></label>
        <label className="fld"><span className="fl">Position</span><input className="inp" value={ed.position} onChange={e => setEd({ ...ed, position: e.target.value })} /></label>
        <label className="fld"><span className="fl">Function</span><input className="inp" list="ch-fns" value={ed.function} onChange={e => setEd({ ...ed, function: e.target.value })} />
          {!ed.isNew && <span style={{ display: 'flex', gap: 6, alignItems: 'center', fontSize: 12, marginTop: 4 }}><input type="checkbox" checked={ed.withTeam !== false} onChange={e => setEd({ ...ed, withTeam: e.target.checked })} />Their team (same function) too</span>}</label>
        <label className="fld"><span className="fl">Line manager (N-1)</span><AsIsPick value={ed.manager_code} valueName={ed.manager_name} exclude={ed.code} onPick={r => setEd({ ...ed, manager_code: r.code, manager_name: r.name })} /></label>
        <label className="fld"><span className="fl">Type</span><select className="inp" value={ed.kind || ed.emp_type} onChange={e => { const v = e.target.value; setEd({ ...ed, emp_type: v === 'FTC' || v === 'dw' ? 'FTC' : 'FTE', kind: v === 'dc' || v === 'dw' ? v : '' }) }}>
          <option value="FTE">FTE</option><option value="dc">{L('dash.dc')}</option><option value="FTC">FTC</option><option value="dw">{L('dash.dw')}</option></select></label>
        <label className="fld"><span className="fl">Unit</span><input className="inp" value={ed.unit} onChange={e => setEd({ ...ed, unit: e.target.value })} /></label>
        <label className="fld" style={{ gridColumn: 'span 3' }}><span className="fl">Note</span><input className="inp" value={ed.note} onChange={e => setEd({ ...ed, note: e.target.value })} placeholder="Why it was corrected" /></label>
      </div>
      <datalist id="ch-fns">{(d?.functions || []).map(f => <option key={f} value={f} />)}</datalist>
      <div className="row-actions" style={{ marginTop: 10, justifyContent: 'space-between' }}>
        <span>{!ed.isNew && <button className="linkbtn" onClick={() => remove(ed)}>Remove from As Is</button>}</span>
        <span style={{ display: 'flex', gap: 8 }}><button className="btn" onClick={() => setEd(null)}>Cancel</button><button className="btn pri" onClick={save}>Save</button></span></div></div>}
    <div className="kvline" style={{ marginBottom: 8 }}>
      <input className="inp" placeholder="Search by name, code or position" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} />
      <select className="inp" value={show} onChange={e => setShow(e.target.value)} style={{ maxWidth: 200 }}><option value="">Everyone</option><option value="edited">Corrected</option><option value="added">Added</option><option value="moved">Line manager changed</option></select></div>
    <div className="tw scroll" style={{ maxHeight: 400 }}><table>
      <thead><tr><th>Employee</th><th>Grade</th><th>Function</th><th>Manager (As Is)</th><th>Source</th></tr></thead>
      <tbody>{(d?.rows || []).map(r => <tr key={r.code} className={canEdit ? 'click' : ''} onClick={canEdit ? () => setEd({ ...r }) : undefined} title={canEdit ? 'Correct' : ''}>
        <td><b>{r.name}</b><div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div></td><td>{r.grade}</td><td>{r.function}</td>
        <td>{r.manager_name || r.manager_code || '–'}</td><td>{r.source === 'file' ? 'HR file' : r.source === 'added' ? <span className="pill p-ok">Added</span> : <span className="pill p-warn" title={r.note}>Corrected</span>}</td></tr>)}
        {d && d.rows.length >= 400 && <tr><td colSpan={5} className="formula">The first 400 are shown. Search to narrow down.</td></tr>}</tbody></table></div>
  </Modal>
}

// ---------------------------------------------------------------- the page
const nz = v => { const x = fmt(v || 0); return x === '-' ? '0' : x }
const delta = (a, b) => { const d = (b || 0) - (a || 0); return d === 0 ? '' : (d > 0 ? '+' : '−') + nz(Math.abs(d)) }

// the proposed figure under the current one (Proposed State): the value and the change
// the Proposed State figure beside the current one, so the two compare at a glance
const XC = { fte: '#00796B', dc: '#C98A00', ftc: '#6FBFB3', dw: '#8E6BB0' }   // staff type colours on the dark figure tiles
// a figure: the value shown (Proposed State: the proposed one), with the current figure and the change beneath
const dd = v => (v ? nz(v) : '–')   // figure tiles: a dash instead of 0
function Fig({ a, b, pro, big, onDiff }) {
  const d = (b || 0) - (a || 0)
  return <span className={'fig' + (big ? ' big' : '')}><b>{dd(b)}</b>
    {pro && <span className="fig-d">Current {dd(a)}{d !== 0 && (onDiff
      ? <em role="button" tabIndex={0} title="Who changed" className={(d < 0 ? 'dn' : 'up') + ' click'} onClick={e => { e.stopPropagation(); onDiff() }}>{d < 0 ? '▼' : '▲'} {nz(Math.abs(d))} ›</em>
      : <em className={d < 0 ? 'dn' : 'up'}>{d < 0 ? '▼' : '▲'} {nz(Math.abs(d))}</em>)}</span>}</span>
}
// who makes the difference between the Current and the Proposed State figure (in / out of the function or type on show)
function DiffList({ diff, onClose }) {
  return <Modal wide title={diff.title} sub={`${diff.rows.filter(r => r.in).length} in · ${diff.rows.filter(r => !r.in).length} out`} onClose={onClose}>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr><th>Staff</th><th>Grade</th><th></th><th>Why</th></tr></thead>
      <tbody>{diff.rows.map(r => <tr key={r.code + (r.in ? 'i' : 'o')}><td><b>{r.name}</b><div className="formula">{[r.pos, r.code].filter(Boolean).join(' · ')}</div></td><td>{r.grade || '–'}</td>
        <td><span className={'pill ' + (r.in ? 'p-ok' : 'p-warn')}>{r.in ? 'In' : 'Out'}</span></td><td>{r.why}</td></tr>)}
        {!diff.rows.length && <tr><td colSpan={4} className="formula">None.</td></tr>}</tbody></table></div>
  </Modal>
}
function Cmp({ a, b, big }) {
  const d = (b || 0) - (a || 0)
  return <span className={'cmp' + (big ? ' big' : '')}>
    <span className="cmp-c"><i>Current</i><b>{nz(a)}</b></span><span className="cmp-ar">→</span>
    <span className="cmp-p"><i>Proposed</i><b>{nz(b)}</b></span>{d !== 0 && <em className={d < 0 ? 'dn' : 'up'}>{d < 0 ? '▼' : '▲'} {nz(Math.abs(d))}</em>}</span>
}

function Pp({ a, b, sm, full }) {
  const d = (b || 0) - (a || 0)
  return <span className={'hxk-pp' + (sm ? ' sm' : '')}><i>{full ? L('hr.pro') : 'Proposed'}</i><b>{nz(b)}</b>{d !== 0 && <em className={d < 0 ? 'dn' : 'up'}>{d < 0 ? '▼' : '▲'} {nz(Math.abs(d))}</em>}</span>
}

const REPL_TABS = [['normal', 'Normal Replacement', 'Resigned staff replacement'], ['special', 'Special Replacement', 'Surrendered staff replacement']]
function ReplList({ repl, initial, onClose }) {
  const [tab, setTab] = useState(initial || 'normal')
  const rows = repl[tab] || []
  const staffCol = tab !== 'normal'
  return <Modal wide title={L('hr.repl')} sub={(REPL_TABS.find(t => t[0] === tab) || [])[2]} onClose={onClose}>
    <div className="tabs" style={{ marginBottom: 10 }}>{REPL_TABS.map(([k, t]) => <button key={k} aria-current={tab === k} onClick={() => setTab(k)}>{t} ({nz(repl['n_' + k])})</button>)}</div>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr>{staffCol && <><th>Staff</th><th>Staff Grade</th></>}<th>Position</th><th>Grade</th><th>Function</th><th>Reports To</th><th>Type</th><th className="num">Positions</th></tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i}>{staffCol && <><td><b>{r.staff}</b>{r.pr && <span className="pr-tag">PR</span>}<div className="formula">{[r.staff_position, r.staff_code].filter(Boolean).join(' · ')}</div></td><td>{r.staff_grade}</td></>}
        <td><b>{r.name}</b></td><td>{r.grade || '-'}</td><td>{r.function}</td><td>{r.to || '-'}</td><td>{r.emp_type}</td><td className="num">{nz(r.count)}</td></tr>)}
        {!rows.length && <tr><td colSpan={staffCol ? 8 : 6} className="formula">None.</td></tr>}</tbody></table></div>
  </Modal>
}

function NewList({ rows, onClose, title }) {
  return <Modal wide title={title || L('hr.new')} onClose={onClose}>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr><th>Position</th><th>Grade</th><th>Function</th><th>Reports To</th><th>Type</th><th className="num">Positions</th><th>Note</th></tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i}><td><b>{r.name}</b>{r.unit && <div className="formula">{r.unit}</div>}</td><td>{r.grade || '-'}</td><td>{r.function}</td><td>{r.to || '-'}</td><td>{r.emp_type}</td><td className="num">{nz(r.count)}</td><td className="formula">{r.note}</td></tr>)}
        {!rows.length && <tr><td colSpan={7} className="formula">None.</td></tr>}</tbody></table></div>
  </Modal>
}

// Trade Staff Realignment: the function the card shows for (administrators)
function TradeFnPick({ cur, fns, notify, onSaved }) {
  const [v, setV] = useState(cur || '')
  const save = async () => { try { await api('/api/chro/trade-function', { method: 'PUT', body: { name: v } }); notify('Saved.'); onSaved() } catch (e) { notify(e.message, true) } }
  return <div className="kvline" style={{ marginBottom: 10, gap: 8, alignItems: 'center' }}>
    <span className="formula" style={{ margin: 0 }}>Card shown for Operations Services and</span>
    <select className="inp" value={v} onChange={e => setV(e.target.value)} style={{ maxWidth: 340 }}>
      <option value="">Functions named "Trade…"</option>{[...fns].sort().map(f => <option key={f} value={f}>{f}</option>)}</select>
    <button className="btn pri" disabled={v === (cur || '')} onClick={save}>Save</button></div>
}

// Layers: span of control, Current → Proposed. Managers whose direct reports changed (a team moved from one manager
// to another without a change of unit or layer), at a glance, with the details behind each figure.
const spanOf = f => { const m = f?.mgrs || []; return m.length ? m.reduce((a, p) => a + p.nk, 0) / m.length : 0 }
function SpanStrip({ fa, fb, rows, onOpen }) {
  const up = rows.filter(r => r.to > r.frm), dn = rows.filter(r => r.to < r.frm)
  const sa = spanOf(fa), sb = spanOf(fb), d = Math.round((sb - sa) * 10) / 10
  const n1 = v => v ? v.toLocaleString('en-US', { maximumFractionDigits: 1, minimumFractionDigits: 1 }) : '–'
  return <div className="spn">
    <div className="spn-t"><span className="spn-h">Span of Control</span><span className="formula" style={{ margin: 0 }}>Current → Proposed</span></div>
    <div className="spn-g">
      <button type="button" className="spn-k" onClick={() => onOpen('all')}><span>Line Managers</span><b>{nz((fa?.mgrs || []).length)} → {nz((fb?.mgrs || []).length)}</b></button>
      <button type="button" className="spn-k" disabled={!up.length} onClick={() => onOpen('up')}><span>Span Increased</span><b>{up.length ? nz(up.length) : '–'}</b>{up.length > 0 && <small>managers · +{nz(up.reduce((a, r) => a + r.to - r.frm, 0))} direct reports</small>}</button>
      <button type="button" className="spn-k" disabled={!dn.length} onClick={() => onOpen('down')}><span>Span Reduced</span><b>{dn.length ? nz(dn.length) : '–'}</b>{dn.length > 0 && <small>managers · −{nz(dn.reduce((a, r) => a + r.frm - r.to, 0))} direct reports</small>}</button>
    </div></div>
}
function SpanList({ rows, initial, onClose }) {
  const [tab, setTab] = useState(initial === 'all' ? 'up' : initial)
  const [q, setQ] = useState('')
  const tabs = [['up', 'Span Increased', rows.filter(r => r.to > r.frm)], ['down', 'Span Reduced', rows.filter(r => r.to < r.frm)]]
  const cur = (tabs.find(t => t[0] === tab) || tabs[0])[2].filter(r => !q.trim() || (r.name + ' ' + r.function).toLowerCase().includes(q.trim().toLowerCase()))
    .sort((a, b) => (b.root ? 1 : 0) - (a.root ? 1 : 0) || (b.top ? 1 : 0) - (a.top ? 1 : 0) || b.to - a.to || (b.rank ?? -9) - (a.rank ?? -9))   // the top person's direct reports first, then the most direct reports
  return <Modal wide title="Span of Control: Current → Proposed" sub={tab === 'up' ? 'Managers whose direct reports increased · Proposed includes their open vacant positions' : 'Managers whose direct reports reduced'} onClose={onClose}>
    <div className="tabs" style={{ marginBottom: 10 }}>{tabs.map(([k, t, r]) => <button key={k} aria-current={tab === k} onClick={() => setTab(k)}>{t} ({nz(r.length)})</button>)}</div>
    <div className="kvline" style={{ marginBottom: 8 }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} /></div>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr><th>Manager</th><th>Grade</th><th>Function</th><th className="num">Current</th><th className="num">Proposed</th>{tab === 'up' && <th className="num">Of which Vacant Positions</th>}<th className="num">Change</th></tr></thead>
      <tbody>{cur.map(r => <tr key={r.code}><td><b>{r.name}</b><div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div></td><td>{r.grade}</td><td>{r.function}</td>
        <td className="num">{nz(r.frm)}</td><td className="num"><b>{nz(r.to)}</b></td>{tab === 'up' && <td className="num">{r.vac ? nz(r.vac) : '–'}</td>}<td className={'num ' + (r.to > r.frm ? 'ch-up' : 'ch-dn')}>{r.to > r.frm ? '+' : '−'}{nz(Math.abs(r.to - r.frm))}</td>
</tr>)}
        {!cur.length && <tr><td colSpan={tab === 'up' ? 7 : 6} className="formula">None.</td></tr>}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={() => {
      const all = [...tabs[0][2], ...tabs[1][2]]
      const csv = [['Manager', 'Code', 'Grade', 'Function', 'Current direct reports', 'Proposed direct reports (incl. vacant)', 'Of which vacant', 'Change'], ...all.map(r => [r.name, r.code, r.grade, r.function, r.frm, r.to, r.vac || 0, r.to - r.frm])]
      const blob = new Blob(['\ufeff' + csv.map(x => x.map(v => '"' + String(v ?? '').replace(/"/g, '""') + '"').join(',')).join('\n')], { type: 'text/csv' })
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'Span of Control changes.csv'; a.click()
    }}>Download List</button></div>
  </Modal>
}

// someone missing from the list: why they are, or are not, a unit transition
function UnitCheck() {
  const [q, setQ] = useState('')
  const [r, setR] = useState(null)
  useEffect(() => { if (q.trim().length < 2) { setR(null); return } const t = setTimeout(() => api('/api/chro/unit-check?q=' + encodeURIComponent(q)).then(setR).catch(() => setR([])), 300); return () => clearTimeout(t) }, [q])
  return <div style={{ marginTop: 14, borderTop: '1px solid var(--line)', paddingTop: 12 }}>
    <h3 style={{ margin: '0 0 6px' }}>Not in the list? Check someone</h3>
    <input className="inp" placeholder="Name or employee code" value={q} onChange={e => setQ(e.target.value)} style={{ width: '100%' }} />
    {r && <div className="tw" style={{ marginTop: 8 }}><table>
      <thead><tr><th>Staff</th><th>Function (HR file → Proposed)</th><th>Line manager (Current → Proposed)</th><th className="num">Team</th><th>Result</th></tr></thead>
      <tbody>{r.map(x => <tr key={x.code}><td><b>{x.name}</b><div className="formula">{x.code}</div></td><td>{x.fn_hr || '–'} → {x.fn_pro || '–'}</td><td>{x.mgr_cur || '–'} → {x.mgr_pro || '–'}</td><td className="num">{x.team || '–'}</td><td>{x.why}</td></tr>)}
        {!r.length && <tr><td colSpan={5} className="formula">No one found.</td></tr>}</tbody></table></div>}
  </div>
}

// Unit Transition Opportunities: the admin picks the units that count
function UnitList({ rows, canEdit, notify, onSaved, onClose }) {
  const [on, setOn] = useState(() => new Set(rows.filter(r => r.selected).map(r => r.code)))
  const save = async () => { try { await api('/api/chro/units', { method: 'PUT', body: { codes: [...on], seen: rows.map(r => r.code) } }); notify('Saved.'); onSaved() } catch (e) { notify(e.message, true) } }
  return <Modal wide title="Unit Transition Opportunities" sub={`${nz(rows.filter(r => on.has(r.code)).length)} units · ${nz(rows.filter(r => on.has(r.code)).reduce((a, r) => a + r.staff, 0))} staff`} onClose={onClose}>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr>{canEdit && <th></th>}<th>Unit Head</th><th>Unit</th><th>Current Function</th><th>Proposed Function</th><th className="num">Staff</th></tr></thead>
      <tbody>{rows.map(r => <tr key={r.code}>{canEdit && <td><input type="checkbox" checked={on.has(r.code)} onChange={e => setOn(s => { const n = new Set(s); e.target.checked ? n.add(r.code) : n.delete(r.code); return n })} /></td>}
        <td><b>{r.name}</b><div className="formula">{r.position}</div></td><td>{r.unit}</td><td>{r.frm}</td><td>{r.to}</td><td className="num">{nz(r.staff)}</td></tr>)}
        {!rows.length && <tr><td colSpan={canEdit ? 6 : 5} className="formula">None.</td></tr>}</tbody></table></div>
    {canEdit && rows.length > 0 && <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn pri" onClick={save}>Save</button></div>}
    {canEdit && <UnitCheck />}
  </Modal>
}

// layers by function for one state (as on the dashboard, without the span)
function LayersTable({ o, people, mgrHead }) {   // mgrHead: the number of managerial layers, headed above L1 to Ln (Proposed State)
  const C = o.C, n = f => C.filter(p => p.f === f).length, fs = [...o.fstats].sort((a, b) => n(b.f) - n(a.f) || a.name.localeCompare(b.name))   // the most staff first
  const ls = C.filter(p => p.ly > 0).map(p => p.ly), hi = Math.max(1, ...ls)
  const LYR = []; for (let l = 1; l <= hi; l++) LYR.push(l)
  const mgr = ps => ps.filter(p => p.nk > 0 && p !== o.ROOT).length
  return <div className="panel" style={{ padding: '10px 14px' }}><div className="tw"><table className="heat">
    <thead>{mgrHead > 0 && <tr className="lt-grp"><th></th>
      <th colSpan={Math.min(mgrHead, hi)}><span className="lt-g lt-g1">Managerial Layers</span></th>
      {hi > mgrHead && <th colSpan={1}><span className="lt-g lt-g2">Teams</span></th>}
      {hi > mgrHead + 1 && <th colSpan={hi - mgrHead - 1}><span className="lt-g lt-g3">FTCs</span></th>}<th></th></tr>}
      <tr><th>Function</th>{LYR.map(l => <th key={l} className="num">L{l}</th>)}<th className="num">Staff</th></tr></thead>
    <tbody>{fs.length > 1 && <tr className="tot top"><td>Total</td>{LYR.map(l => { const r = C.filter(p => p.ly === l); return <td key={l} className="num">{r.length ? <button className="cellbtn" onClick={() => people(`Layer ${l}`, r)}>{nz(r.length)}</button> : ''}</td> })}
      <td className="num">{nz(C.length)}</td></tr>}
      {fs.map(s => { const ps = C.filter(p => p.f === s.f); const row = LYR.map(l => ps.filter(p => p.ly === l)); const mx = Math.max(1, ...row.map(r => r.length))
        const used = Math.max(0, ...ps.map(p => p.ly || 0)), last = row.length - 1 - [...row].reverse().findIndex(r => r.length)
        return <tr key={s.f}><td><span className="dot" style={{ background: o.FCOL[s.f] }} />{s.name}</td>
          {row.map((r, i) => <td key={i} className={'num hc' + (r.length / mx > 0.6 ? ' dk' : '')} style={{ '--h': r.length ? 0.12 + 0.78 * r.length / mx : 0 }}>
            {r.length ? <button className="cellbtn" onClick={() => people(`${s.name}: Layer ${LYR[i]}`, r)}>{nz(r.length)}</button> : i < last ? <span className="dash">-</span> : ''}</td>)}
          <td className="num"><b>{nz(ps.length)}</b></td></tr> })}</tbody></table></div></div>
}

export default function Chro({ notify, theme, user }) {
  const [fn, setFn] = useState('')
  const [unit, setUnit] = useState('')   // a unit of the function on show
  const [d, setD] = useState(null)
  const [raw, setRaw] = useState({ asis: null, tobe: null })
  const [ver, setVer] = useState(0)
  const [state, setState] = useState('cur')        // Current State / Proposed State
  const [list, setList] = useState(null)
  const [focus, setFocus] = useState(null)
  const [asIs, setAsIs] = useState(false)
  const [plist, setPlist] = useState(null)
  const [openSec, setOpenSec] = useState(null)
  const [vacs, setVacs] = useState([])
  const [vacJd, setVacJd] = useState(null)
  const [repl, setRepl] = useState(null)
  const [newOpen, setNewOpen] = useState(false)
  const [spanOpen, setSpanOpen] = useState(null)   // the span of control changes: 'up', 'down' or 'all'
  const [unitsOpen, setUnitsOpen] = useState(false)
  const [fw, setFw] = useState(null)
  const canBm = !!(user && user.can_hr_bm)
  const [showMax, setShowMax] = useState(false)
  const [bench, setBench] = useState(null)
  const pro = state === 'pro'
  useEffect(() => { if (canBm && showMax && !bench) api('/api/chro/bench').then(setBench).catch(e => notify(e.message, true)) }, [showMax, ver])
  useEffect(() => { if (openSec === 'bench' && !fw) api('/api/bm/framework').then(setFw).catch(e => notify(e.message, true)) }, [openSec])
  useEffect(() => { setD(null); api('/api/chro/summary?fn=' + encodeURIComponent(fn)).then(setD).catch(e => notify(e.message, true)) }, [fn, ver])
  useEffect(() => { api('/api/chro/vacancies').then(setVacs).catch(() => setVacs([])) }, [ver])
  useEffect(() => { Promise.all([api('/api/chro/org?side=asis'), api('/api/chro/org?side=tobe')]).then(([a, b]) => setRaw({ asis: a, tobe: b })).catch(e => notify(e.message, true)) }, [ver])
  const orgOf = data => {
    if (!data) return null
    const ef = fn || ((d?.functions || []).length === 1 ? d.functions[0] : '')
    const i = ef ? data.functions.indexOf(ef) : -1
    let scoped = i >= 0 ? scopeData(data, [data.function_ids[i]]) : data
    if (unit && i >= 0) scoped = unitData(scoped, [unit])
    return scoped.people.length ? buildOrg(scoped, true) : null
  }
  const oa = useMemo(() => orgOf(raw.asis), [raw.asis, fn, unit, d?.functions])
  const oaAll = useMemo(() => raw.asis && raw.asis.people.length ? buildOrg(raw.asis, true) : null, [raw.asis])
  const obAll = useMemo(() => raw.tobe && raw.tobe.people.length ? buildOrg(raw.tobe, true) : null, [raw.tobe])
  const [diff, setDiff] = useState(null)
  const showDiff = (title, test = () => true) => {   // staff in the Proposed figure and not the Current one, and the other way
    if (!oa || !ob || !oaAll || !obAll) return
    const A = new Set(oa.C.filter(test).map(p => p.id)), B = new Set(ob.C.filter(test).map(p => p.id))
    const tl = p => typeName(p), fnOf = (O, p) => O.F[p.f] || ''
    const why = (p, inn) => {
      const a = oaAll.byId.get(p.id), b = obAll.byId.get(p.id)
      if (inn && (!a || !oaAll.counted(a))) return 'Not in the Current State'
      if (!inn && (!b || !obAll.counted(b))) return b && b.hs ? (b.rp ? 'Surrendered (replacement)' : 'Headcount saved') : 'Not in the Proposed State'
      if (fnOf(oaAll, a) !== fnOf(obAll, b)) return `Function: ${fnOf(oaAll, a)} → ${fnOf(obAll, b)}`
      if (typeKey(a) !== typeKey(b)) return `Type: ${tl(a)} → ${tl(b)}`
      return 'Changed'
    }
    const rows = [...ob.C.filter(p => test(p) && !A.has(p.id)).map(p => ({ code: p.id, name: p.n, pos: p.pos, grade: p.g, in: true, why: why(p, true) })),
      ...oa.C.filter(p => test(p) && !B.has(p.id)).map(p => ({ code: p.id, name: p.n, pos: p.pos, grade: p.g, in: false, why: why(p, false) }))]
    setDiff({ title: `${title}: Current → Proposed`, rows })
  }
  const ob = useMemo(() => orgOf(raw.tobe), [raw.tobe, fn, unit, d?.functions])
  const changed = () => setVer(v => v + 1)
  const m = d?.meta || {}
  const o = pro ? ob : oa
  let fp = o && focus ? o.byId.get(focus) : null
  if (o && focus && !fp) {
    const rows = new Map([...(raw.asis?.people || []), ...(raw.tobe?.people || [])].map(r => [r[0], r]))
    let c = rows.get(focus)?.[4], n = 0
    while (c && !o.byId.get(c) && n++ < 30) c = rows.get(c)?.[4]
    fp = c ? o.byId.get(c) : null
  }
  // with a unit chosen, the chart starts at the unit's head (the one counted person whose manager is not in the unit)
  const oRoot = useMemo(() => { if (!o || !unit) return o?.ROOT; const t = o.C.filter(p => p.m < 0 || o.P[p.m].ctx); return t.length === 1 ? t[0] : o.ROOT }, [o, unit])
  const sel = fp || oRoot
  const fnList = d?.functions || []
  const one = !!(d?.scoped && fnList.length === 1)
  const vacShown = useMemo(() => vacs.filter(v => !fn || v.function === fn), [vacs, fn])
  const vacMap = useMemo(() => pro && ob ? vacMapOf(vacShown, ob, ob.ROOT) : null, [vacShown, ob, pro])
  // the figures of each state
  const figs = x => {
    if (!x) return null
    const t = {}; types().forEach(tp => { t[tp.k] = x.C.filter(tp.test).length })
    return { staff: x.C.length, t, layers: x.C.length ? Math.max(0, ...x.C.map(p => p.ly || 0)) : 0, mgrs: x.C.filter(p => p.nk > 0 && p !== x.ROOT),
      svc: x.C.filter(p => p.st === 'Service').length, sup: x.C.filter(p => p.st === 'Support').length }
  }
  const fa = useMemo(() => figs(oa), [oa]), fb = useMemo(() => figs(ob), [ob])
  const people = (title, ps, org) => setPlist({ title, people: ps, org: org || o })
  const toggleSec = k => { setOpenSec(x => x === k ? null : k); setTimeout(() => document.getElementById('hx-' + k)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60) }
  // activities: the functions on show
  const actSel = useMemo(() => { const data = raw.tobe; if (!data) return []; if (fn) { const i = data.functions.indexOf(fn); return i >= 0 ? [data.function_ids[i]] : [] } return d?.scoped ? [...new Set(data.people.filter(r => !r[12]).map(r => data.function_ids[r[3]]).filter(x => x > 0))] : [] }, [raw.tobe, fn, d?.scoped])
  const uploadHr = async file => {
    const send = dry => { const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false'); return api('/api/chro/asis/upload', { method: 'POST', form: fd }) }
    try {
      const rep = await send(true)
      if (!window.confirm(`${file.name}: ${fmt(rep.rows)} staff. Use it as the Current State?`)) return
      const r = await send(false); notify(`${file.name}: ${fmt(r.rows)} staff.`); changed()
    } catch (e) { notify(e.message, true) }
  }
  const useDb = async () => {
    if (!window.confirm('Use the database for the Current State?')) return
    try { await api('/api/chro/asis/reset', { method: 'POST' }); changed() } catch (e) { notify(e.message, true) }
  }
  const stateSeg = cls => <span className={'seg hx-state' + (cls ? ' ' + cls : '')} role="group" aria-label="State"><button type="button" aria-pressed={!pro} onClick={() => setState('cur')}>{L('hr.cur')}</button><button type="button" aria-pressed={pro} onClick={() => setState('pro')}>{L('hr.pro')}</button></span>
  const maxBtn = canBm && pro ? <button type="button" className={'btn bm-btn' + (showMax ? ' on' : '')} aria-pressed={showMax} onClick={() => setShowMax(x => !x)}><span className="bm-key" />Show Max Grade</button> : null
  const panel = o && sel ? <DirectPanel o={o} p={sel} onPick={x => setFocus(x.id)} onList={(t, ps) => people(t, ps)} /> : null
  const unitList = useMemo(() => {
    const ef = fn || ((d?.functions || []).length === 1 ? d.functions[0] : '')
    if (!ef) return []
    const u = new Set()
    ;[raw.asis, raw.tobe].forEach(x => { if (!x) return; const i = x.functions.indexOf(ef); x.people.forEach(r => { if (r[3] === i && r[12] !== 1 && r[16]) u.add(r[16]) }) })
    return [...u].sort()
  }, [raw, fn, d?.functions])
  // with a unit chosen: the lists and counts of the summary limited to the staff of the unit (either state)
  const dv = useMemo(() => {
    if (!d || !unit || !oa || !ob) return d
    const ids = new Set([...oa.C, ...ob.C, ...oa.P.filter(p => p.hs), ...ob.P.filter(p => p.hs)].map(p => p.id)), inU = r => r && r.code && ids.has(r.code), byU = r => (r.unit || '') === unit
    const opt = { ...d.opt }
    ;['delayering', 'units', 'exit', 'pr', 'trade', 'geo'].forEach(k => { opt[k] = (d.opt[k] || []).filter(inU) })
    opt.units_n = opt.units.filter(u => u.selected).length; opt.units_staff = opt.units.filter(u => u.selected).reduce((a, u) => a + u.staff, 0)
    opt.geo_from = [...new Set(opt.geo.flatMap(g => g.regions || []))].sort(); opt.geo_to = [...new Set(opt.geo.map(g => g.to))].sort()
    const changes = Object.fromEntries(Object.entries(d.changes || {}).map(([k, v]) => [k, (v || []).filter(r => r.code ? ids.has(r.code) : byU(r))]))
    const counts = Object.fromEntries(Object.entries(changes).map(([k, v]) => [k, v.length]))
    const n = rows => rows.reduce((a, r) => a + (r.count || 0), 0)
    const repl = { ...d.repl }; ['normal', 'special', 'post', 'new', 'pending'].forEach(k => { repl[k] = (d.repl[k] || []).filter(r => r.staff_code ? ids.has(r.staff_code) : byU(r)); repl['n_' + k] = n(repl[k]) })
    let benchmark = d.benchmark
    if (benchmark) { const lists = Object.fromEntries(Object.entries(benchmark.lists).map(([k, v]) => [k, v.filter(inU)])); benchmark = { ...benchmark, lists, above: lists.above.length, at: lists.at.length, room: lists.room.length } }
    return { ...d, opt, changes, counts, repl, benchmark }
  }, [d, unit, oa, ob])
  const rp = dv?.repl, op = dv?.opt
  const dz = v => (v ? nz(v) : '–')   // optimisation: a dash instead of 0
  // delayering: the functions whose number of layers goes down (Current → Proposed), not the staff
  const delay = useMemo(() => {
    if (!oa || !ob) return { n: 0, txt: '' }
    const lay = (O, f) => Math.max(0, ...O.C.filter(p => O.F[p.f] === f).map(p => p.ly || 0))
    const fs = [...new Set(ob.C.map(p => ob.F[p.f]).filter(Boolean))]
    const red = fs.map(f => [f, lay(oa, f), lay(ob, f)]).filter(([, a, b]) => a > b).sort((x, y) => (y[1] - y[2]) - (x[1] - x[2]))
    if (fn || red.length <= 1 && fs.length === 1) { const r = red[0]; return { n: r ? r[1] - r[2] : 0, txt: r ? `Layers ${r[1]} → ${r[2]}` : '' } }
    return { n: red.length, txt: red.length ? red.slice(0, 3).map(([f, a, b]) => `${f} ${a} → ${b}`).join(' · ') + (red.length > 3 ? ` · +${red.length - 3} more` : '') : '' }
  }, [oa, ob, fn])
  const opts = !d ? [] : [
    ['lean', 'Delayering', delay.n ? nz(delay.n) : '–', null, delay.txt || `Max Managerial Layers ${op.max_layers}`],
    ['units', 'Unit Transition Opportunity', dz(op.units_n), () => setUnitsOpen(true), op.units_n ? `${nz(op.units_staff)} staff` : ''],
    ['geo', 'Geographic Consolidation', dz(op.geo.length), () => setList({ k: 'geo', title: 'Geographic Consolidation', rows: op.geo }),
      op.geo.length ? `${L('hr.cur')} ${op.geo_from.join(' & ')} · ${L('hr.pro')} ${op.geo_to.join(' & ')}` : ''],
    ...(dv.benchmark && canBm ? [['grade', 'Position Realignment Opportunity', dz(dv.benchmark.above), () => setList({ k: 'bm_above', title: 'Position Realignment Opportunity', rows: dv.benchmark.lists.above })]] : []),
    ['title', 'Title Realignment', dz(dv.counts.title), () => setList({ k: 'title', title: 'Title Realignment' })],
    ['exit', 'Staff Exit Candidate', dz(op.exit.length), () => setList({ k: 'exit', title: 'Staff Exit Candidate', rows: op.exit }), [...types()].sort((a, b) => (b.k === 'dc') - (a.k === 'dc')).map(t => [t.k === 'dc' ? 'PR' : t.label, op.exit.filter(r => r.t === t.k).length]).filter(x => x[1]).map(x => `${x[0]} ${nz(x[1])}`).join(' · ')],
    ['pr', 'Post Retirement Staff Replacement', dz(op.pr.length), () => setList({ k: 'pr', title: 'Post Retirement Staff Replacement', rows: op.pr })],
    ...((() => { const ef = fn || (fnList.length === 1 ? fnList[0] : ''), isT = f => op.trade_fn ? f === op.trade_fn : /trade/i.test(f)
      return ef ? isT(ef) : !d.scoped || fnList.some(isT) })() ? [['trade', 'Trade Staff Realignment', dz(op.trade.length), () => setList({ k: 'trade', title: 'Trade Staff Realignment', rows: op.trade })]] : []),
  ]
  const SECS = [['bench', 'Position Benchmark'], ['org', 'Organogram'], ['layers', 'Layers'], ['opt', 'Optimization'], ['acts', 'Activities']]
  const typeList = types().filter(t => (fa && fa.t[t.k]) || (fb && fb.t[t.k]))   // a type with no one in either state is not shown
  return <section className="view on ch-page chv hr-page hx">
    <header className="hxh">
      <div className="hxh-r">
        <div className="hxh-ctl">
          <label className="hxh-fn"><span>Function</span>
            <select className="inp" value={fn || (one ? fnList[0] : '')} onChange={e => { setFn(e.target.value); setUnit(''); setFocus(null) }}>
              {!one && <option value="">{d?.scoped ? 'All my functions' : L('dash.title')}</option>}{fnList.map(f => <option key={f} value={f}>{f}</option>)}</select></label>
          {(fn || one) && unitList.length > 0 && <label className="hxh-fn"><span>Unit</span>
            <select className="inp" value={unit} onChange={e => { setUnit(e.target.value); setFocus(null) }}>
              <option value="">All units</option>{unitList.map(u => <option key={u} value={u}>{u}</option>)}</select></label>}
          {stateSeg('big')}</div>
        {d?.can_edit && <div className="hxh-adm">
          <label className="linkbtn" style={{ cursor: 'pointer' }}>Upload HR Master File<input type="file" accept=".xlsx" hidden onChange={e => { const f = e.target.files[0]; e.target.value = ''; if (f) uploadHr(f) }} /></label>
          {m.source === 'upload' && <button className="linkbtn" onClick={useDb}>Use Database</button>}
          <button className="linkbtn" onClick={() => setAsIs(true)}>As Is Data</button></div>}
      </div>
    </header>
    {!d || !fa ? <div className="loading">Loading…</div> : <>
      {(() => {
        const sh = pro && fb ? fb : fa, so = pro && fb ? ob : oa
        const nFte = rp ? rp.new.filter(r => r.emp_type !== 'FTC').reduce((a, r) => a + r.count, 0) : 0, nFtc = rp ? rp.new.filter(r => r.emp_type === 'FTC').reduce((a, r) => a + r.count, 0) : 0
        const ft = (rows, t) => (rows || []).filter(r => (r.emp_type === 'FTC') === (t === 'FTC')).reduce((a, r) => a + (r.count || 1), 0)   // replacement positions by FTE / FTC
        const rAll = rp ? [...(rp.normal || []), ...(rp.special || [])] : [], rFte = ft(rAll, 'FTE'), rFtc = ft(rAll, 'FTC')
        const exitC = new Set((op?.exit || []).map(r => r.code)), svIn = st => (ob || oa).C.filter(p => p.st === st && !exitC.has(p.id))   // the Proposed State staff   // not the staff exit candidates
        const nSvc = svIn('Service').length, nSup = svIn('Support').length, svT = nSvc + nSup
        return <div className={'xtg ' + (pro ? 'pro' : 'cur')}>
          <div className="xt xt-staff">
            <button type="button" className="xt-top" onClick={() => people(L('hr.active'), o.C)}>
              <span className="xt-h"><span className="xt-ic"><Icon name="people" /></span><span className="xt-l">{L('hr.active')}</span></span>
              <Fig a={fa.staff} b={sh.staff} pro={pro && fb} big onDiff={() => showDiff(L('hr.active'))} /></button>
            <span className="xt-comp"><Split parts={typeList.map(t => ({ v: sh.t[t.k], color: XC[t.k], label: t.label }))} />
              <span className="xt-leg">{typeList.map(t => <span key={t.k}><i style={{ background: XC[t.k] }} />{t.label} <b>{pcs(sh.t[t.k], sh.staff)}</b></span>)}</span></span>
            <div className="xt-types">{typeList.map(t => <button type="button" key={t.k} className="xt-type" onClick={() => people(t.label, o.C.filter(t.test))}>
              <span className="xt-tl"><span>{t.label}</span><small>{pcs(sh.t[t.k], sh.staff)}</small></span>
              <Fig a={fa.t[t.k]} b={sh.t[t.k]} pro={pro && fb} onDiff={() => showDiff(t.label, t.test)} />
              <span className="xt-bar"><i style={{ width: pct(sh.t[t.k], sh.staff) + '%', background: XC[t.k] }} /></span></button>)}</div>
          </div>
          {pro && rp && <div className="xt">
            <span className="xt-h"><span className="xt-ic"><Icon name="list" /></span><span className="xt-l">{L('hr.repl')}</span></span>
            <Fig b={rp.n_normal + rp.n_special} />
            <span className="xt-rows">
              <span className="xt-leg"><span><i style={{ background: '#00796B' }} />FTE <b>{dd(rFte)}</b></span><span><i style={{ background: '#6FBFB3' }} />FTC <b>{dd(rFtc)}</b></span></span>
              {REPL_TABS.map(([k, t, def]) => <button type="button" key={k} className="xt-row xt-row2" onClick={() => setRepl(k)}><span>{t}<small>{def}</small></span>
                <span className="xt-rn"><b>{dd(rp['n_' + k])}</b><small>FTE {dd(ft(rp[k], 'FTE'))} · FTC {dd(ft(rp[k], 'FTC'))}</small></span></button>)}</span>
          </div>}
          {pro && rp && (() => { const pr = rp.pending || [], pF = pr.filter(r => r.emp_type !== 'FTC').reduce((a, r) => a + r.count, 0), pC = pr.filter(r => r.emp_type === 'FTC').reduce((a, r) => a + r.count, 0)
            return <div className="xt">
              <span className="xt-h"><span className="xt-ic"><Icon name="list" /></span><span className="xt-l">{L('hr.pend')}</span></span>
              <Fig b={rp.n_pending || 0} />
              <span className="xt-rows"><Split parts={[{ v: pF, color: '#00796B', label: 'FTE' }, { v: pC, color: '#6FBFB3', label: 'FTC' }]} />
                {[['FTE', pF], ['FTC', pC]].map(([t, v]) => <button type="button" key={t} className="xt-row" onClick={() => setNewOpen('pending')}><span>{t}<small>{pcs(v, pF + pC)}</small></span><b>{dd(v)}</b></button>)}</span>
            </div> })()}
          {pro && rp && <div className="xt">
            <span className="xt-h"><span className="xt-ic"><Icon name="tag" /></span><span className="xt-l">{L('hr.new')}</span></span>
            <Fig b={rp.n_new} />
            <span className="xt-rows"><Split parts={[{ v: nFte, color: '#00796B', label: 'FTE' }, { v: nFtc, color: '#6FBFB3', label: 'FTC' }]} />
              {[['FTE', nFte], ['FTC', nFtc]].map(([t, v]) => <button type="button" key={t} className="xt-row" onClick={() => setNewOpen(true)}><span>{t}<small>{pcs(v, nFte + nFtc)}</small></span><b>{dd(v)}</b></button>)}</span>
          </div>}
        </div>
      })()}

      <div className="seclaunch" role="group">{SECS.map(([k, l]) => <button key={k} type="button" aria-pressed={openSec === k} onClick={() => toggleSec(k)}>
        <i className="sl-dot" /><span><b>{l}</b></span><em className="sl-go">{openSec === k ? '–' : '+'}</em></button>)}</div>

      {openSec === 'bench' && <section id="hx-bench" className="dsec"><div className="dsec-h"><div><span className="dbul" /><h2>Position Benchmark</h2></div></div>
        {fw ? <BenchFramework inline settings={fw.settings} ladder={fw.ladder} top="EXCO" topTag="" title="Position Benchmark" /> : <div className="loading">Loading…</div>}
        {dv.benchmark && <div className="hr-bm" style={{ marginTop: 14 }}>
          {[['room', 'Below Benchmark', 'b1'], ['at', 'At Benchmark', 'b2'], ['above', 'Above Benchmark', 'b3']].map(([x, t, tone]) =>
            <button key={x} type="button" className={'hr-k ' + tone} disabled={!dv.benchmark[x]} onClick={() => setList({ k: 'bm_' + x, title: t, rows: dv.benchmark.lists[x] })}><span className="hr-kt">{t}</span><b>{nz(dv.benchmark[x])}</b></button>)}
        </div>}</section>}

      {openSec === 'org' && <section id="hx-org" className="dsec"><div className="dsec-h"><div><span className="dbul" /><h2>Organogram</h2></div>
        <span className="org-right">{stateSeg('sm')}{focus && <button className="linkbtn" onClick={() => setFocus(null)}>Back to the top</button>}
          {maxBtn}</span></div>
        {!o ? <p className="formula">None.</p>
          : <div className={pro ? 'lp-wrap hx-lpw' : 'hx-nolp'}>{pro && panel}<div className="orgchart wide"><Classic simple root={oRoot} top={oRoot} focus={fp || null} onFocus={p => setFocus(p ? p.id : null)} org={o} theme={theme} largeTeam={40} onReroot={() => {}}
              onOpenList={x => people(`${x.n}: direct reports`, x.kids.filter(o.counted))} onSelect={p => setFocus(p.id)} tools={<>{stateSeg('sm')}{maxBtn}</>} side={pro ? panel : null}
              vacancies={vacMap} onVacancy={v => setVacJd(v)} bench={pro && showMax ? bench : null} /></div></div>}</section>}

      {openSec === 'layers' && <section id="hx-layers" className="dsec"><div className="dsec-h"><div><span className="dbul" /><h2>Layers</h2></div>{stateSeg('sm')}</div>
        {pro && <SpanStrip fa={fa} fb={fb} rows={dv.changes.span || []} onOpen={k => setSpanOpen(k)} />}
        {o ? <LayersTable o={o} people={(t, ps) => people(t, ps)} mgrHead={pro ? (op?.max_layers || 5) : 0} /> : <p className="formula">None.</p>}</section>}

      {openSec === 'opt' && <section id="hx-opt" className="dsec hx-opt"><div className="dsec-h"><div><span className="dbul" /><h2>Optimization</h2></div></div>
        <div className="hx-opts">{opts.map(([k, t, v, go, sub], i) => <button type="button" key={k} className={'hx-o' + (go ? '' : ' static')} onClick={go || undefined} disabled={!go}>
          <span className="hx-on">{i + 1}</span><span className="hx-ot">{t}</span><b>{v}</b>{sub && <small>{sub}</small>}</button>)}</div></section>}

      {openSec === 'acts' && <div id="hx-acts"><ActsSection sel={actSel} units={[]} includeFlagged={false} theme={theme} staff /></div>}
    </>}
    {vacJd && <Modal title={vacJd.position} sub={[vacKindL(vacJd.kind), vacJd.emp_type, vacJd.grade, vacJd.unit].filter(Boolean).join(' · ')} onClose={() => setVacJd(null)}>
      <p className="formula" style={{ marginTop: 0 }}>Reports to {vacJd.parent_position ? `${vacJd.parent_position} (vacant)` : vacJd.manager_name || 'the function head'} · {fmt(vacJd.open)} open{vacJd.replaces_name ? ` · replaces ${vacJd.replaces_name}` : ''}{vacJd.note ? ' · ' + vacJd.note : ''}</p>
      {vacJd.jd ? <div className="jd-text">{vacJd.jd}</div> : null}</Modal>}
    {repl && d && <ReplList repl={dv.repl} initial={repl} onClose={() => setRepl(null)} />}
    {newOpen && d && <NewList rows={newOpen === 'pending' ? dv.repl.pending || [] : dv.repl.new} title={newOpen === 'pending' ? L('hr.pend') : undefined} onClose={() => setNewOpen(false)} />}
    {unitsOpen && d && <UnitList rows={dv.opt.units} canEdit={d.can_edit} notify={notify} onSaved={() => { setUnitsOpen(false); changed() }} onClose={() => setUnitsOpen(false)} />}
    {list && d && <ChangeList k={list.k} title={list.title} rows={list.rows || dv.changes[list.k] || []} onPerson={r => { setList(null); if (r.code) { setFocus(r.code); setOpenSec('org') } }} onClose={() => setList(null)}
      extra={list.k === 'trade' && d.can_edit ? <TradeFnPick cur={d.opt.trade_fn} fns={(raw.tobe?.functions || []).filter(Boolean)} notify={notify} onSaved={changed} /> : null} />}
    {spanOpen && d && <SpanList rows={dv.changes.span || []} initial={spanOpen} onClose={() => setSpanOpen(null)} />}
    {diff && <DiffList diff={diff} onClose={() => setDiff(null)} />}
    {asIs && <AsIsData notify={notify} canEdit={d?.can_edit} onChanged={changed} onClose={() => setAsIs(false)} />}
    {plist && <PeopleModal title={plist.title} people={plist.people} F={plist.org.F} heads={plist.org.headIds} initial="people" onPerson={x => { setPlist(null); setFocus(x.id); setOpenSec('org') }} onClose={() => setPlist(null)} />}
  </section>
}

// the layer panel on the left of the organogram: the person's reporting line above them, and their direct reports by
// layer below them (only the direct reports, not the whole team)
function DirectPanel({ o, p, onPick, onList }) {
  const chain = []; let x = p; while (x) { chain.unshift(x); x = x.m >= 0 ? o.P[x.m] : null }
  const at = {}; chain.forEach(c => { if (c.ly > 0 && !at[c.ly]) at[c.ly] = c })
  const dir = {}; p.kids.forEach(k => { if (o.counted(k) && k.ly > 0) (dir[k.ly] = dir[k.ly] || []).push(k) })
  const last = Math.max(p.ly || 1, ...Object.keys(dir).map(Number))
  const ls = []; for (let l = 1; l <= last; l++) ls.push(l)
  const nd = Object.values(dir).reduce((a, v) => a + v.length, 0)
  return <div className="lp hx-lp">
    <div className="lp-top"><h3>Layers</h3></div>
    <div className="lp-sub">{o.F[p.f] || ''}</div>
    <div className="lp-depth"><b>L{p.ly}</b> {p.n}{nd ? <> · <b>{nz(nd)}</b> direct reports</> : ''}</div>
    <div className="lp-steps">{ls.map(l => {
      const c = at[l], mine = l === p.ly, under = l > (p.ly || 0), dl = dir[l]
      return <div key={l} className={'lp-st' + (mine ? ' on' : '') + ((!under && !c) || (under && !dl) ? ' none' : '')}>
        <i>L{l}</i>
        <div>{!under ? (c ? <button type="button" className="lp-n" onClick={() => c !== p && onPick(c)}>{c.n}</button> : <b>–</b>)
          : dl ? <button type="button" className="lp-n lp-cnt" onClick={() => onList(`${p.n}: direct reports on Layer ${l}`, dl)}>{nz(dl.length)} {dl.length === 1 ? 'direct report' : 'direct reports'}</button> : <b>–</b>}
          <span>{LNAME[l] || 'Layer ' + l}{!under && c && c.g && c.g !== '-' ? ` · ${c.g}` : ''}</span></div>
      </div>
    })}</div>
  </div>
}

// the layer panel on top of the organogram: the person's reporting line above them, and their direct reports by
// layer below them (shaded by how many direct reports sit on each layer)
const LNAME = { 1: 'EXCO', 2: 'Function', 3: 'Department', 4: 'Unit', 5: 'Team Lead', 6: 'Teams', 7: 'FTCs' }
function LayerStrip({ o, p, onPick, onList }) {
  const chain = []; let x = p; while (x) { chain.unshift(x); x = x.m >= 0 ? o.P[x.m] : null }
  const at = {}; chain.forEach(c => { if (c.ly > 0 && !at[c.ly]) at[c.ly] = c })
  const dir = {}; p.kids.forEach(k => { if (o.counted(k) && k.ly > 0) (dir[k.ly] = dir[k.ly] || []).push(k) })
  const last = Math.max(p.ly || 1, ...Object.keys(dir).map(Number))
  const mx = Math.max(1, ...Object.values(dir).map(v => v.length))
  const ls = []; for (let l = 1; l <= last; l++) ls.push(l)
  return <div className="hr-strip">{ls.map(l => {
    const c = at[l], un = l > (p.ly || 0), dl = dir[l], h = un && dl ? 0.12 + 0.78 * dl.length / mx : 0
    return <div key={l} className={'hr-sc' + (l === p.ly ? ' on' : '') + (h > 0.6 ? ' dk' : '')} style={{ '--h': h }}>
      <div className="hr-sh"><b>L{l}</b><span>{LNAME[l] || 'Layer ' + l}</span></div>
      <div className="hr-sv">{!un ? (c ? (c === p ? <b>{c.n}</b> : <button type="button" onClick={() => onPick(c)}>{c.n}</button>) : <b>–</b>)
        : dl ? <button type="button" onClick={() => onList(`${p.n}: direct reports on Layer ${l}`, dl)}>{fmt(dl.length)} {dl.length === 1 ? 'direct' : 'directs'}</button> : <b>–</b>}</div>
    </div>
  })}</div>
}
