import React, { useEffect, useRef, useState } from 'react'
import Chart from 'chart.js/auto'
import { L } from './prefs.js'

export const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim()

export function ChartBox({ config, tall, deps = [] }) {
  const ref = useRef(null)
  useEffect(() => {
    Chart.defaults.font.family = 'Manrope, Segoe UI, system-ui, sans-serif'
    Chart.defaults.font.size = 12
    Chart.defaults.color = css('--ink-2')
    Chart.defaults.borderColor = css('--line')
    Chart.defaults.plugins.legend.labels.boxWidth = 10
    Chart.defaults.plugins.legend.labels.boxHeight = 10
    const c = new Chart(ref.current, { ...config(), options: { maintainAspectRatio: false, ...config().options } })
    return () => c.destroy()
  }, deps)
  return <div className={'chartbox' + (tall ? ' tall' : '')}><canvas ref={ref} /></div>
}

// Table: cols = [{h, v:(row)=>node, num}] ; onRow optional
export function Table({ cols, rows, onRow, empty = 'Nothing to show.' }) {
  return (
    <table>
      <thead><tr>{cols.map((c, i) => <th key={i} className={c.num ? 'num' : ''}>{c.h}</th>)}</tr></thead>
      <tbody>
        {rows.length ? rows.map((r, j) => (
          <tr key={j} className={onRow ? 'click' : ''} onClick={onRow ? () => onRow(r) : undefined}>
            {cols.map((c, i) => <td key={i} className={c.num ? 'num' : ''}>{c.v(r)}</td>)}
          </tr>)) : <tr><td colSpan={cols.length} style={{ color: 'var(--ink-3)' }}>{empty}</td></tr>}
      </tbody>
    </table>
  )
}

// The employee types: FTE, Contract (DC: retired, rehired on contract), FTC and Daily Wagers. The admin names them
// (Admin, Labels) and sets the order they are shown in everywhere (Admin, Labels, Employee types).
// one colour per layer (L1 EXCO ... L7), used by the layer panels
export const LAYER_COL = { 1: '#00403A', 2: '#2A78D6', 3: '#6250D6', 4: '#008C78', 5: '#B87400', 6: '#E0702F', 7: '#7D9490' }
export const typeKey = p => p.dw ? 'dw' : p.dc ? 'dc' : p.fte ? 'fte' : 'ftc'
const TYPE_DEF = { fte: ['dash.fte', 'var(--fte)', 'fte', ''], dc: ['dash.dc', 'var(--dc)', 'fte', 'dc'], ftc: ['dash.ftc', 'var(--ftc)', 'ftc', 'ftc'], dw: ['dash.dw', 'var(--dw)', 'ftc', 'dw'] }
export const TYPE_KEYS = ['fte', 'dc', 'ftc', 'dw']
export const typeOrder = () => {
  const o = String(L('types.order') || '').split(',').filter(k => TYPE_DEF[k])
  return [...new Set([...(o.length ? o : []), ...TYPE_KEYS])]
}
// [{k, label, test, color, icon, tone}] in the admin's order
export const types = () => typeOrder().map(k => ({ k, label: L(TYPE_DEF[k][0]), test: p => typeKey(p) === k, color: TYPE_DEF[k][1], icon: TYPE_DEF[k][2], tone: TYPE_DEF[k][3] }))
export const typeName = p => p.dw ? L('dash.dw') : p.dc ? L('dash.dc') : p.fte ? 'FTE' : 'FTC'
export const Dot = ({ fte, dc, dw }) => <span className={'dot ' + (dw ? 'd-dw' : dc ? 'd-dc' : fte ? 'd-fte' : 'd-ftc')} />
export const TypeTag = ({ p }) => <><Dot fte={p.fte} dc={p.dc} dw={p.dw} />{typeName(p)}</>

// Text/number input that saves when the user leaves the field or presses Enter
export function EditField({ value, onCommit, type = 'text', className = 'inp', multiline, ...rest }) {
  const [v, setV] = useState(value ?? '')
  useEffect(() => { setV(value ?? '') }, [value])
  const commit = () => { const nv = type === 'number' ? (v === '' ? 0 : Number(v)) : v; if (String(nv) !== String(value ?? '')) onCommit(nv) }
  const props = { className, value: v, onChange: e => setV(e.target.value), onBlur: commit, ...rest }
  if (multiline) return <textarea rows={1} {...props} />
  return <input type={type} {...props} onKeyDown={e => { if (e.key === 'Enter') e.target.blur() }} />
}

export function Toast({ msg, bad, onDone }) {
  useEffect(() => { if (msg) { const t = setTimeout(onDone, 3500); return () => clearTimeout(t) } }, [msg])
  if (!msg) return null
  return <div className={'toast' + (bad ? ' bad' : '')} role="status">{msg}</div>
}

// ---------------------------------------------------------------- dialogs
// open modals, newest last: Esc closes only the top one
const STACK = []
// data that reloads without the page jumping: the previous data stays on show (faded) until the new data arrives,
// and only the answer to the latest request is used
export function useLive(fetcher, deps) {
  const [s, setS] = useState({ data: null, busy: true })
  const seq = useRef(0)
  useEffect(() => {
    const id = ++seq.current
    setS(x => x.busy ? x : { ...x, busy: true })
    Promise.resolve().then(fetcher).then(d => { if (id === seq.current) setS({ data: d, busy: false }) })
  }, deps)   // eslint-disable-line react-hooks/exhaustive-deps
  return [s.data, s.busy]
}

export function Modal({ title, sub, onClose, children, wide }) {
  const close = useRef(onClose); close.current = onClose
  useEffect(() => {
    const me = {}; STACK.push(me)
    const k = e => { if (e.key === 'Escape' && STACK[STACK.length - 1] === me) { e.stopPropagation(); close.current() } }
    window.addEventListener('keydown', k); document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', k); STACK.splice(STACK.indexOf(me), 1); if (!STACK.length) document.body.style.overflow = '' }
  }, [])
  return <div className="modal-bg" role="dialog" aria-modal="true" aria-label={title} onClick={onClose}>
    <div className={'modal' + (wide ? ' wide' : '')} onClick={e => e.stopPropagation()}>
      <div className="modal-h"><div><h2>{title}</h2>{sub && <div className="formula">{sub}</div>}</div>
        <button className="btn" onClick={onClose} aria-label="Close">✕</button></div>
      <div className="modal-b">{children}</div>
    </div>
  </div>
}

// Long text shown as one line with a button to expand it
export function Expand({ text, lines = 1 }) {
  const [open, setOpen] = useState(false)
  if (!text) return null
  const long = text.length > 70 || text.includes('\n')
  return <div className="expand">
    <div className={open ? '' : 'clamp'} style={open ? null : { WebkitLineClamp: lines }}>{text}</div>
    {long && <button type="button" className="linkbtn" onClick={e => { e.stopPropagation(); setOpen(o => !o) }} aria-expanded={open}>{open ? 'Show Less' : 'Show Full Description'}</button>}
  </div>
}

const fmtN = n => Number(n) ? Number(n).toLocaleString('en-US') : '-'

// Breakdown of a group of people: by grade (default), function, region, and the list of names
// Employees behind a figure: by grade, function or region, or as a list. Every figure opens the
// employees it counts; selecting an employee opens their reporting line (onPerson).
const TAB_TITLE = { grade: 'by Grade', function: 'by Function', region: 'by Region', people: 'Employees' }
const baseTitle = t => String(t || '').replace(/\s+by grade$/i, '').replace(/:\s*(employees|all employees)$/i, '')
export function PeopleModal({ title, sub, people, F, onPerson, initial = 'grade', onClose, heads }) {
  const [tab, setTab] = useState(initial)
  const [drill, setDrill] = useState(null)   // {label, list}: the employees behind one figure
  const [q, setQ] = useState('')
  const fns = new Set(people.map(p => p.f))
  const regs = new Set(people.map(p => p.rg))
  const TY = types().map(t => [t.k, t.k === 'fte' || t.k === 'ftc' ? t.k.toUpperCase() : t.label, t.test, t.color]).filter(t => people.some(t[2]))
  const mixed = TY.length > 1
  const group = key => {
    const m = new Map()
    people.forEach(p => { const k = key(p); const r = m.get(k.k) || { ...k, n: 0, fte: 0, dc: 0, ftc: 0, dw: 0, ps: [] }; r.n++; r[typeKey(p)]++; r.ps.push(p); m.set(k.k, r) })
    return [...m.values()]
  }
  const tabs = [['grade', 'By Grade'], ...(fns.size > 1 ? [['function', 'By Function']] : []), ...(regs.size > 1 ? [['region', 'By Region']] : []), ['people', `Employees (${fmtN(people.length)})`]]
  let rows = []
  if (tab === 'grade') rows = group(p => p.d === 0 && (!p.g || p.g === '-') ? { k: '__top', label: 'COSO', rk: 999 } : ({ k: p.g, label: p.g || '-', rk: p.rk })).sort((a, b) => (b.rk ?? -9) - (a.rk ?? -9) || a.label.localeCompare(b.label))
  if (tab === 'function') rows = group(p => ({ k: p.f, label: F[p.f] || 'No function' })).sort((a, b) => a.label.localeCompare(b.label))
  if (tab === 'region') rows = group(p => ({ k: p.rg, label: p.rg || 'Region not set' })).sort((a, b) => (a.label === 'Region not set') - (b.label === 'Region not set') || b.n - a.n)
  const max = Math.max(1, ...rows.map(r => r.n))
  const ql = q.trim().toLowerCase()
  const src = drill ? drill.list : people
  const isH = p => heads && heads.has(p.i) ? 1 : 0   // the top person and function heads first, then by grade
  const list = tab === 'people' ? [...src].sort((a, b) => isH(b) - isH(a) || (b.rk ?? -9) - (a.rk ?? -9) || a.n.localeCompare(b.n)).filter(p => !ql || (p.n + ' ' + p.id + ' ' + (p.pos || '')).toLowerCase().includes(ql)) : []
  const open = (label, ps) => { if (!ps.length) return; setDrill({ label, list: ps }); setQ(''); setTab('people') }
  const base = baseTitle(title)
  const head = tab === 'people' ? (drill ? `${base} · ${drill.label}: Employees` : `${base}: Employees`) : `${base} ${TAB_TITLE[tab]}`
  const N = ({ v, label, ps, b }) => v ? <button className="cellbtn" onClick={() => open(label, ps)}>{b ? <b>{fmtN(v)}</b> : fmtN(v)}</button> : <span className="formula">0</span>
  return <Modal wide title={head} sub={`${fmtN(tab === 'people' ? src.length : people.length)} employees${sub ? ' · ' + sub : ''}`} onClose={onClose}>
    <div className="tabs" style={{ marginBottom: 12 }}>{tabs.map(([k, l]) => <button key={k} aria-current={tab === k} onClick={() => { setTab(k); if (k !== 'people') setDrill(null) }}>{k === 'people' && drill ? `Employees (${fmtN(drill.list.length)})` : l}</button>)}</div>
    {tab !== 'people' ? <div className="tw"><table>
      <thead><tr><th>{tab === 'grade' ? 'Grade' : tab === 'function' ? 'Function' : 'Region'}</th>{mixed ? <><th className="num">Total</th>{TY.map(t => <th key={t[0]} className="num">{t[1]}</th>)}</> : <th className="num">Employees</th>}<th style={{ width: '38%' }}></th><th className="num">Share</th></tr></thead>
      <tbody>{rows.map(r => <tr key={String(r.k)}>
        <td><b>{r.label}</b></td>
        {mixed ? <><td className="num"><N v={r.n} label={r.label} ps={r.ps} b /></td>{TY.map(t => <td key={t[0]} className="num"><N v={r[t[0]]} label={`${r.label} · ${t[1]}`} ps={r.ps.filter(t[2])} /></td>)}</>
          : <td className="num"><N v={r.n} label={r.label} ps={r.ps} b /></td>}
        <td><div className="bar" style={{ minWidth: 80 }}>{TY.map(t => <i key={t[0]} style={{ width: r[t[0]] / max * 100 + '%', background: t[3] }} />)}</div></td>
        <td className="num">{Math.round(r.n / people.length * 100) ? Math.round(r.n / people.length * 100) + '%' : '-'}</td></tr>)}
        <tr className="tot"><td>Total</td>{mixed ? <><td className="num"><N v={people.length} label="all" ps={people} /></td>{TY.map(t => <td key={t[0]} className="num"><N v={people.filter(t[2]).length} label={t[1]} ps={people.filter(t[2])} /></td>)}</> : <td className="num"><N v={people.length} label="all" ps={people} /></td>}<td></td><td className="num">100%</td></tr>
      </tbody></table></div> : <>
      <div className="kvline" style={{ marginBottom: 8 }}>
        {drill && <span className="tagchip">{drill.label}<button type="button" aria-label="Show everyone" onClick={() => setDrill(null)}>×</button></span>}
        <input className="inp" placeholder="Search by name, code or position" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} />
      </div>
      <div className="tw scroll" style={{ maxHeight: 440 }}><table>
        <thead><tr><th>Name</th><th>Code</th><th>Grade</th><th>Type</th><th>Function</th><th>Region</th></tr></thead>
        <tbody>{list.slice(0, 800).map(p => <tr key={p.i} className={onPerson ? 'click' : ''} onClick={onPerson ? () => onPerson(p) : undefined} title={onPerson ? 'Open the reporting line' : undefined}>
          <td><b>{p.n}</b><div className="formula">{p.pos}</div></td><td>{p.id}</td><td style={{ whiteSpace: 'nowrap' }}>{p.g}</td>
          <td style={{ whiteSpace: 'nowrap' }}><TypeTag p={p} /></td><td>{F[p.f]}</td><td>{p.rg}</td></tr>)}
          {list.length > 800 && <tr><td colSpan={6} className="formula">Showing 800 of {fmtN(list.length)}. Search to narrow down.</td></tr>}
          {!list.length && <tr><td colSpan={6} className="formula">No one matches.</td></tr>}</tbody></table></div>
      </>}
  </Modal>
}

// The HBL logo: logo-light.png (green, for light backgrounds) and logo-dark.png (white, for dark backgrounds),
// in frontend/public. onDark: the place is dark in both themes (the sidebar), so the white logo is always used.
// If a file is missing, the green HBL box is shown.
export function Logo({ onDark }) {
  const [ok, setOk] = useState({ light: true, dark: true })
  const bad = k => () => setOk(o => ({ ...o, [k]: false }))
  if (!ok.dark || (!onDark && !ok.light)) return <div className="mark">HBL</div>
  if (onDark) return <span className="logo"><img src="/logo-dark.png" alt="HBL" onError={bad('dark')} /></span>
  return <span className="logo">
    <img className="logo-light" src="/logo-light.png" alt="HBL" onError={bad('light')} />
    <img className="logo-dark" src="/logo-dark.png" alt="HBL" onError={bad('dark')} /></span>
}

// ---------------------------------------------------------------- KPI tiles (the figures at the top of each insight page)
const ICONS = {
  people: <><circle cx="9" cy="8" r="3.2" /><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5" /><circle cx="17" cy="9" r="2.6" /><path d="M15.6 14.2c2.6-.3 4.5 1.3 5 4.8" /></>,
  fte: <><circle cx="10" cy="8" r="3.4" /><path d="M4 19.5c.6-3.3 3-5.3 6-5.3 1.3 0 2.5.4 3.5 1" /><path d="m15.4 17.6 2.1 2 3.6-4.1" /></>,
  ftc: <><circle cx="10" cy="8" r="3.4" /><path d="M4 19.5c.6-3.3 3-5.3 6-5.3" /><circle cx="17.5" cy="17" r="3.6" /><path d="M17.5 15.3v1.9l1.3.9" /></>,
  layers: <><path d="m12 3.5 8.5 4.6-8.5 4.6-8.5-4.6 8.5-4.6Z" /><path d="m3.5 12.3 8.5 4.6 8.5-4.6" /><path d="m3.5 16.4 8.5 4.6 8.5-4.6" /></>,
  managers: <><rect x="9" y="3" width="6" height="5" rx="1.3" /><rect x="3" y="16" width="6" height="5" rx="1.3" /><rect x="15" y="16" width="6" height="5" rx="1.3" /><path d="M12 8v4M6 16v-2.5h12V16" /></>,
  work: <><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M9 7V5.2c0-.7.5-1.2 1.2-1.2h3.6c.7 0 1.2.5 1.2 1.2V7M3 13h18" /></>,
  list: <><rect x="4" y="3" width="16" height="18" rx="2.2" /><path d="M8 8h8M8 12h8M8 16h5" /></>,
  tag: <><path d="M3.5 12V4.6c0-.6.5-1.1 1.1-1.1H12l8.6 8.6-8.5 8.5-8.6-8.6Z" /><circle cx="8" cy="8" r="1.5" /></>,
  bolt: <path d="M13 2.5 4.5 13.5h6.8l-1 8 8.7-11.2h-7l1-7.8Z" />,
  pin: <><path d="M12 21s-7-6.2-7-11.4a7 7 0 0 1 14 0C19 14.8 12 21 12 21Z" /><circle cx="12" cy="9.6" r="2.5" /></>,
  chat: <><path d="M4 5.5C4 4.7 4.7 4 5.5 4h13c.8 0 1.5.7 1.5 1.5v9c0 .8-.7 1.5-1.5 1.5H10l-4.5 4v-4h0c-.8 0-1.5-.7-1.5-1.5v-9Z" /><path d="M8 9h8M8 12.5h5" /></>,
  volume: <><path d="M4 20V11M9.3 20V6M14.6 20v-8M20 20V4" /></>,
  globe: <><circle cx="12" cy="12" r="8.5" /><path d="M3.5 12h17M12 3.5c2.4 2.3 3.6 5.1 3.6 8.5s-1.2 6.2-3.6 8.5c-2.4-2.3-3.6-5.1-3.6-8.5S9.6 5.8 12 3.5Z" /></>,
}
export function Icon({ name, size = 20 }) {
  return <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{ICONS[name]}</svg>
}
// a small ring: the share of the whole (track in a lighter step of the same colour)
export function Ring({ value, color = 'var(--teal)', track = 'var(--teal-soft)' }) {
  const r = 15, c = 2 * Math.PI * r, v = Math.max(0, Math.min(100, value || 0))
  return <svg viewBox="0 0 40 40" width="44" height="44" className="kring" aria-hidden="true">
    <circle cx="20" cy="20" r={r} fill="none" stroke={track} strokeWidth="5" />
    {v > 0 && <circle cx="20" cy="20" r={r} fill="none" stroke={color} strokeWidth="5" strokeLinecap="round" strokeDasharray={`${c * v / 100} ${c}`} transform="rotate(-90 20 20)" />}
    <text x="20" y="23.5" textAnchor="middle">{v ? Math.round(v) + '%' : '-'}</text></svg>
}
// a meter split into parts, with a 2px gap between the parts
export function Split({ parts }) {
  const tot = parts.reduce((a, p) => a + p.v, 0) || 1
  return <span className="ksplit" aria-hidden="true">{parts.filter(p => p.v > 0).map((p, i) => <i key={i} style={{ flexGrow: p.v / tot, background: p.color }} title={`${p.label}: ${Math.round(p.v).toLocaleString('en-US')}`} />)}</span>
}
// one bar per layer, stepping down
export function Steps({ n }) {
  const k = Math.max(1, Math.min(n || 0, 9))
  return <svg viewBox="0 0 48 34" width="48" height="34" className="ksteps" aria-hidden="true">{Array.from({ length: k }, (_, i) => {
    const w = 46 - i * (40 / k); return <rect key={i} x={(48 - w) / 2} y={i * (34 / k)} width={w} height={Math.max(2, 34 / k - 2)} rx="1.5" />
  })}</svg>
}
export function Kpi({ icon, label, value, sub, onClick, viz, foot, disabled, tone }) {
  const body = <>
    <span className={'kpi-ic' + (tone ? ' ' + tone : '')}><Icon name={icon} /></span>
    <span className="kpi-tx"><span className="kpi-l">{label}</span><b>{value}</b>{sub && <em>{sub}</em>}</span>
    {viz && <span className="kpi-viz">{viz}</span>}
    {foot && <span className="kpi-foot">{foot}</span>}</>
  return onClick ? <button type="button" className="kpi" onClick={onClick} disabled={disabled}>{body}</button> : <div className="kpi">{body}</div>
}

// ---------------------------------------------------------------- infographics for the figure boxes
// a row of person figures: `on` of `n` filled (for example 3 of 10 = 27%)
export function People({ share, n = 10, color = 'var(--teal)', off = 'var(--line)' }) {
  const on = Math.round((share || 0) / 100 * n)
  return <svg viewBox={`0 0 ${n * 16} 26`} className="ig-people" aria-hidden="true">{Array.from({ length: n }, (_, i) =>
    <g key={i} transform={`translate(${i * 16 + 1},0)`} fill={i < on ? color : off}><circle cx="7" cy="5" r="4.2" /><path d="M0 25c0-7 3.1-11 7-11s7 4 7 11z" /></g>)}</svg>
}
// layers as a centred pyramid, widest at the bottom (square-root widths so small layers stay visible)
export function Pyramid({ values }) {
  const mx = Math.max(1, ...values), h = Math.max(4, Math.min(9, 60 / Math.max(1, values.length) - 2))
  return <svg viewBox={`0 0 160 ${values.length * (h + 2)}`} className="ig-pyr" aria-hidden="true">{values.map((v, i) => {
    const w = 12 + 146 * Math.sqrt(v / mx); return <rect key={i} x={(160 - w) / 2} y={i * (h + 2)} width={w} height={h} rx="2" fill="var(--teal)" fillOpacity={0.3 + 0.7 * (i + 1) / values.length}><title>{`Layer ${i + 1}: ${v}`}</title></rect>
  })}</svg>
}
// one manager and their team: the average span, drawn
export function SpanArt({ span }) {
  const k = Math.max(1, Math.min(8, Math.round(span || 0))), w = 160, step = w / (k + 1)
  return <svg viewBox="0 0 160 50" className="ig-span" aria-hidden="true">
    <rect x="66" y="1" width="28" height="15" rx="4" fill="var(--teal)" />
    <path d={`M80 16v8M${step} 24H${w - step}` + Array.from({ length: k }, (_, i) => `M${step * (i + 1)} 24v8`).join('')} stroke="var(--ink-3)" strokeWidth="1.4" fill="none" />
    {Array.from({ length: k }, (_, i) => <rect key={i} x={step * (i + 1) - 9} y="32" width="18" height="14" rx="3.5" fill="var(--ftc)" />)}</svg>
}
// a ring split into parts
export function Donut({ parts, size = 64, label }) {
  const r = 15.5, c = 2 * Math.PI * r, tot = parts.reduce((a, p) => a + p.v, 0) || 1; let off = 0
  return <svg viewBox="0 0 40 40" width={size} height={size} className="ig-donut" aria-hidden="true">
    <circle cx="20" cy="20" r={r} fill="none" stroke="var(--surface-2)" strokeWidth="6" />
    {parts.map((p, i) => { const len = c * p.v / tot, el = <circle key={i} cx="20" cy="20" r={r} fill="none" stroke={p.color} strokeWidth="6" strokeDasharray={`${Math.max(0, len - 0.6)} ${c}`} strokeDashoffset={-off} transform="rotate(-90 20 20)" />; off += len; return el })}
    {label && <text x="20" y="23.2" textAnchor="middle">{label}</text>}</svg>
}
// small horizontal bars, largest first (for example employees by function)
export function MiniBars({ items, max = 5, color = 'var(--teal)' }) {
  const top = items.slice(0, max), mx = Math.max(1, ...top.map(x => x.v))
  return <div className="ig-bars">{top.map((x, i) => <div key={i} title={`${x.label}: ${x.v}`}><span>{x.label}</span><i><i style={{ width: Math.max(4, x.v / mx * 100) + '%', background: color }} /></i></div>)}</div>
}
// a figure box with an infographic under the number
export function InfoBox({ icon, label, value, sub, art, aside, tone = 'teal', onClick, disabled }) {
  const body = <>
    <span className="ib-head"><span className="ib-ic"><Icon name={icon} size={17} /></span><span className="ib-l">{label}</span></span>
    <span className="ib-mid"><span><b>{value}</b>{sub && <em>{sub}</em>}</span>{aside}</span>
    {art && <span className="ib-art">{art}</span>}</>
  const cls = 'ibox t-' + tone
  return onClick ? <button type="button" className={cls} onClick={onClick} disabled={disabled}>{body}</button> : <div className={cls}>{body}</div>
}
