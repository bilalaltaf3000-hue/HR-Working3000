import React, { useEffect, useRef, useState } from 'react'
import { fmt, short, pcs } from '../org.js'
import { Table } from '../ui.jsx'

export default function Opportunities({ org, go, showLine, embedded, et = '' }) {
  // with FTE or FTC selected, spans count only that type of direct report, and employee findings list only that type
  const isT = p => !et || (et === 'FTE' ? p.fte : !p.fte)
  const { MGR, ROOT, C, P, F, narrow, wide, biggest, fstats } = org
  const hasTeam = p => p.kids.some(k => org.counted(k))
  const cross = org.cross.filter(isT), seniorNoTeam = C.filter(p => isT(p) && p.rk >= org.senior && !hasTeam(p))
  const [open, setOpen] = useState(null)
  const detail = useRef(null)
  useEffect(() => setOpen(null), [org])
  const pass = MGR.filter(m => m !== ROOT && m.nk === 1 && m.kids.find(k => org.counted(k))?.kids.length)
  const idleTL = C.filter(p => isT(p) && /team lead|supervisor/i.test(p.pos) && !hasTeam(p))
  const inv = C.filter(p => isT(p) && p.m >= 0 && P[p.m] !== ROOT && p.rk > 0 && P[p.m].rk > 0 && p.rk > P[p.m].rk)
  const same = C.filter(p => isT(p) && p.m >= 0 && P[p.m] !== ROOT && p.rk > 0 && p.rk === P[p.m].rk)
  const deepF = fstats.filter(s => s.hc >= 20 && s.layers >= 6 && s.span < 5)   // deeper than 5 layers (the Group Head is Layer 1)
  const c = {
    mgr: { h: 'Manager', v: r => r.n }, name: { h: 'Name', v: r => r.n }, grade: { h: 'Grade', v: r => r.g }, pos: { h: 'Position', v: r => short(r.pos || '', 40) },
    func: { h: 'Function', v: r => short(F[r.f]) }, direct: { h: 'Direct', num: 1, v: r => fmt(r.nk) }, team: { h: 'Total Team', num: 1, v: r => fmt(r.team) },
    boss: { h: 'Manager', v: r => P[r.m].n }, bossp: { h: "Manager's Position", v: r => short(P[r.m].pos || '', 40) }, bossg: { h: "Manager's Grade", v: r => P[r.m].g },
  }
  const tlInBig = biggest.kids.filter(k => /team lead/i.test(k.pos) && !k.kids.length).length
  const O = [
    { k: 'Delayer', tone: 'p-warn', t: 'Single-Report Managers', n: pass.length, u: 'managers', d: 'Each of these managers has exactly one direct report, who in turn manages a team. The extra layer adds an approval step without widening the span of control.', a: 'Assess whether the two roles can be combined, or the team re-aligned to the next manager up.', rows: pass, cols: [c.mgr, c.pos, c.grade, c.func, { h: 'Only Direct Report', v: r => { const k = r.kids.find(x => org.counted(x)) || r.kids[0]; return k ? <>{k.n}<div className="formula">{[short(k.pos || '', 40), k.g].filter(Boolean).join(' · ')}</div></> : '' } }, c.team] },
    { k: 'Delayer', tone: 'p-warn', t: 'Narrow Spans of Control', n: narrow.length, u: 'managers', d: 'These managers supervise one or two direct reports. Narrow spans add supervisory cost and lengthen decision chains.', a: 'Consolidate adjacent small teams under a single lead, beginning with managers in the same function.', rows: [...narrow].sort((a, b) => b.rk - a.rk), cols: [c.mgr, c.pos, c.grade, c.func, c.direct, c.team] },
    { k: 'Rebalance', tone: 'p-bad', t: 'Spans Too Wide for Effective Supervision', n: wide.length, u: 'managers', d: `Each manager has more than 15 direct reports; the largest span is ${fmt(biggest.nk)} in ${F[biggest.f]}.`, a: 'Introduce team leads between the manager and the team, using existing team lead positions first.', rows: [...wide].sort((a, b) => b.nk - a.nk), cols: [c.mgr, c.pos, c.grade, c.func, c.direct, { h: 'FTC Share', num: 1, v: r => pcs(r.kids.filter(k => !k.fte).length, r.kids.length) }] },
    { k: 'Rebalance', tone: 'p-bad', t: 'Team Leads and Supervisors Without Direct Reports', n: idleTL.length, u: 'employees', d: `The position title indicates a team lead or supervisory role, but no one reports to them in the master data.${tlInBig ? ` ${tlInBig} of them sit within the team of ${fmt(biggest.nk)}.` : ''}`, a: 'Map employees to these roles, which also relieves wide spans at no additional cost, or correct the position title.', rows: [...idleTL].sort((a, b) => b.rk - a.rk), cols: [c.name, c.pos, c.grade, c.func, c.boss, c.bossp, c.bossg] },
    { k: 'Grade', tone: 'p-bad', t: 'Employees Graded Above Their Manager', n: inv.length, u: 'employees', d: 'The employee holds a higher grade than their line manager. This usually indicates a tagging error or an outdated reporting line.', a: 'Confirm the reporting line with the function POC and correct the master data or the grade.', rows: [...inv].sort((a, b) => b.rk - a.rk), cols: [c.name, c.pos, c.grade, c.boss, c.bossp, c.bossg, c.func] },
    { k: 'Grade', tone: 'p-warn', t: 'Employees on the Same Grade as Their Manager', n: same.length, u: 'employees', d: 'This can be intentional, but when widespread it compresses the grade structure.', a: 'Review whether these are peer roles placed under a lead, and whether the lead role is graded correctly.', rows: [...same].sort((a, b) => b.rk - a.rk), cols: [c.name, c.pos, c.grade, c.boss, c.bossp, c.bossg, c.func] },
    { k: 'Delayer', tone: 'p-warn', t: 'Deep Functions with Narrow Spans', n: deepF.length, u: 'functions', d: 'Deeper than five layers (the Group Head is Layer 1) while the average manager supervises fewer than five employees.', a: 'Prioritise these functions for layer reduction.', rows: deepF.map(s => ({ ...s, i: s.head ? s.head.i : ROOT.i })), cols: [{ h: 'Function', v: r => r.name }, { h: 'Employees', num: 1, v: r => fmt(r.hc) }, { h: 'Layers', num: 1, v: r => fmt(r.layers) }, { h: 'Avg Span', num: 1, v: r => fmt(Math.round(r.span)) }, { h: 'Managers', num: 1, v: r => fmt(r.mg) }] },
    { k: 'Senior roles', tone: 'p-warn', t: 'Senior Grades Without Direct Reports', n: seniorNoTeam.length, u: 'employees', d: 'Some are specialist or advisory roles; others may have reporting lines missing from the master data.', a: 'Ask function POCs to confirm each as a specialist role or to correct the reporting line.', rows: [...seniorNoTeam].sort((a, b) => b.rk - a.rk), cols: [c.name, c.pos, c.grade, c.func, c.boss, c.bossp] },
    { k: 'Tagging', tone: 'p-ok', t: 'Reporting Lines Across Functions', n: cross.length, u: 'employees', d: 'These employees report to a manager tagged to another function, which distorts the employee count by function.', a: 'Function POCs to confirm the correct function during data capture.', rows: cross, cols: [c.name, c.pos, c.grade, c.func, c.boss, c.bossp, c.bossg, { h: "Manager's Function", v: r => short(F[P[r.m].f]) }] },
  ].filter(o => o.n > 0)
  const involved = new Set(); O.forEach(o => o.u !== 'functions' && o.rows.forEach(r => involved.add(r.i)))
  const sel = open !== null ? O[open] : null
  const Wrap = embedded ? 'div' : 'section'
  return <Wrap className={embedded ? '' : 'view on'}>
    {!embedded && <><h1>Structure Opportunities</h1></>}
    <div className="totals">
      <div><b>{fmt(O.length)}</b><span>Findings</span></div><div><b>{fmt(involved.size)}</b><span>Employees Involved</span></div>
      <div><b>{fmt(new Set([...narrow, ...pass]).size)}</b><span>Managers in Layer-Reduction Candidates</span></div>
      <div><b>{fmt(idleTL.length)}</b><span>Team Lead Roles Available to Relieve Wide Spans</span></div>
    </div>
    <div className="opps">{O.map((o, i) => <div key={i} className="opp">
      <div className="top"><span className={'pill ' + o.tone}>{o.k}</span></div><h3>{o.t}</h3>
      <p style={{ color: 'var(--ink)' }}><b>Next Step:</b> {o.a}</p>
      <div className="foot"><div className="big">{fmt(o.n)}<small>{o.u}</small></div>
        <button className="btn" onClick={() => { setOpen(open === i ? null : i); setTimeout(() => detail.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50) }}>{open === i ? 'Hide the List' : 'View Employees'}</button></div></div>)}</div>
    {sel && <div className="panel" ref={detail} style={{ marginTop: 18 }}>
      <div className="rhead"><h2>{sel.t}</h2><button className="btn" onClick={() => setOpen(null)}>Close</button></div>
      <p className="sub">{fmt(sel.n)} {sel.u}</p>
      <div className="tw scroll" style={{ maxHeight: 480 }}><Table rows={sel.rows} cols={sel.cols} onRow={r => { const p = P[r.i]; if (showLine && p) showLine(p.id); else go('org', r.i) }} /></div></div>}
    {!O.length && <div className="empty">No structural findings for this selection.</div>}
  </Wrap>
}
