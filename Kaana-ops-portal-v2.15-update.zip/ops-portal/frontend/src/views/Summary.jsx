import React, { useEffect, useState } from 'react'
import { api } from '../api.js'
import { vfmt } from '../org.js'
import { Modal } from '../ui.jsx'

const n0 = v => Number(v || 0).toLocaleString('en-US')
const when = s => s ? new Date(s + ':00Z').toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : ''
const volTxt = a => `${vfmt(a.volume)} ${(a.freq || '').toLowerCase()}`.trim()

// The codes of employees with recorded activities: the organogram shows the summary button only for them
export function useSumCodes(on) {
  const [s, setS] = useState(null)
  useEffect(() => { if (!on) { setS(null); return } api('/api/sum/codes').then(r => setS(new Set(r.codes))).catch(() => setS(null)) }, [on])
  return s
}

// The pop-up: the AI's summary of the person's recorded work, their volume-based and non-volume-based work
export function SummaryModal({ code, onClose, notify }) {
  const [d, setD] = useState(null)
  const [all, setAll] = useState(false)
  const [busy, setBusy] = useState(false)
  const load = () => api('/api/sum/person/' + encodeURIComponent(code)).then(setD).catch(e => { notify && notify(e.message, true); onClose() })
  useEffect(() => { load() }, [code])
  if (!d) return <Modal wide title="Loading…" onClose={onClose}><div className="loading">Loading…</div></Modal>
  const write = async () => { setBusy(true); try { await api(`/api/sum/person/${encodeURIComponent(code)}/write`, { method: 'POST' }); await load() } catch (e) { notify && notify(e.message, true) } finally { setBusy(false) } }
  const sub = [d.function, d.grade, d.team ? `${n0(d.team)} direct report${d.team === 1 ? '' : 's'}` : '', d.region].filter(Boolean).join(' · ')
  return <Modal wide title={`${d.name}${d.position ? ' · ' + d.position : ''}`} sub={sub} onClose={onClose}>
    {d.summary ? <div className="sm-ai"><b>Summary of work</b><br />{d.summary}
      <small>Summary from {n0(d.activities)} recorded activit{d.activities === 1 ? 'y' : 'ies'} · written {when(d.at)} · on-premise AI{d.stale ? <> · <span className="stale">the activities have changed since; the next run updates it</span></> : ''}</small></div>
      : <div className="sm-ai"><b>Summary of work</b><br /><span className="formula">{d.few ? 'Too few activities recorded for a written summary; the recorded work is listed below.' : 'No summary written yet. The admin writes them in Admin, AI Server, Work Summaries.'}</span></div>}
    <div className="sm-k"><div><b>{n0(d.activities)}</b><span>activities</span></div><div><b>{n0(d.volume_based)}</b><span>volume-based</span></div>
      <div><b>{n0(d.non_volume)}</b><span>non-volume-based</span></div><div><b>{d.items_day ? '≈ ' + n0(d.items_day) : '-'}</b><span>items a day (volume-based)</span></div></div>
    {!all ? <div className="sm-two">
      <div><h4>Volume-based work</h4>{d.volume.length ? <ul>{d.volume.map(a => <li key={a.id} title={a.desc}>{a.text}<span className="v">{volTxt(a)}</span></li>)}</ul> : <p className="formula">None recorded.</p>}</div>
      <div><h4>Non-volume-based work</h4>{d.non.length ? <ul>{d.non.map(a => <li key={a.id} title={a.desc}>{a.text}</li>)}</ul> : <p className="formula">None recorded.</p>}</div>
    </div> : <div className="tw scroll sm-all" style={{ maxHeight: '50vh' }}><table><thead><tr><th>Activity</th><th>Category</th><th>Frequency</th><th className="num">Volume</th></tr></thead>
      <tbody>{[...d.volume, ...d.non].map(a => <tr key={a.id}><td>{a.desc || <i className="formula">No description</i>}</td><td>{a.cat || '-'}</td><td>{a.freq || '-'}</td><td className="num">{a.volume ? vfmt(a.volume) : '-'}</td></tr>)}</tbody></table></div>}
    <div className="sm-foot"><span>Indicative: written by the bank's on-premise AI from the activities recorded in the portal only.</span>
      <span className="row-actions">{d.can_write && <button className="btn" disabled={busy} onClick={write}>{busy ? 'Writing…' : d.written ? 'Write again now' : 'Write now'}</button>}
        <button className="btn" onClick={() => setAll(x => !x)}>{all ? 'Back to summary' : 'View all activities'}</button></span></div>
  </Modal>
}

// Admin → AI Server: the background run that writes the summaries
export function SummaryRunPanel({ notify }) {
  const [st, setSt] = useState(null)
  const [fns, setFns] = useState([])
  const [fid, setFid] = useState('')
  const load = () => api('/api/sum/status').then(setSt).catch(e => notify(e.message, true))
  useEffect(() => { load(); api('/api/capture/functions').then(r => setFns([...r].sort((a, b) => a.name.localeCompare(b.name)))).catch(() => {}) }, [])
  const run = st?.run, going = run && (run.status === 'queued' || run.status === 'running')
  useEffect(() => { if (!going) return; const t = setInterval(load, 3000); return () => clearInterval(t) }, [going])
  if (!st) return <div className="panel"><div className="loading">Loading…</div></div>
  const start = async onlyChanged => {
    try { await api('/api/sum/run', { method: 'POST', body: { function_id: fid ? +fid : null, only_changed: onlyChanged } }); notify('Writing the summaries in the background.'); load() } catch (e) { notify(e.message, true) }
  }
  const stop = async () => { try { await api('/api/sum/run/stop', { method: 'POST' }); notify('Stopping after the current requests…') } catch (e) { notify(e.message, true) } }
  return <div className="panel vac-form"><h2>Work Summaries</h2>
    <p className="sub">The AI writes a short summary of each employee's recorded work, shown from the box button on organogram cards. Written in the background and saved, so the pop-up opens at once.</p>
    <div className="sm-k"><div><b>{n0(st.with_activities)}</b><span>employees with activities</span></div><div><b>{n0(st.written)}</b><span>summaries up to date</span></div>
      <div><b>{n0(st.stale)}</b><span>activities changed since</span></div><div><b>{n0(st.missing)}</b><span>not written yet</span></div></div>
    <label>Function<select className="inp" value={fid} onChange={e => setFid(e.target.value)}><option value="">All functions</option>{fns.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select></label>
    {going ? <div className="row-actions"><span className="ro-prog"><i><b style={{ width: (run.total ? (run.done + run.failed) / run.total * 100 : 0) + '%' }} /></i><span>{n0(run.done + run.failed)} of {n0(run.total)}</span></span><button className="btn" onClick={stop}>Stop</button></div>
      : <div className="row-actions"><button className="btn pri" onClick={() => start(true)}>Write New and Changed</button><button className="btn" onClick={() => start(false)}>Write All Again</button></div>}
    {run && !going && <p className="formula">Last run: {run.status} · {n0(run.done)} written{run.failed ? `, ${n0(run.failed)} failed` : ''} · {when((run.finished_at || '').slice(0, 16))}{run.error ? ` · ${run.error.slice(0, 200)}` : ''}</p>}
    <p className="formula">One employee takes a few seconds; all of COSO can take a few hours, so run it after office hours. Only one AI run (this or Role Overlap) goes at a time.</p>
  </div>
}
