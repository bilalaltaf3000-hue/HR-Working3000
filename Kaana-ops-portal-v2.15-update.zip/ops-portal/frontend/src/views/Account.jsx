import React, { useState } from 'react'
import { api } from '../api.js'

export default function Account({ user, notify }) {
  const [f, setF] = useState({ current: '', new1: '', new2: '' })
  const [err, setErr] = useState('')
  const save = async e => {
    e.preventDefault(); setErr('')
    if (f.new1.length < 8) return setErr('New password must be at least 8 characters.')
    if (f.new1 !== f.new2) return setErr('The two new passwords do not match.')
    try { await api('/api/auth/password', { method: 'POST', body: { current: f.current, new: f.new1 } }); notify('Password changed.'); setF({ current: '', new1: '', new2: '' }) }
    catch (ex) { setErr(ex.message) }
  }
  const field = (k, label, ac) => <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13, fontWeight: 600, color: 'var(--ink-2)' }}>{label}
    <input className="inp" type="password" autoComplete={ac} value={f[k]} onChange={e => setF({ ...f, [k]: e.target.value })} /></label>
  return <section className="view on">
    <h1>My Account</h1>
    <p className="lede">Signed in as {user.username}{user.function_name ? `, POC for ${user.function_name}` : ''}.</p>
    <form className="panel" style={{ maxWidth: 420, display: 'flex', flexDirection: 'column', gap: 14 }} onSubmit={save}>
      <h2>Change Password</h2>
      {field('current', 'Current password', 'current-password')}{field('new1', 'New password', 'new-password')}{field('new2', 'Repeat new password', 'new-password')}
      {err && <div className="err">{err}</div>}
      <button className="btn pri" style={{ alignSelf: 'flex-start' }}>Save</button>
    </form>
  </section>
}
