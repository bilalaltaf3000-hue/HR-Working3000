import React, { useEffect, useState } from 'react'
import { api, download } from '../api.js'
import { Modal } from '../ui.jsx'

// Staff segmentation tables: written by hand by the admin for a function (e.g. Credit Administration) and opened
// from a button on that function's dashboard. Every figure is typed in; nothing is loaded or reconciled.
const n0 = v => v === null || v === undefined || v === '' ? '' : Number(v).toLocaleString('en-US')
const tot = r => (r.fte || 0) + (r.ftc || 0)

export function useSegTables() {
  const [list, setList] = useState([])
  useEffect(() => { api('/api/seg').then(setList).catch(() => setList([])) }, [])
  return list
}

export function SegTable({ d }) {
  const uni = d.universe_label + (d.as_of ? ` as of ${d.as_of}` : '')
  const t = d.total
  return <div className="tw seg-tw"><table className="segt">
    <thead><tr><th>{d.title}</th><th className="num">Total FTEs</th><th className="num">Total FTCs</th><th className="num">Total</th><th className="num seg-u">{uni}</th></tr></thead>
    <tbody>{d.rows.map((r, i) => <tr key={i}>
      <td>{r.name}</td><td className="num">{n0(r.fte)}</td><td className="num">{n0(r.ftc)}</td><td className="num">{n0(tot(r) || '')}</td>
      <td className={'num seg-u' + (r.universe === null && !r.note ? ' seg-na' : '')}>{r.universe !== null ? n0(r.universe) : r.note ? '' : '–'}{r.note && <small>{r.note}</small>}</td></tr>)}
      <tr className="tot"><td>Grand Total</td><td className="num">{n0(t.fte)}</td><td className="num">{n0(t.ftc)}</td><td className="num">{n0(tot(t))}</td><td className="num">{n0(t.universe)}</td></tr>
    </tbody></table></div>
}

export function SegModal({ fid, onClose, notify }) {
  const [d, setD] = useState(null)
  useEffect(() => { api('/api/seg/' + fid).then(setD).catch(e => { notify && notify(e.message, true); onClose() }) }, [fid])
  if (!d) return null
  return <Modal wide title={d.title} sub={`${d.function}${d.as_of ? ` · ${d.universe_label} as of ${d.as_of}` : ''}`} onClose={onClose}>
    <SegTable d={d} />
    <div className="row-actions" style={{ justifyContent: 'space-between', marginTop: 12 }}>
      <span className="formula">{d.updated_at ? `Updated ${d.updated_at}` : ''}</span>
      <button className="btn" onClick={() => download(`/api/seg/${fid}/export`).catch(e => notify && notify(e.message, true))}>Export Excel</button></div>
  </Modal>
}

// ---------------------------------------------------------------- admin: write and edit the table
const blankRow = () => ({ name: '', fte: '', ftc: '', universe: '', note: '' })
const num = v => v === '' || v === null || v === undefined ? null : Number(String(v).replace(/,/g, ''))

export function SegAdminTab({ notify }) {
  const [fns, setFns] = useState([])
  const [fid, setFid] = useState('')
  const [d, setD] = useState(null)
  const [have, setHave] = useState([])
  const loadList = () => api('/api/seg').then(setHave).catch(() => {})
  useEffect(() => {
    api('/api/capture/functions').then(r => {
      const s = [...r].sort((a, b) => a.name.localeCompare(b.name)); setFns(s)
      const cad = s.find(f => /credit admin/i.test(f.name)); setFid(String((cad || s[0] || {}).id || ''))
    }).catch(e => notify(e.message, true)); loadList()
  }, [])
  useEffect(() => {
    if (!fid) return
    setD(null)
    api('/api/seg/' + fid).then(x => setD({ ...x, rows: x.rows.length ? x.rows.map(r => ({ ...r, fte: r.fte ?? '', ftc: r.ftc ?? '', universe: r.universe ?? '' })) : [blankRow()] })).catch(e => notify(e.message, true))
  }, [fid])
  const setRow = (i, k, v) => setD(x => ({ ...x, rows: x.rows.map((r, j) => j === i ? { ...r, [k]: v } : r) }))
  const move = (i, by) => setD(x => { const rows = [...x.rows]; const j = i + by; if (j < 0 || j >= rows.length) return x; [rows[i], rows[j]] = [rows[j], rows[i]]; return { ...x, rows } })
  const save = async () => {
    const bad = d.rows.find(r => ['fte', 'ftc', 'universe'].some(k => r[k] !== '' && isNaN(num(r[k]))))
    if (bad) { notify(`${bad.name || 'A row'}: figures must be numbers.`, true); return }
    try {
      const r = await api('/api/seg/' + fid, { method: 'PUT', body: { title: d.title, universe_label: d.universe_label, as_of: d.as_of, rows: d.rows.map(r => ({ name: r.name, note: r.note || '', fte: num(r.fte), ftc: num(r.ftc), universe: num(r.universe) })) } })
      setD({ ...r, rows: r.rows.length ? r.rows.map(x => ({ ...x, fte: x.fte ?? '', ftc: x.ftc ?? '', universe: x.universe ?? '' })) : [blankRow()] }); notify('Table saved. It shows on the function\'s dashboard.'); loadList()
    } catch (e) { notify(e.message, true) }
  }
  const remove = async () => {
    if (!window.confirm('Remove this table? The button disappears from the dashboard.')) return
    try { await api('/api/seg/' + fid, { method: 'DELETE' }); notify('Table removed.'); setD(x => ({ ...x, rows: [blankRow()] })); loadList() } catch (e) { notify(e.message, true) }
  }
  const preview = d && { ...d, rows: d.rows.filter(r => r.name || r.fte !== '' || r.ftc !== '' || r.universe !== '').map(r => ({ ...r, fte: num(r.fte), ftc: num(r.ftc), universe: num(r.universe) })) }
  if (preview) preview.total = { fte: preview.rows.reduce((a, r) => a + (r.fte || 0), 0), ftc: preview.rows.reduce((a, r) => a + (r.ftc || 0), 0), universe: preview.rows.reduce((a, r) => a + (r.universe || 0), 0) }
  return <div>
    <p className="sub">Write a staff segmentation table for a function. A button with its title appears at the top of that function's dashboard for everyone who can see the function. All figures are typed in here.</p>
    <div className="kvline" style={{ gap: 12, flexWrap: 'wrap' }}>
      <label className="fld"><span className="fl">Function</span><select className="inp" value={fid} onChange={e => setFid(e.target.value)}>
        {fns.map(f => <option key={f.id} value={f.id}>{f.name}{have.some(h => h.function_id === f.id) ? ' · has a table' : ''}</option>)}</select></label>
      {d && <><label className="fld"><span className="fl">Title (also the button)</span><input className="inp" value={d.title} onChange={e => setD({ ...d, title: e.target.value })} /></label>
        <label className="fld"><span className="fl">Last column heading</span><input className="inp" value={d.universe_label} onChange={e => setD({ ...d, universe_label: e.target.value })} /></label>
        <label className="fld"><span className="fl">As of</span><input className="inp" value={d.as_of} placeholder="30.9.2026" onChange={e => setD({ ...d, as_of: e.target.value })} style={{ width: 130 }} /></label></>}
    </div>
    {d && <>
      <div className="tw" style={{ marginTop: 12 }}><table className="seg-ed">
        <thead><tr><th style={{ width: 34 }}></th><th>Segment</th><th className="num">FTEs</th><th className="num">FTCs</th><th className="num">Total</th><th className="num">{d.universe_label}</th><th>Note under the figure (optional)</th><th></th></tr></thead>
        <tbody>{d.rows.map((r, i) => <tr key={i}>
          <td className="seg-mv"><button type="button" title="Move up" onClick={() => move(i, -1)}>▲</button><button type="button" title="Move down" onClick={() => move(i, 1)}>▼</button></td>
          <td><input className="inp" value={r.name} onChange={e => setRow(i, 'name', e.target.value)} placeholder="e.g. Agriculture - Core" /></td>
          <td><input className="inp num" value={r.fte} onChange={e => setRow(i, 'fte', e.target.value)} /></td>
          <td><input className="inp num" value={r.ftc} onChange={e => setRow(i, 'ftc', e.target.value)} /></td>
          <td className="num">{n0((num(r.fte) || 0) + (num(r.ftc) || 0) || '')}</td>
          <td><input className="inp num" value={r.universe} onChange={e => setRow(i, 'universe', e.target.value)} placeholder="blank: –" /></td>
          <td><input className="inp" value={r.note || ''} onChange={e => setRow(i, 'note', e.target.value)} placeholder={i === 0 ? "e.g. Collaborative = 117 · Standalone = 570" : ""} /></td>
          <td><button type="button" className="linkbtn" onClick={() => setD(x => ({ ...x, rows: x.rows.filter((_, j) => j !== i) }))}>Remove</button></td></tr>)}
        </tbody></table></div>
      <div className="row-actions" style={{ marginTop: 10, justifyContent: 'space-between' }}>
        <button className="btn" onClick={() => setD(x => ({ ...x, rows: [...x.rows, blankRow()] }))}>Add Row</button>
        <span style={{ display: 'flex', gap: 8 }}>{have.some(h => h.function_id === +fid) && <button className="btn" onClick={remove}>Remove Table</button>}<button className="btn pri" onClick={save}>Save</button></span></div>
      <h3 className="rv-h2">Preview</h3>
      <SegTable d={preview} />
      <p className="formula">Totals add up automatically. {d.updated_at ? `Last saved ${d.updated_at} by ${d.updated_by}.` : 'Not saved yet.'}</p>
    </>}
  </div>
}
