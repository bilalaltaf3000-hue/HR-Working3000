import React, { useEffect, useState } from 'react'
import { api, download } from '../api.js'

const FORMATS = [
  // { k: 'summary', t: 'One-page summary', d: 'A single PDF page for an executive review: headline figures, top activity themes, functions and structure findings.', ic: '1 PG' },
  { k: 'pdf', t: 'PDF report', d: 'Executive report: structure, employees, layers, service and support, regions and opportunities.', ic: 'PDF' },
  { k: 'pptx', t: 'PowerPoint deck', d: 'Ready-to-present slides with editable native charts and an organogram slide.', ic: 'PPT' },
  { k: 'html', t: 'Web page', d: 'A single file that opens in any browser, works offline and can be emailed.', ic: 'HTML' },
  { k: 'xlsx', t: 'Excel workbook', d: 'All the data, including every employee activity in the data capture template layout.', ic: 'XLS' },
]

export default function ExportDialog({ user, includeFlagged, notify, close, sel = [], units = [], groupLabel = 'COSO' }) {
  const [fns, setFns] = useState([])
  const [scope, setScope] = useState(sel.length ? 'sel' : '')
  const [fmt, setFmt] = useState('pdf')
  const [flag, setFlag] = useState(includeFlagged)
  const [busy, setBusy] = useState(false)
  useEffect(() => { api('/api/capture/functions').then(r => { setFns(r); if (r.length === 1) setScope(String(r[0].id)) }).catch(() => {}) }, [])
  useEffect(() => { const k = e => e.key === 'Escape' && close(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [])
  const go = async () => {
    setBusy(true)
    const q = new URLSearchParams({ include_flagged: flag ? 'true' : 'false' }); if (scope === 'sel') q.set('functions', sel.join(',')); else if (scope) q.set('functions', scope)
    units.forEach(u => q.append('units', u))
    try { await download(`/api/export/${fmt}?${q}`, fmt === 'summary' ? 'summary.pdf' : `report.${fmt}`); notify('Export ready. Check your downloads.'); close() }
    catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  return <div role="dialog" aria-modal="true" aria-label="Export" onClick={close}
    style={{ position: 'fixed', inset: 0, background: 'rgba(0,30,26,.45)', zIndex: 80, display: 'grid', placeItems: 'center', padding: 16 }}>
    <div className="panel" onClick={e => e.stopPropagation()} style={{ width: '100%', maxWidth: 720, maxHeight: '90vh', overflow: 'auto' }}>
      <div className="rhead"><h2 style={{ fontSize: 20 }}>Export</h2><button className="btn" onClick={close} aria-label="Close">✕</button></div>
      <p className="sub">Exports use the same numbers as the dashboard and include only what you have access to.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', gap: 10, marginBottom: 16 }}>
        {FORMATS.map(f => <button key={f.k} onClick={() => setFmt(f.k)} aria-pressed={fmt === f.k}
          style={{ all: 'unset', cursor: 'pointer', border: `2px solid ${fmt === f.k ? 'var(--teal)' : 'var(--line)'}`, background: fmt === f.k ? 'var(--teal-soft)' : 'var(--surface)', borderRadius: 12, padding: 14, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <span style={{ display: 'inline-grid', placeItems: 'center', width: 42, height: 42, borderRadius: 9, background: 'var(--teal)', color: '#fff', fontWeight: 800, fontSize: 12 }}>{f.ic}</span>
          <b style={{ fontSize: 14 }}>{f.t}</b><span className="formula" style={{ lineHeight: 1.4 }}>{f.d}</span></button>)}
      </div>
      <div className="kvline">
        <label className="formula" style={{ minWidth: 60 }}>Scope</label>
        <select value={scope} onChange={e => setScope(e.target.value)} style={{ flex: 1 }}>
          {fns.length > 1 && <option value="">{user.sees_everything ? `${groupLabel}: all functions` : 'All functions I can see'}</option>}
          {sel.length > 0 && <option value="sel">Current dashboard selection ({sel.length === 1 ? fns.find(f => f.id === sel[0])?.name || '1 function' : sel.length + ' functions'})</option>}
          {fns.map(f => <option key={f.id} value={f.id}>{f.name} only</option>)}
        </select>
      </div>
      <label className="formula" style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '6px 0 16px' }}><input type="checkbox" checked={flag} onChange={e => setFlag(e.target.checked)} />Count employees marked "exclude" in employee count and spans</label>
      <p className="formula" style={{ marginTop: 0 }}>{'A single-function export also lists each employee\'s recorded activities. The Excel workbook always includes every activity in scope.'}</p>
      <div className="row-actions"><button className="btn pri" onClick={go} disabled={busy}>{busy ? 'Preparing…' : `Download ${FORMATS.find(f => f.k === fmt).t}`}</button><button className="btn" onClick={close}>Cancel</button></div>
    </div>
  </div>
}
