"""Put back activity fields from a backup database, for one function (or all), by activity ID.

Use it when activities were changed by mistake (for example an Excel upload that put descriptions on the wrong
activities). Activities are matched by their ID, which never changes, so each one gets its own value back.

    Check first (changes nothing):
        sudo python3 restore_from_backup.py BACKUP.db --function "Function name"
    Put the descriptions back:
        sudo python3 restore_from_backup.py BACKUP.db --function "Function name" --apply
    Other fields:   --fields description,category,frequency,volume,handling
    Every function: leave out --function

Stop the portal first (sudo systemctl stop ops-portal). With --apply, a copy of the live database is saved next to
it before anything is changed. Activities added after the backup are not touched; activities deleted since the
backup are not recreated.
"""
import argparse
import sqlite3
import sys
from datetime import datetime

LIVE = "/data/opt/ops-portal/backend/data/portal.db"
ALLOWED = {"description", "category", "frequency", "volume", "handling", "product", "process", "channel", "minutes",
           "peak_som", "peak_eom", "automation"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("backup")
    ap.add_argument("--live", default=LIVE)
    ap.add_argument("--function", default="")
    ap.add_argument("--fields", default="description")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    fields = [f.strip() for f in a.fields.split(",") if f.strip()]
    bad = [f for f in fields if f not in ALLOWED]
    if bad:
        sys.exit(f"Unknown field(s): {', '.join(bad)}. Allowed: {', '.join(sorted(ALLOWED))}")
    bk = sqlite3.connect(a.backup)
    lv = sqlite3.connect(a.live)
    fn_ids = None
    if a.function:
        fn_ids = [r[0] for r in lv.execute("select id from functions where lower(trim(name)) = lower(trim(?))", (a.function,))]
        if not fn_ids:
            names = [r[0] for r in lv.execute("select name from functions order by name")]
            sys.exit(f"Function '{a.function}' not found. Functions: " + "; ".join(names))
    q = "select w.id, w.employee_code, " + ", ".join("w." + f for f in fields) + " from work_items w join employees e on e.code = w.employee_code"
    params = ()
    if fn_ids:
        q += " where e.function_id in (%s)" % ",".join("?" * len(fn_ids))
        params = tuple(fn_ids)
    live = {r[0]: r for r in lv.execute(q, params)}
    old = {r[0]: r for r in bk.execute("select id, employee_code, " + ", ".join(fields) + " from work_items")}
    diffs = []
    for i, r in live.items():
        b = old.get(i)
        if not b or b[1] != r[1]:
            continue          # added after the backup, or not the same employee: left alone
        ch = {f: (r[2 + k], b[2 + k]) for k, f in enumerate(fields) if (r[2 + k] or "") != (b[2 + k] or "")}
        if ch:
            diffs.append((i, r[1], ch))
    print(f"{len(live)} activities in scope; {len(diffs)} differ from the backup in: {', '.join(fields)}")
    for i, code, ch in diffs[:15]:
        for f, (now, was) in ch.items():
            print(f"  activity {i} (employee {code}) {f}:\n     now:    {str(now)[:110]}\n     backup: {str(was)[:110]}")
    if len(diffs) > 15:
        print(f"  ... and {len(diffs) - 15} more")
    if not a.apply:
        print("\nNothing changed. Add --apply to put these values back.")
        return
    if not diffs:
        print("Nothing to put back.")
        return
    safe = f"{a.live}.before_restore_{datetime.now():%Y%m%d_%H%M%S}"
    dst = sqlite3.connect(safe)
    lv.backup(dst)
    dst.close()
    print(f"Copy of the live database saved: {safe}")
    for i, code, ch in diffs:
        lv.execute("update work_items set " + ", ".join(f"{f} = ?" for f in ch) + " where id = ?", [was for _, (now, was) in ch.items()] + [i])
    lv.commit()
    print(f"Put back {len(diffs)} activities. Start the portal again: sudo systemctl start ops-portal")


if __name__ == "__main__":
    main()
