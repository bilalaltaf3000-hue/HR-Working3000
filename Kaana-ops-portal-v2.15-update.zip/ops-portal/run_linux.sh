#!/usr/bin/env bash
# Run the portal on Linux (after installing packages into backend/venv, see README).
set -e
cd "$(dirname "$0")/backend"
exec ./venv/bin/python -m uvicorn app.main:app --host "${OPS_HOST:-0.0.0.0}" --port "${OPS_PORT:-8000}" --workers 1
