# HBL Operations Services Workforce Portal

Web portal for the organogram, span of control, layers, workforce mix and structure
opportunities, plus data capture of each employee's region and activities by function POCs.

- **Backend:** Python (FastAPI + SQLAlchemy), SQLite by default, PostgreSQL optional
- **Frontend:** React, already built into `backend/static` (no Node.js needed to run it)
- **Access rights (set per user by the admin):** input rights for one or more functions; dashboards for none, the same functions, selected functions or the whole organisation; export on or off; or full administrator. Templates: Function POC, Function head, HR / executive, Administrator.
- **Exports:** PDF report, PowerPoint deck (native, editable charts), standalone HTML page and Excel workbook, for everything a user can see or for a single function.

```
ops-portal/
  backend/            Python application (this is what runs)
    app/              API code
    static/           Built web pages (from frontend/)
    data/             Created on first run: database, secret key, first admin password
    requirements.txt
  frontend/           React source code (only needed if you change the screens)
  deploy/             systemd service, nginx config, backup script
  run_windows.bat     Start on Windows for testing
  run_linux.sh        Start on Linux
```

---

## 1. Test on your Windows machine

1. Install **Python 3.12** from python.org (tick "Add Python to PATH").
2. Unzip the folder, for example to `C:\ops-portal`.
3. Double-click **`run_windows.bat`**. The first run creates a virtual environment and installs the packages (needs internet once).
4. Note the **first admin password** printed in the window. It is also saved in `backend\data\FIRST_ADMIN_PASSWORD.txt`.
5. Open **http://127.0.0.1:8000** and sign in as `admin`.
6. Go to **Admin → Import** and upload the employee master sheet.
7. Explore the dashboards, then open **Data capture** to try the POC screens.

To start again from a clean state, stop the portal and delete the `backend\data` folder.

---

## 2. Deploy on the RHEL 9 VM (no internet)

### 2.1 Linux packages (already included)

The `wheels` folder in this zip already contains every package for **RHEL 9 with Python 3.9, 3.11 or 3.12**
(x86_64), so nothing needs downloading. Copy the whole `ops-portal` folder to the VM, for
example with WinSCP, into `/opt/ops-portal`.

If you ever change `requirements.txt`, rebuild the folder on a machine with internet
(Windows Command Prompt, in the `ops-portal` folder):

```bat
py -3.12 -m pip download -r backend\requirements.txt -d wheels ^
   --platform manylinux2014_x86_64 --platform manylinux_2_17_x86_64 --platform manylinux_2_28_x86_64 ^
   --python-version 3.11 --implementation cp --only-binary=:all:
```



### 2.2 On the VM

```bash
# Python: use the VM's existing python3 (3.9, 3.11 or 3.12); nothing to install

# service account and folder ownership
sudo useradd --system --home /opt/ops-portal --shell /sbin/nologin opsportal
sudo chown -R opsportal:opsportal /opt/ops-portal

# install packages from the copied wheels
cd /opt/ops-portal/backend
sudo -u opsportal python3 -m venv venv
sudo -u opsportal ./venv/bin/pip install --no-index --find-links ../wheels -r requirements.txt

# quick test run (Ctrl+C to stop); note the first admin password it prints
sudo -u opsportal ./venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open `http://<vm-ip>:8000` from your laptop. If it does not load, open the port:
`sudo firewall-cmd --add-port=8000/tcp --permanent && sudo firewall-cmd --reload`.

### 2.3 Run it as a service

```bash
sudo cp /opt/ops-portal/deploy/ops-portal.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now ops-portal
sudo systemctl status ops-portal      # should show "active (running)"
journalctl -u ops-portal -f           # live log
```

The service listens on `127.0.0.1:8000`, so put nginx in front (next step), or change
`--host 127.0.0.1` to `--host 0.0.0.0` in the service file to reach it directly on port 8000.

### 2.4 nginx and HTTPS (recommended)

```bash
sudo dnf install -y nginx
sudo cp /opt/ops-portal/deploy/nginx-ops-portal.conf /etc/nginx/conf.d/ops-portal.conf
# place your internal certificate and key at the paths in that file (ask IT)
sudo setsebool -P httpd_can_network_connect 1     # SELinux: allow nginx to reach the app
sudo nginx -t && sudo systemctl enable --now nginx
sudo firewall-cmd --add-service=https --add-service=http --permanent && sudo firewall-cmd --reload
```

### 2.5 Backups

The whole database is one file: `backend/data/portal.db`. Schedule the nightly backup:

```bash
sudo mkdir -p /opt/ops-portal/backups && sudo chown opsportal /opt/ops-portal/backups
sudo crontab -u opsportal -e
# add:  0 1 * * * /opt/ops-portal/deploy/backup_db.sh
```

### 2.6 Moving your Windows test data to the VM (optional)

Stop the portal on Windows and copy `backend\data\portal.db` and `backend\data\secret.key`
into `/opt/ops-portal/backend/data/` before starting the service. Otherwise start fresh
and import the sheet again on the VM.

---

## 3. First-time setup checklist

1. Sign in as `admin`, choose **Change password** in the sidebar, then delete `backend/data/FIRST_ADMIN_PASSWORD.txt`.
2. **Admin → Import**: upload the employee master sheet and review the import checks.
3. **Admin → Settings**: productive hours per day (default 7.5), top of the organogram (auto-detected), senior grade threshold (68 = SM I).
4. **Admin → Categories and regions**: adjust the region list (Karachi is included; add the rest).
5. **Admin → People and flags**: mark external people or people to exclude from span and headcount.
6. **Admin → Users**: "Create a POC login for every function without one" downloads a CSV of usernames and passwords (each can fill in and see their own function). Use **Create a login** with the **HR / executive** template for HR, or **Function head** for heads who should also export. **Edit access** changes any user's rights later, and shows exactly what they will see.
7. POCs sign in, set each employee's unit and region (step 1), record each employee's activities in the template (step 2) and check the review (step 3).
8. Track progress in **Admin → Capture progress**. The **Export** button in the sidebar produces a PDF report, PowerPoint deck, HTML page or Excel workbook for the whole group, the current dashboard selection or one function.

## 4. How the calculations work

- **Hierarchy:** built only from employee code and N-1 manager code. Layers, spans and teams are recalculated live. Repeated managers in N-2…N-7, a sheet "Layers" column that disagrees, manager codes stored as numbers (0 vs 00000), self-reporting and circular loops are all detected and reported on import.
- **FTE / FTC:** grade text "Outsourced Staff" means FTC (contract/outsourced); everything else is FTE (permanent). Change the text with the `OPS_OUTSOURCED_GRADE` environment variable if needed.
- **Seniority:** from the number before each grade (088 GM III … 052 AM I). Outsourced staff rank last.
- **Function head:** the person who reports directly to the top of the organisation (or the top person, for their own function). The head is listed first everywhere and recording their activities is optional.
- **Units and regions:** set by POCs in step 1 (regions also from a Region / Location / City column in the master sheet when present). Setting a manager's unit or region carries down to their team; anyone set individually keeps their own.
- **Activities:** one row per employee per activity (the unit comes from the employee): product, process, channel, description, category, service or support, frequency, average volume, peak volumes (start and end of month, average per day), handling, processing time per item and automation opportunity.
- **Total staff processing time (min)** = processing time per item × average volume (per frequency period).
- **Daily man-hours** = total ÷ working days in the period (daily 1, weekly 5, fortnightly 10, monthly 22; set in Admin → Settings) ÷ 60. **FTE equivalent** = man-hours ÷ productive hours. **Utilisation** = an employee's daily man-hours ÷ productive hours. **Peak day** uses the peak volumes where entered.
- **Service / support / both:** each activity is Service or Support; an employee with both kinds is shown as Both.
- **Copy to colleagues:** copies selected activities to colleagues with the same volume, a volume per region, or empty volumes. Copies stay linked: **Compare and set volumes** shows the same activity across colleagues (set a volume for a whole region, then adjust individuals), and **Apply these details to all** pushes detail changes to every copy.

## 5. Upgrading from an earlier version

Replace the `backend/app`, `backend/static`, `frontend` and `wheels` folders, keep `backend/data`, and reinstall packages (`pip install -r requirements.txt`, or with `--no-index --find-links ../wheels` on the VM). Existing POC and viewer logins are converted automatically on start: POCs keep input for their function, viewers get whole-organisation dashboards and export. Version 2 converts activities recorded in version 1 (per unit and process) into one row per employee on its first start; see UPDATE_v2.md.

## 6. Changing the screens (developers)

```bash
cd frontend
npm install
npm run dev      # development server on http://localhost:5173, uses the backend on :8000
npm run build    # writes the production build into backend/static
```

API documentation is available at `/api/docs` while the portal is running.

## 7. Settings via environment variables

| Variable | Default | Purpose |
|---|---|---|
| `OPS_DB_URL` | SQLite file in `backend/data` | e.g. `postgresql+psycopg2://user:pass@localhost/opsportal` (also install `psycopg2-binary`) |
| `OPS_DATA_DIR` | `backend/data` | Where the database, secret key and first password are stored |
| `OPS_SECRET_KEY` | generated on first run | Signs login tokens |
| `OPS_TOKEN_HOURS` | 12 | Login session length |
| `OPS_OUTSOURCED_GRADE` | `Outsourced Staff` | Grade text that marks FTC staff |
