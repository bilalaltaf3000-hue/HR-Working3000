"""Role overlap (on-premise AI): results per function, HR's review of each case, the admin's AI settings and runs,
the Excel file and the one-page PDF. Seen by the admin and the logins with Role Overlap access; only the admin runs
the AI."""
import io
from datetime import datetime
from typing import Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models, roleai
from ..db import get_db
from ..security import audit, current_user, require_admin

router = APIRouter(prefix="/api/ro")
STATUSES = ["Open", "Under review", "Confirmed", "Dismissed"]
FLAG_WORDS = {"team_work": "Doing team's work", "single": "Single report", "near": "Near-identical", "supervisory": "Mainly supervisory", "few": "Few activities"}


def require_ro(user=Depends(current_user)):
    if user.role != "admin" and not user.can_role_overlap:
        raise HTTPException(403, "You do not have access to Role Overlap. Ask the admin.")
    return user


def _results(db, fid=None) -> Dict[int, dict]:
    q = db.query(models.RoResult)
    if fid:
        q = q.filter(models.RoResult.function_id == fid)
    out = {}
    for r in q:
        out[r.function_id] = dict(r.payload or {}, run_id=r.run_id, at=r.created_at.isoformat(timespec="minutes") if r.created_at else None)
    return out


def _cases(db, fid=None) -> Dict[str, models.RoCase]:
    q = db.query(models.RoCase)
    if fid:
        q = q.filter(models.RoCase.function_id == fid)
    return {c.key: c for c in q}


def sup_key(code):
    return f"sup:{code}"


def pair_key(a, b):
    a, b = sorted((a, b))
    return f"pair:{a}|{b}"


def _flagged_sup(s):
    return any(f in s["flags"] for f in ("team_work", "single", "near"))


def _case_out(c: Optional[models.RoCase]):
    if not c:
        return {"status": "Open", "note": "", "owner": "", "decisions": {}, "decision_id": None, "updated_by": "", "updated_at": None}
    return {"status": c.status, "note": c.note or "", "owner": c.owner or "", "decisions": c.decisions or {}, "decision_id": c.decision_id,
            "updated_by": c.updated_by or "", "updated_at": c.updated_at.isoformat(timespec="minutes") if c.updated_at else None}


def _fn_figures(p: dict, cases: Dict[str, models.RoCase]):
    sups, pairs = p.get("supervisors", []), p.get("pairs", [])
    sp = [s["supervisory_pct"] for s in sups if s.get("supervisory_pct") is not None]
    keys = [sup_key(s["code"]) for s in sups if _flagged_sup(s)] + [pair_key(x["a"], x["b"]) for x in pairs if x["flag"]]
    reviewed = sum(1 for k in keys if k in cases and cases[k].status in ("Confirmed", "Dismissed"))
    return {"supervisors": len(sups), "team_work": sum(1 for s in sups if "team_work" in s["flags"]),
            "single": sum(1 for s in sups if "single" in s["flags"]), "near": sum(1 for s in sups if "near" in s["flags"]),
            "same_region": sum(1 for x in pairs if x["region"] == "same"), "region_unknown": sum(1 for x in pairs if x["region"] == "unknown"),
            "supervisory_avg": round(sum(sp) / len(sp)) if sp else None, "fte": p.get("fte", 0),
            "cases": len(keys), "reviewed": reviewed, "staff": len({c for s in sups for c in [s["code"]] + s["reports_compared"]})}


def _top_cases(db, cases, fns, n=None):
    """The strongest cases across COSO: flagged supervisors and colleagues doing the same work in the same region."""
    top = []
    for fid, p in _results(db).items():
        if fid not in fns:
            continue
        for s in p.get("supervisors", []):
            if _flagged_sup(s):
                c = cases.get(sup_key(s["code"]))
                e = _emp(p, s["code"])
                top.append({"score": s["same_pct"] + (20 if "near" in s["flags"] else 0), "fid": fid, "function": fns.get(fid, ""), "kind": "sup", "codes": [s["code"]],
                            "who": e["name"], "position": e["position"], "flag": ", ".join(FLAG_WORDS[f] for f in s["flags"] if f in FLAG_WORDS),
                            "why": s["summary"] or f"{s['matched']} of {s['activities']} activities also done by the team", "fte": s.get("overlap_fte", 0),
                            "status": c.status if c else "Open"})
        for x in p.get("pairs", []):
            if x["region"] == "same":
                c = cases.get(pair_key(x["a"], x["b"]))
                top.append({"score": 40 + 5 * x["a_matched"], "fid": fid, "function": fns.get(fid, ""), "kind": "pair", "codes": [x["a"], x["b"]],
                            "who": f"{_emp(p, x['a'])['name']} · {_emp(p, x['b'])['name']}", "position": "Colleagues", "flag": "Same work, same region",
                            "why": f"{x['a_matched']} of {x['a_acts']} and {x['b_matched']} of {x['b_acts']} activities are the same work", "fte": x.get("overlap_fte", 0),
                            "status": c.status if c else "Open"})
    top.sort(key=lambda r: -r["score"])
    return top[:n] if n else top


# ---------------------------------------------------------------- reading
@router.get("/overview")
def overview(user=Depends(require_ro), db: Session = Depends(get_db)):
    fns = {f.id: f.name for f in db.query(models.Function)}
    res, cases = _results(db), _cases(db)
    rows, tot = [], {"supervisors": 0, "team_work": 0, "single": 0, "near": 0, "same_region": 0, "fte": 0.0, "cases": 0, "reviewed": 0, "staff": 0}
    sp_all = []
    for fid, p in res.items():
        if fid not in fns:
            continue
        f = _fn_figures(p, cases)
        rows.append({"id": fid, "name": fns[fid], "at": p.get("at"), **f})
        for k in tot:
            tot[k] += f[k] or 0
        sp_all += [s["supervisory_pct"] for s in p.get("supervisors", []) if s.get("supervisory_pct") is not None]
    rows.sort(key=lambda r: -(r["team_work"] * 3 + r["near"] * 3 + r["single"] * 2 + r["same_region"] * 2))
    tot["fte"] = round(tot["fte"], 1)
    tot["supervisory_avg"] = round(sum(sp_all) / len(sp_all)) if sp_all else None
    last = db.query(models.RoRun).filter(models.RoRun.kind != "summary").order_by(models.RoRun.id.desc()).first()
    status = {k: 0 for k in STATUSES}
    keys = set()
    for fid, p in res.items():
        keys |= {sup_key(s_["code"]) for s_ in p.get("supervisors", []) if _flagged_sup(s_)} | {pair_key(x["a"], x["b"]) for x in p.get("pairs", []) if x["flag"]}
    for k in keys:
        st_ = cases[k].status if k in cases else "Open"
        status[st_] = status.get(st_, 0) + 1
    return {"functions": rows, "totals": tot, "top": _top_cases(db, cases, fns, 8), "status": status, "not_analysed": sorted([{"id": i, "name": n} for i, n in fns.items() if i not in res], key=lambda r: r["name"]),
            "all_functions": sorted([{"id": i, "name": n} for i, n in fns.items()], key=lambda r: r["name"]),
            "run": _run_out(last), "can_run": user.role == "admin", "threshold": roleai.settings(db)["threshold"]}


def _emp(p, code):
    e = p.get("emps", {}).get(code) or {}
    return {"code": code, "name": e.get("name", code), "position": e.get("position", ""), "grade": e.get("grade", ""),
            "emp_type": e.get("emp_type", ""), "region": e.get("region", ""), "unit": e.get("unit", ""), "manager": e.get("manager", "")}


@router.get("/function/{fid}")
def function_view(fid: int, user=Depends(require_ro), db: Session = Depends(get_db)):
    fn = db.get(models.Function, fid)
    if not fn:
        raise HTTPException(404, "Function not found.")
    p = _results(db, fid).get(fid)
    if not p:
        return {"function": {"id": fid, "name": fn.name}, "analysed": False, "can_run": user.role == "admin"}
    cases = _cases(db, fid)
    sups = [{**_emp(p, s["code"]), **{k: s[k] for k in ("team", "activities", "matched", "same_pct", "supervisory_pct", "flags", "summary", "overlap_fte") if k in s}, "checks": s.get("checks", 0),
             "near": [_emp(p, c)["name"] for c in s.get("near", [])], "case": _case_out(cases.get(sup_key(s["code"])))["status"]} for s in p["supervisors"]]
    pairs = [{"a": _emp(p, x["a"]), "b": _emp(p, x["b"]), **{k: x[k] for k in ("same_manager", "region", "a_matched", "a_acts", "b_matched", "b_acts", "a_vday", "b_vday", "flag", "overlap_fte")},
              "manager": _emp(p, p["emps"].get(x["a"], {}).get("manager", ""))["name"] if x["same_manager"] else "",
              "case": _case_out(cases.get(pair_key(x["a"], x["b"])))["status"]} for x in p["pairs"]]
    return {"function": {"id": fid, "name": fn.name}, "analysed": True, "at": p.get("at"), "figures": _fn_figures(p, cases), "supervisors": sups,
            "pairs": pairs, "threshold": p.get("threshold"), "can_run": user.role == "admin"}


def _act(p, i):
    a = p["acts"].get(str(i)) or {}
    return {"id": a.get("id", i), "desc": a.get("desc", ""), "cat": a.get("cat", ""), "process": a.get("process", ""), "product": a.get("product", ""),
            "freq": a.get("freq", ""), "vday": a.get("vday", 0), "hours": a.get("hours", 0)}


@router.get("/supervisor/{fid}/{code}")
def supervisor(fid: int, code: str, user=Depends(require_ro), db: Session = Depends(get_db)):
    p = _results(db, fid).get(fid)
    s = next((x for x in (p or {}).get("supervisors", []) if x["code"] == code), None)
    if not s:
        raise HTTPException(404, "This supervisor is not in the last analysis of the function.")
    m = p["emps"][code]
    reports = [{**_emp(p, k), "acts": [_act(p, i) for i in p["emps"][k]["acts"]]} for k in s["reports_compared"]]
    return {"supervisor": {**_emp(p, code), "acts": [{**_act(p, i), "label": s["labels"].get(str(i))} for i in m["acts"]]},
            "reports": reports, "matches": s["matches"], "summary": s["summary"], "figures": {**{k: s[k] for k in ("team", "activities", "matched", "same_pct", "supervisory_pct", "flags", "overlap_fte")}, "checks": s.get("checks", 0)},
            "near": [_emp(p, c)["name"] for c in s.get("near", [])], "key": sup_key(code), "case": _case_out(_cases(db, fid).get(sup_key(code))), "at": p.get("at")}


@router.get("/pair/{fid}/{a}/{b}")
def pair(fid: int, a: str, b: str, user=Depends(require_ro), db: Session = Depends(get_db)):
    p = _results(db, fid).get(fid)
    a, b = sorted((a, b))
    x = next((y for y in (p or {}).get("pairs", []) if y["a"] == a and y["b"] == b), None)
    if not x:
        raise HTTPException(404, "This pair is not in the last analysis of the function.")
    side = lambda c: {**_emp(p, c), "acts": [_act(p, i) for i in p["emps"][c]["acts"]]}
    return {"a": side(a), "b": side(b), "matches": x["matches"], "figures": {k: x[k] for k in ("same_manager", "region", "a_matched", "a_acts", "b_matched", "b_acts", "a_vday", "b_vday", "flag", "overlap_fte")},
            "key": pair_key(a, b), "case": _case_out(_cases(db, fid).get(pair_key(a, b))), "at": p.get("at")}


@router.get("/tracker")
def tracker(user=Depends(require_ro), db: Session = Depends(get_db)):
    fns = {f.id: f.name for f in db.query(models.Function)}
    res = _results(db)
    names = {}
    for p in res.values():
        for c, e in p.get("emps", {}).items():
            names[c] = e.get("name", c)
    out = []
    for c in db.query(models.RoCase).order_by(models.RoCase.updated_at.desc()):
        if c.key.startswith("sup:"):
            label, kind, codes = names.get(c.key[4:], c.key[4:]), "supervisor", [c.key[4:]]
        else:
            codes = c.key[5:].split("|")
            label, kind = " · ".join(names.get(x, x) for x in codes), "pair"
        out.append({"key": c.key, "kind": kind, "codes": codes, "label": label, "function_id": c.function_id, "function": fns.get(c.function_id, ""),
                    **_case_out(c)})
    return {"cases": out, "statuses": STATUSES}


# ---------------------------------------------------------------- HR review
class CaseIn(BaseModel):
    key: str
    function_id: int
    status: Optional[str] = None
    note: Optional[str] = None
    owner: Optional[str] = None
    decision: Optional[Dict[str, str]] = None    # {"<a>-<b>": "confirmed" | "rejected" | ""}


@router.patch("/case")
def update_case(body: CaseIn, user=Depends(require_ro), db: Session = Depends(get_db)):
    if not (body.key.startswith("sup:") or body.key.startswith("pair:")) or len(body.key) > 120:
        raise HTTPException(400, "Unknown case.")
    c = db.get(models.RoCase, body.key)
    if not c:
        c = models.RoCase(key=body.key, function_id=body.function_id, status="Open", decisions={})
        db.add(c)
    if body.status is not None:
        if body.status not in STATUSES:
            raise HTTPException(400, "Unknown status.")
        c.status = body.status
    if body.note is not None:
        c.note = body.note[:4000]
    if body.owner is not None:
        c.owner = body.owner[:80]
    if body.decision:
        d = dict(c.decisions or {})
        for k, v in body.decision.items():
            if v in ("confirmed", "rejected"):
                d[k[:40]] = v
            else:
                d.pop(k, None)
        c.decisions = d
        if c.status == "Open":
            c.status = "Under review"
    if not c.owner:
        c.owner = user.username
    c.updated_by, c.updated_at = user.username, datetime.utcnow()
    audit(db, user, "role_overlap_review", f"{body.key}: {c.status}")
    db.commit()
    return _case_out(c)


class RecIn(BaseModel):
    key: str
    function_id: int
    subject: str
    details: str = ""


@router.post("/case/recommend")
def recommend(body: RecIn, user=Depends(require_ro), db: Session = Depends(get_db)):
    if user.role != "admin" and not user.can_decisions:
        raise HTTPException(403, "Adding a Recommendation needs Recommendations access. Ask the admin.")
    if len(body.subject.strip()) < 3:
        raise HTTPException(400, "Type a subject.")
    d = models.Decision(function_id=body.function_id, decided_on=datetime.now().strftime("%Y-%m-%d"), subject=body.subject.strip()[:250],
                        details=body.details.strip()[:10000], status="Recommended", recorded_by=user.username, recorded_name=user.full_name or user.username)
    db.add(d)
    db.flush()
    c = db.get(models.RoCase, body.key) or models.RoCase(key=body.key, function_id=body.function_id, decisions={})
    db.add(c)
    c.decision_id, c.status = d.id, "Confirmed"
    c.updated_by, c.updated_at = user.username, datetime.utcnow()
    if not c.owner:
        c.owner = user.username
    audit(db, user, "role_overlap_recommend", f"{body.key} -> recommendation {d.id}")
    db.commit()
    return {"decision_id": d.id, "case": _case_out(c)}


# ---------------------------------------------------------------- running the AI (admin only)
def _run_out(r: Optional[models.RoRun]):
    if not r:
        return None
    fname = None
    return {"id": r.id, "function_id": r.function_id, "status": r.status, "total": r.total, "done": r.done, "failed": r.failed, "current": r.current or fname,
            "error": r.error or "", "model": r.model, "by": r.started_by,
            "started_at": r.started_at.isoformat(timespec="seconds") if r.started_at else None,
            "finished_at": r.finished_at.isoformat(timespec="seconds") if r.finished_at else None,
            "seconds": int(((r.finished_at or datetime.utcnow()) - r.started_at).total_seconds()) if r.started_at else 0}


@router.get("/run")
def run_status(user=Depends(require_ro), db: Session = Depends(get_db)):
    return _run_out(db.query(models.RoRun).filter(models.RoRun.kind != "summary").order_by(models.RoRun.id.desc()).first())


class RunIn(BaseModel):
    function_id: Optional[int] = None


@router.post("/run")
def run_start(body: RunIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    if body.function_id and not db.get(models.Function, body.function_id):
        raise HTTPException(404, "Function not found.")
    try:
        roleai.models_list(roleai.settings(db))
        r = roleai.start(db, body.function_id, user)
    except roleai.AiError as e:
        raise HTTPException(400, str(e))
    audit(db, user, "role_overlap_run", f"function {body.function_id or 'all'}")
    db.commit()
    return _run_out(r)


@router.post("/run/stop")
def run_stop(user=Depends(require_admin), db: Session = Depends(get_db)):
    r = roleai.busy(db)
    if not r:
        raise HTTPException(400, "No analysis is running.")
    roleai.cancel(r.id)
    return {"ok": True}


class AiIn(BaseModel):
    url: Optional[str] = None
    model: Optional[str] = None
    api_key: Optional[str] = None
    concurrency: Optional[int] = None
    max_tokens: Optional[int] = None
    timeout: Optional[int] = None
    json_mode: Optional[bool] = None
    threshold: Optional[int] = None


@router.get("/ai")
def ai_get(user=Depends(require_admin), db: Session = Depends(get_db)):
    s = roleai.settings(db)
    return {**s, "api_key": "•••" if s.get("api_key") else ""}


@router.put("/ai")
def ai_put(body: AiIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    d = body.model_dump(exclude_unset=True)
    if d.get("api_key") == "•••":
        d.pop("api_key")
    before = roleai.settings(db)["threshold"]
    s = roleai.save_settings(db, d)
    if s["threshold"] != before:
        roleai.recompute_stored(db, force=True)   # the flags follow the new threshold without asking the AI again
    audit(db, user, "ai_settings", f"{s['url']} {s['model']}")
    db.commit()
    return {**s, "api_key": "•••" if s.get("api_key") else ""}


@router.post("/ai/test")
def ai_test(user=Depends(require_admin), db: Session = Depends(get_db)):
    try:
        return roleai.test_connection(roleai.settings(db))
    except roleai.AiError as e:
        raise HTTPException(400, str(e))


# ---------------------------------------------------------------- Excel and PDF
@router.get("/export")
def export(function_id: Optional[int] = Query(None), user=Depends(require_ro), db: Session = Depends(get_db)):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    fns = {f.id: f.name for f in db.query(models.Function)}
    res, cases = _results(db, function_id), _cases(db)
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws.append(["Function", "Supervisor code", "Supervisor", "Grade", "Position", "Direct reports", "Activities", "Same as team (n)",
               "Same as team (%)", "Supervisory work (%)", "Flags", "Summary", "Overlapping work (FTE, indicative)", "HR status", "HR note"])
    mt = wb.create_sheet("Matches")
    mt.append(["Function", "Supervisor", "Supervisor's activity ID", "Supervisor's activity", "Category", "Direct report", "Report's activity ID",
               "Report's activity", "Confidence", "AI reason", "HR decision"])
    pm = wb.create_sheet("Peer matches")
    pm.append(["Function", "Colleague A", "Region A", "Colleague B", "Region B", "Same manager", "Region", "A's activity", "B's activity",
               "Confidence", "AI reason", "A volume a day", "B volume a day", "HR status", "HR decision"])
    sf = wb.create_sheet("Structure flags")
    sf.append(["Function", "Flag", "Who", "Details"])
    for fid, p in sorted(res.items(), key=lambda kv: fns.get(kv[0], "")):
        fn = fns.get(fid, "")
        for s in p.get("supervisors", []):
            e = _emp(p, s["code"])
            c = cases.get(sup_key(s["code"]))
            ws.append([fn, s["code"], e["name"], e["grade"], e["position"], s["team"], s["activities"], s["matched"], s["same_pct"], s["supervisory_pct"],
                       ", ".join(FLAG_WORDS.get(f, f) for f in s["flags"]), s["summary"], s["overlap_fte"], c.status if c else "Open", (c.note if c else "") or ""])
            dec = (c.decisions if c else None) or {}
            for x in s["matches"]:
                a, b = _act(p, x["a"]), _act(p, x["b"])
                mt.append([fn, e["name"], a["id"], a["desc"], a["cat"], _emp(p, p["acts"].get(str(x["b"]), {}).get("code", ""))["name"], b["id"], b["desc"],
                           x["conf"].title() + (" (check/approval: not counted)" if x.get("check") else ""), x["reason"], {"confirmed": "Confirmed", "rejected": "Not the same"}.get(dec.get(f"{x['a']}-{x['b']}"), "")])
            if "single" in s["flags"]:
                sf.append([fn, "Single-report manager", e["name"], "One direct report: a layer to review"])
            for nm in [_emp(p, k)["name"] for k in s.get("near", [])]:
                sf.append([fn, "Near-identical manager and report", f"{e['name']} and {nm}", f"{s['same_pct']}% of the manager's activities are the same as the team's"])
            if s.get("supervisory_pct") == 0 and s["activities"]:
                sf.append([fn, "No supervisory work", e["name"], "None of the supervisor's activities were labelled supervisory"])
        for x in p.get("pairs", []):
            ea, eb = _emp(p, x["a"]), _emp(p, x["b"])
            c = cases.get(pair_key(x["a"], x["b"]))
            dec = (c.decisions if c else None) or {}
            for m in x["matches"]:
                a, b = _act(p, m["a"]), _act(p, m["b"])
                pm.append([fn, ea["name"], ea["region"], eb["name"], eb["region"], "Yes" if x["same_manager"] else "No",
                           {"same": "Same region", "different": "Different regions", "unknown": "Region not set"}[x["region"]], a["desc"], b["desc"],
                           m["conf"].title(), m["reason"], a["vday"], b["vday"], c.status if c else "Open",
                           {"confirmed": "Confirmed", "rejected": "Not the same"}.get(dec.get(f"{m['a']}-{m['b']}"), "")])
    for sh in (ws, mt, pm, sf):
        for cell in sh[1]:
            cell.font, cell.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="00796B")
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            sh.column_dimensions[cell.column_letter].width = 16
        sh.freeze_panes = "A2"
    for col, w in (("L", 60), ("E", 28), ("C", 26)):
        ws.column_dimensions[col].width = w
    for col in ("D", "H", "J"):
        mt.column_dimensions[col].width = 50
    for col in ("H", "I", "K"):
        pm.column_dimensions[col].width = 45
    sf.column_dimensions["D"].width = 60
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    audit(db, user, "role_overlap_export", str(function_id or "all"))
    db.commit()
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="role_overlap_{datetime.now():%Y%m%d_%H%M}.xlsx"'})


@router.get("/pdf")
def pdf(user=Depends(require_ro), db: Session = Depends(get_db)):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    ov = overview(user, db)
    t = ov["totals"]
    green, ink, soft = colors.HexColor("#00665B"), colors.HexColor("#0F2E2A"), colors.HexColor("#E7F4F1")
    H = ParagraphStyle("h", fontName="Helvetica-Bold", fontSize=16, leading=20, textColor=ink, spaceAfter=3)
    S = ParagraphStyle("s", fontName="Helvetica", fontSize=8.5, textColor=colors.HexColor("#4A6561"))
    B = ParagraphStyle("b", fontName="Helvetica", fontSize=8.5, textColor=ink, leading=11)
    H2 = ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=10.5, textColor=green, spaceBefore=8, spaceAfter=4)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=14 * mm, rightMargin=14 * mm, topMargin=12 * mm, bottomMargin=12 * mm)
    story = [Paragraph("Role Overlap · COSO", H), Paragraph(f"{datetime.now():%d %b %Y} · {len(ov['functions'])} functions analysed", S), Spacer(1, 6)]
    figs = [["Supervisors doing\nteam's work", "Single-report\nmanagers", "Near-identical\npairs", "Same work,\nsame region", "Supervisory\nwork", "Overlapping work\n(indicative)"],
            [str(t["team_work"]), str(t["single"]), str(t["near"]), str(t["same_region"]), f"{t['supervisory_avg']}%" if t["supervisory_avg"] is not None else "-", f"≈ {round(t['fte']) if t['fte'] >= 10 else t['fte']} FTE"]]
    ft = Table(figs, colWidths=[30 * mm] * 6)
    ft.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), green), ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
                            ("FONTNAME", (0, 0), (-1, 0), "Helvetica"), ("FONTSIZE", (0, 0), (-1, 0), 7.5), ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
                            ("FONTSIZE", (0, 1), (-1, 1), 14), ("ALIGN", (0, 0), (-1, -1), "LEFT"), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                            ("LINEAFTER", (0, 0), (-2, -1), 2, colors.white), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 1), (-1, 1), 8)]))
    story += [ft, Paragraph("Functions to review first", H2)]
    HB = ParagraphStyle("hb", parent=B, fontName="Helvetica-Bold", fontSize=8)
    rows = [[Paragraph(x, HB) for x in ("Function", "Doing team's work", "Single report", "Near-identical", "Same region", "Overlap (FTE)", "Reviewed")]]
    for r in ov["functions"][:5]:
        rows.append([Paragraph(r["name"], B), r["team_work"], r["single"], r["near"], r["same_region"], r["fte"], f"{r['reviewed']} of {r['cases']}"])
    tb = Table(rows, colWidths=[54 * mm, 24 * mm, 18 * mm, 24 * mm, 18 * mm, 21 * mm, 23 * mm])
    tb.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 8), ("BACKGROUND", (0, 0), (-1, 0), soft),
                            ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#D8E3E1")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    story.append(tb)
    # the ten strongest cases
    cases = _cases(db)
    fns = {f.id: f.name for f in db.query(models.Function)}
    top = [(c["score"], c["function"], c["who"], c["flag"], c["why"], c["status"]) for c in _top_cases(db, cases, fns)]
    story.append(Paragraph("Top cases", H2))
    FL = ParagraphStyle("fl", parent=B, fontSize=7.5, leading=9.5)
    rows = [["Function", "Who", "Flag", "Why (AI)", "HR"]] + [[Paragraph(r[1], B), Paragraph(r[2], B), Paragraph(r[3], FL), Paragraph(r[4][:220], B), r[5]] for r in top[:8]]
    tb = Table(rows, colWidths=[34 * mm, 34 * mm, 28 * mm, 74 * mm, 14 * mm], repeatRows=1)
    tb.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 8), ("BACKGROUND", (0, 0), (-1, 0), soft),
                            ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#D8E3E1")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story.append(tb)
    st = {k: 0 for k in STATUSES}
    for c in cases.values():
        st[c.status] = st.get(c.status, 0) + 1
    story += [Paragraph("HR review", H2), Paragraph(f"{t['reviewed']} of {t['cases']} flagged cases reviewed. " + " · ".join(f"{k}: {v}" for k, v in st.items()), B),
              Spacer(1, 10), Paragraph("Indicative. AI-assisted matching of the activities captured in the portal, by the bank's on-premise AI; every case is reviewed by HR before any decision. Powered by Operations Services.", S)]
    doc.build(story)
    buf.seek(0)
    audit(db, user, "role_overlap_pdf", "")
    db.commit()
    return StreamingResponse(buf, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="role_overlap_{datetime.now():%Y%m%d}.pdf"'})
