"""Staff segmentation tables: a table the admin writes by hand for a function (e.g. Credit Administration:
staff per segment and the business universe), shown from a button on that function's dashboard.
Nothing is loaded or reconciled: every figure is typed in by the admin."""
import io
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..security import audit, get_setting, require_admin, require_dashboard, sees_everything, set_setting, view_ids

router = APIRouter(prefix="/api/seg")
KEY = "seg_tables"


class RowIn(BaseModel):
    name: str = ""
    fte: Optional[float] = None
    ftc: Optional[float] = None
    universe: Optional[float] = None
    note: str = ""          # e.g. "Collaborative = 117 · Standalone = 570"


class TableIn(BaseModel):
    title: str = "Staff Segmentation"
    universe_label: str = "Business Universe"
    as_of: str = ""          # the date of the business universe, as written (e.g. 30.9.2026)
    rows: List[RowIn] = []


def _all(db) -> dict:
    return get_setting(db, KEY) or {}


def _may_see(user, db, fid: int) -> bool:
    return sees_everything(user) or fid in (view_ids(user, db) or set())


def _num(v):
    return None if v is None else (int(v) if float(v).is_integer() else v)


def _out(fid: int, t: dict, fname: str) -> dict:
    rows = [{"name": r.get("name", ""), "fte": _num(r.get("fte")), "ftc": _num(r.get("ftc")), "universe": _num(r.get("universe")), "note": r.get("note", "")}
            for r in t.get("rows", [])]
    tot = {k: _num(sum(r[k] or 0 for r in rows)) for k in ("fte", "ftc", "universe")}
    return {"function_id": fid, "function": fname, "title": t.get("title") or "Staff Segmentation",
            "universe_label": t.get("universe_label") or "Business Universe", "as_of": t.get("as_of", ""),
            "rows": rows, "total": tot, "updated_at": t.get("updated_at", ""), "updated_by": t.get("updated_by", "")}


@router.get("")
def tables(user=Depends(require_dashboard), db: Session = Depends(get_db)):
    """The functions with a table that this login can see (for the dashboard button)."""
    out = []
    for k, t in _all(db).items():
        fid = int(k)
        if t.get("rows") and _may_see(user, db, fid):
            out.append({"function_id": fid, "title": t.get("title") or "Staff Segmentation"})
    return out


@router.get("/{fid}")
def table(fid: int, user=Depends(require_dashboard), db: Session = Depends(get_db)):
    t = _all(db).get(str(fid))
    f = db.get(models.Function, fid)
    if not f or not _may_see(user, db, fid):
        raise HTTPException(404, "No table for this function.")
    if t is None:
        if user.role != "admin":
            raise HTTPException(404, "No table for this function.")
        t = {}
    return _out(fid, t, f.name)


@router.put("/{fid}")
def save(fid: int, body: TableIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    f = db.get(models.Function, fid)
    if not f:
        raise HTTPException(404, "Function not found")
    rows = [{"name": " ".join(r.name.split())[:150], "fte": r.fte, "ftc": r.ftc, "universe": r.universe, "note": " ".join(r.note.split())[:200]}
            for r in body.rows if r.name.strip() or r.fte or r.ftc or r.universe]
    al = _all(db)
    al[str(fid)] = {"title": " ".join(body.title.split())[:80] or "Staff Segmentation", "universe_label": " ".join(body.universe_label.split())[:60] or "Business Universe",
                    "as_of": body.as_of.strip()[:30], "rows": rows, "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M"), "updated_by": user.username}
    set_setting(db, KEY, al)
    audit(db, user, "seg_table", f"{f.name}: {len(rows)} rows")
    db.commit()
    return _out(fid, al[str(fid)], f.name)


@router.delete("/{fid}")
def remove(fid: int, user=Depends(require_admin), db: Session = Depends(get_db)):
    al = _all(db)
    if al.pop(str(fid), None) is not None:
        set_setting(db, KEY, al)
        audit(db, user, "seg_table_removed", str(fid))
        db.commit()
    return {"ok": True}


@router.get("/{fid}/export")
def export(fid: int, user=Depends(require_dashboard), db: Session = Depends(get_db)):
    d = table(fid, user, db)
    wb = Workbook()
    ws = wb.active
    ws.title = d["title"][:31]
    uni = d["universe_label"] + (f" as of {d['as_of']}" if d["as_of"] else "")
    ws.append([d["function"]])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([])
    ws.append([d["title"], "Total FTEs", "Total FTCs", "Total", uni, "Note"])
    head = PatternFill("solid", fgColor="00665B")
    for c in ws[3]:
        c.font, c.fill, c.alignment = Font(bold=True, color="FFFFFF"), head, Alignment(horizontal="center", vertical="center", wrap_text=True)
    for r in d["rows"]:
        tot = (r["fte"] or 0) + (r["ftc"] or 0)
        ws.append([r["name"], r["fte"], r["ftc"], tot or None, r["universe"], r["note"]])
    t = d["total"]
    ws.append(["Grand Total", t["fte"], t["ftc"], (t["fte"] or 0) + (t["ftc"] or 0), t["universe"], ""])
    for c in ws[ws.max_row]:
        c.font, c.fill = Font(bold=True), PatternFill("solid", fgColor="DCEFEA")
    for row in ws.iter_rows(min_row=4, min_col=2, max_col=5):
        for c in row:
            c.number_format = "#,##0"
    for col, w in zip("ABCDEF", (46, 12, 12, 10, 28, 40)):
        ws.column_dimensions[col].width = w
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    name = "".join(ch for ch in f"{d['title']} - {d['function']}" if ch.isalnum() or ch in " -_")[:80]
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="{name}.xlsx"'})
