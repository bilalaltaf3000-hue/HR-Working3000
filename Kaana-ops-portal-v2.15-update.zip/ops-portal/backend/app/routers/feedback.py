"""Feedback: every login can send feedback about any change; the admin reads it, sets a status and replies."""
import csv
import io
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..security import audit, can_edit_function, current_user, in_units, read_ids, require_admin, unit_scope

router = APIRouter(prefix="/api/feedback")
TOPICS = ("Change request", "Employee change", "Issue", "Suggestion", "Other")
CHANGE_TYPES = ("retag", "remove", "add")
STATUSES = ("New", "Under review", "Done", "Not planned")


class ChangeIn(BaseModel):
    type: str
    code: Optional[str] = None            # the employee (re-tag, remove)
    manager_code: Optional[str] = None    # new manager (re-tag) or manager (add)
    function_id: Optional[int] = None     # new function (re-tag) or function (add)
    unit: Optional[str] = None
    name: Optional[str] = None            # add
    new_code: Optional[str] = None        # add
    position: Optional[str] = None
    grade: Optional[str] = None
    emp_type: Optional[str] = None


class FeedbackIn(BaseModel):
    page: str = ""
    topic: str = "Change request"
    message: str = ""
    change: Optional[ChangeIn] = None


class FeedbackUpd(BaseModel):
    status: Optional[str] = None
    reply: Optional[str] = None


def change_text(ch: dict, names=None, fnames=None) -> str:
    """A plain description of an employee change request."""
    if not ch:
        return ""
    names, fnames = names or {}, fnames or {}
    who = f"{ch.get('name') or names.get(ch.get('code'), '')} ({ch.get('code')})" if ch.get("code") else ""
    if ch.get("type") == "remove":
        return f"Remove {who}"
    if ch.get("type") == "retag":
        parts = []
        if ch.get("manager_code"):
            parts.append(f"report to {names.get(ch['manager_code'], ch['manager_code'])} ({ch['manager_code']})")
        if ch.get("function_id"):
            parts.append(f"move to {fnames.get(ch['function_id'], 'another function')}")
        if ch.get("unit"):
            parts.append(f"unit {ch['unit']}")
        return f"Re-tag {who}: " + ", ".join(parts)
    if ch.get("type") == "add":
        bits = [x for x in [ch.get("position"), ch.get("grade"), ch.get("emp_type"), fnames.get(ch.get("function_id")), ch.get("unit")] if x]
        mgr = f", reports to {names.get(ch.get('manager_code'), ch.get('manager_code'))}" if ch.get("manager_code") else ""
        return f"Add {ch.get('name')} ({ch.get('new_code')})" + (f": {', '.join(bits)}" if bits else "") + mgr
    return ""


def ser(f: models.Feedback, names=None, fnames=None) -> dict:
    return {"id": f.id, "at": f.at.isoformat() if f.at else None, "username": f.username, "full_name": f.full_name or "",
            "page": f.page or "", "topic": f.topic or "", "message": f.message or "", "status": f.status or "New",
            "reply": f.reply or "", "updated_at": f.updated_at.isoformat() if f.updated_at else None,
            "change": f.change or None, "change_text": change_text(f.change, names, fnames) if f.change else ""}


def _lookup_names(db):
    return ({c: n for c, n in db.query(models.Employee.code, models.Employee.name)}, {x.id: x.name for x in db.query(models.Function)})


def _scope_emps(user, db):
    """Employees this login may raise a change for: their functions (input or dashboards), and their units."""
    ok = read_ids(user, db)
    us = unit_scope(user)
    fns = {f.id: f for f in db.query(models.Function)}
    out = []
    for e in db.query(models.Employee):
        if e.resigned or e.function_id not in ok:
            continue
        if user.role != "admin" and fns.get(e.function_id) and not can_edit_function(user, fns[e.function_id]) and not in_units(e, us):
            continue
        out.append(e)
    return out


@router.get("/employees")
def change_employees(user=Depends(current_user), db: Session = Depends(get_db)):
    """The employees, functions and units offered in an employee change request."""
    names, fnames = _lookup_names(db)
    emps = _scope_emps(user, db)
    units = {}
    for e in db.query(models.Employee.function_id, models.Employee.unit_name).distinct():
        if e[0] and e[1]:
            units.setdefault(str(e[0]), set()).add(e[1])
    return {"employees": sorted([{"code": e.code, "name": e.name, "position": e.position or "", "grade": e.grade, "function_id": e.function_id,
                                  "function": fnames.get(e.function_id, ""), "unit": e.unit_name or "", "manager_code": e.manager_code or "",
                                  "manager_name": names.get(e.manager_code, "")} for e in emps], key=lambda x: (x["function"], x["name"])),
            "functions": [{"id": i, "name": n} for i, n in sorted(fnames.items(), key=lambda kv: kv[1])],
            "units": {k: sorted(v) for k, v in units.items()}}


@router.post("")
def send(body: FeedbackIn, user=Depends(current_user), db: Session = Depends(get_db)):
    msg = (body.message or "").strip()
    ch = None
    fid = None
    if body.topic == "Employee change":
        c = body.change
        if not c or c.type not in CHANGE_TYPES:
            raise HTTPException(400, "Choose the type of change.")
        mine = {e.code: e for e in _scope_emps(user, db)}
        if c.type in ("retag", "remove"):
            if not c.code or c.code not in mine:
                raise HTTPException(400, "Choose an employee of your function.")
            if c.type == "retag" and not (c.manager_code or c.function_id or (c.unit or "").strip()):
                raise HTTPException(400, "Choose the new manager, function or unit.")
            if c.manager_code and not db.get(models.Employee, c.manager_code):
                raise HTTPException(400, "The new manager's code was not found.")
            fid = mine[c.code].function_id
        else:
            if not (c.new_code or "").strip() or not (c.name or "").strip():
                raise HTTPException(400, "Enter the new employee's code and name.")
            if db.get(models.Employee, c.new_code.strip()):
                raise HTTPException(400, "An employee with this code already exists.")
            fid = c.function_id
            if not fid or fid not in {e.function_id for e in mine.values()}:
                raise HTTPException(400, "Choose one of your functions for the new employee.")
            us = unit_scope(user)
            if user.role != "admin" and us and fid in us and (c.unit or "").strip() not in us[fid]:
                raise HTTPException(400, "Choose one of your units for the new employee.")
        ch = {k: v for k, v in c.model_dump().items() if v not in (None, "")}
        if not msg:
            msg = "-"
    elif len(msg) < 3:
        raise HTTPException(400, "Please write your feedback.")
    f = models.Feedback(username=user.username, full_name=user.full_name or "", page=(body.page or "")[:80],
                        topic=body.topic if body.topic in TOPICS else "Other", message=msg[:5000], change=ch, function_id=fid)
    db.add(f)
    audit(db, user, "feedback", f"{f.topic}: {msg[:80]}")
    db.commit()
    return ser(f, *_lookup_names(db))


@router.get("/mine")
def mine(user=Depends(current_user), db: Session = Depends(get_db)):
    q = db.query(models.Feedback).filter(models.Feedback.username == user.username).order_by(models.Feedback.id.desc())
    nm = _lookup_names(db)
    return [ser(f, *nm) for f in q.limit(200)]


@router.get("")
def all_feedback(user=Depends(require_admin), db: Session = Depends(get_db)):
    nm = _lookup_names(db)
    return [ser(f, *nm) for f in db.query(models.Feedback).order_by(models.Feedback.id.desc()).limit(2000)]


@router.put("/{fid}")
def update(fid: int, body: FeedbackUpd, user=Depends(require_admin), db: Session = Depends(get_db)):
    f = db.get(models.Feedback, fid)
    if not f:
        raise HTTPException(404, "Feedback not found.")
    if body.status is not None:
        if body.status not in STATUSES:
            raise HTTPException(400, "Unknown status.")
        f.status = body.status
    if body.reply is not None:
        f.reply = body.reply.strip()[:3000]
    f.updated_at = datetime.utcnow()
    audit(db, user, "feedback_update", f"#{f.id}: {f.status}")
    db.commit()
    return ser(f, *_lookup_names(db))


@router.post("/{fid}/apply")
def apply_change(fid: int, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Make the employee change a request asks for, with the same checks as Admin, Employees."""
    from .staffadmin import EmpEdit, EmpNew, add_employee, edit_employee, remove_employee
    f = db.get(models.Feedback, fid)
    if not f or not f.change:
        raise HTTPException(404, "This feedback is not an employee change request.")
    if f.status == "Done":
        raise HTTPException(400, "This request has already been applied.")
    c = f.change
    t = c.get("type")
    if t == "remove":
        remove_employee(c["code"], user, db)
        f = db.get(models.Feedback, fid)
    elif t == "retag":
        e = db.get(models.Employee, c.get("code") or "")
        if not e:
            raise HTTPException(404, "The employee is no longer in the portal.")
        upd = {}
        if c.get("manager_code"):
            upd["manager_code"] = c["manager_code"]
        if c.get("function_id"):
            upd["function_id"] = int(c["function_id"])
            upd["move_team"] = False
        if c.get("unit"):
            upd["unit"] = c["unit"]
        edit_employee(c["code"], EmpEdit(**upd), user, db)
    elif t == "add":
        if not c.get("function_id") or not c.get("manager_code"):
            raise HTTPException(400, "The request needs the function and the manager. Add the employee in Admin, Employees instead.")
        add_employee(EmpNew(code=c["new_code"], name=c["name"], position=c.get("position", ""), grade=c.get("grade", ""),
                            emp_type=c.get("emp_type") or "FTE", function_id=int(c["function_id"]), manager_code=c["manager_code"],
                            unit=c.get("unit", "")), user, db)
    else:
        raise HTTPException(400, "Unknown change.")
    f = db.get(models.Feedback, fid)
    f.status = "Done"
    if not f.reply:
        f.reply = "Applied."
    f.updated_at = datetime.utcnow()
    audit(db, user, "feedback_apply", f"#{fid}: {change_text(c)}")
    db.commit()
    return ser(f, *_lookup_names(db))


@router.delete("/{fid}")
def remove(fid: int, user=Depends(require_admin), db: Session = Depends(get_db)):
    f = db.get(models.Feedback, fid)
    if not f:
        raise HTTPException(404, "Feedback not found.")
    db.delete(f)
    audit(db, user, "feedback_delete", f"#{fid}")
    db.commit()
    return {"ok": True}


@router.get("/export.csv")
def export_csv(user=Depends(require_admin), db: Session = Depends(get_db)):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["#", "Date (UTC)", "Name", "Login", "Page", "Topic", "Feedback", "Status", "Reply"])
    for f in db.query(models.Feedback).order_by(models.Feedback.id):
        w.writerow([f.id, f"{f.at:%Y-%m-%d %H:%M}" if f.at else "", f.full_name, f.username, f.page, f.topic, f.message, f.status, f.reply])
    data = ("﻿" + buf.getvalue()).encode("utf-8")
    return StreamingResponse(io.BytesIO(data), media_type="text/csv; charset=utf-8",
                             headers={"Content-Disposition": f"attachment; filename=portal_feedback_{datetime.now():%Y%m%d}.csv"})
