"""Password hashing, signed login tokens, role checks, settings and audit helpers.
Uses only the Python standard library so nothing extra has to be installed offline."""
import base64
import hashlib
import hmac
import json
import secrets
import time
from typing import Optional

from fastapi import Depends, Header, HTTPException
from sqlalchemy.orm import Session

from .config import SECRET_KEY, TOKEN_HOURS
from .db import get_db
from . import models

_ITER = 200_000


def hash_password(pw: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), _ITER)
    return f"pbkdf2${_ITER}${salt}${dk.hex()}"


def verify_password(pw: str, stored: str) -> bool:
    try:
        _, it, salt, h = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), int(it))
        return hmac.compare_digest(dk.hex(), h)
    except Exception:
        return False


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def make_token(user: models.User) -> str:
    payload = {"uid": user.id, "exp": int(time.time()) + TOKEN_HOURS * 3600}
    body = _b64(json.dumps(payload).encode())
    sig = _b64(hmac.new(SECRET_KEY.encode(), body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}"


def read_token(token: str) -> Optional[int]:
    try:
        body, sig = token.split(".")
        good = _b64(hmac.new(SECRET_KEY.encode(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(good, sig):
            return None
        data = json.loads(_unb64(body))
        if data["exp"] < time.time():
            return None
        return int(data["uid"])
    except Exception:
        return None


def current_user(authorization: str = Header(default=""), db: Session = Depends(get_db)) -> models.User:
    token = authorization.replace("Bearer ", "").strip()
    uid = read_token(token) if token else None
    user = db.get(models.User, uid) if uid else None
    if not user or not user.active:
        raise HTTPException(401, "Please sign in again.")
    return user


def require_admin(user: models.User = Depends(current_user)) -> models.User:
    if user.role != "admin":
        raise HTTPException(403, "Admin access required.")
    return user


# ---- access rights ----------------------------------------------------------
# Every user has two independent rights set by the admin:
#   input_functions : functions they can fill in (data capture)
#   view_mode       : dashboards for none / their input functions / selected functions / all
# Admins can do everything. Anyone who can input a function can also read its profile and employee details.

def all_function_ids(db: Session):
    return [f.id for f in db.query(models.Function.id)]


def input_ids(user: models.User, db: Session):
    if user.role == "admin":
        return set(all_function_ids(db))
    return set(user.input_functions or [])


def view_ids(user: models.User, db: Session):
    """Functions whose dashboards the user may see."""
    if user.role == "admin" or user.view_mode == "all":
        return set(all_function_ids(db))
    if user.view_mode == "input":
        return set(user.input_functions or [])
    if user.view_mode == "selected":
        return set(user.view_functions or [])
    return set()


def sees_everything(user: models.User) -> bool:
    return user.role == "admin" or user.view_mode == "all"


def read_ids(user: models.User, db: Session):
    return view_ids(user, db) | input_ids(user, db)


def can_read_function(user: models.User, function_id: int, db: Session = None) -> bool:
    if user.role == "admin" or user.view_mode == "all":
        return True
    return function_id in (set(user.input_functions or []) | (set(user.view_functions or []) if user.view_mode == "selected" else set()))


def unit_scope(user: models.User):
    """Units a dashboard login is limited to: {function id: {unit names}}, or None for no unit limit.
    Only for logins with dashboards for selected functions; a function without units listed is seen whole."""
    if user.role == "admin" or user.view_mode != "selected":
        return None
    d = {}
    for s in user.view_units or []:
        f, _, u = str(s).partition("|")
        if f.isdigit() and u.strip() and int(f) in set(user.view_functions or []):
            d.setdefault(int(f), set()).add(u.strip())
    return d or None


def in_units(e, scope) -> bool:
    """Whether an employee is inside a unit scope ({function id: {units}}; None = everyone)."""
    return not scope or e.function_id not in scope or (e.unit_name or "") in scope[e.function_id]


def merge_units(scope, picked, fids=None):
    """Combine the login's unit scope with units picked in the filter (unit names, any function)."""
    if not picked:
        return scope
    pk = {u.strip() for u in picked if u and u.strip()}
    out = {}
    for f in (fids if fids is not None else (scope or {}).keys()):
        base = (scope or {}).get(f)
        out[f] = (base & pk) if base is not None else set(pk)
    if scope:
        for f, us in scope.items():
            out.setdefault(f, us & pk)
    return out


def can_edit_function(user: models.User, fn: models.Function) -> bool:
    if user.role == "admin":
        return True
    return fn.id in (user.input_functions or [])  # submission no longer locks a function


def require_dashboard(user: models.User = Depends(current_user)) -> models.User:
    if user.role == "admin":
        return user
    no = (user.view_mode or "none") == "none" or (user.view_mode == "input" and not user.input_functions) \
        or (user.view_mode == "selected" and not user.view_functions)
    if no:
        raise HTTPException(403, f"You are signed in as {user.username}, which has no dashboard access. "
                                 "Ask the admin to give this login dashboard rights (Admin, Users, Edit access), then sign in again.")
    return user


def require_export(user: models.User = Depends(current_user)) -> models.User:
    if user.role != "admin" and not user.can_export:
        raise HTTPException(403, "You do not have export rights. Ask the admin.")
    return user


# ---- settings -------------------------------------------------------------
DEFAULT_SETTINGS = {"productive_hours": 7.5, "root_code": "", "senior_rank": 68, "large_team": 40,
                    "working_days_week": 5, "working_days_month": 22, "group_label": "COSO",
                    "show_time": False}


def get_setting(db: Session, key: str):
    row = db.get(models.Setting, key)
    return row.value if row else DEFAULT_SETTINGS.get(key)


def set_setting(db: Session, key: str, value):
    row = db.get(models.Setting, key)
    if row:
        row.value = value
    else:
        db.add(models.Setting(key=key, value=value))


def audit(db: Session, user: Optional[models.User], action: str, detail: str = ""):
    db.add(models.AuditLog(username=user.username if user else "system", action=action, detail=detail[:4000]))
