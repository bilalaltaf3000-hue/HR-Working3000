from datetime import datetime

from sqlalchemy import (Boolean, Column, DateTime, Float, ForeignKey, Integer,
                        String, Text, JSON)
from sqlalchemy.orm import relationship

from .db import Base


class Function(Base):
    __tablename__ = "functions"
    id = Column(Integer, primary_key=True)
    name = Column(String(200), unique=True, nullable=False)
    hr_name = Column(String(200), nullable=True)   # the name in the HR master sheet (the portal name can be renamed)
    bm_band = Column(String(8), nullable=True)     # grade benchmark size band set by hand: "small" (under 50) / "large" (50 or more); None = from headcount
    org_type = Column(String(12), nullable=True)   # grade benchmark: "division" / "department" (None = not tagged yet)
    status = Column(String(30), default="Not started")  # Not started / In progress / Submitted
    status_at = Column(DateTime, nullable=True)
    units_seeded = Column(Boolean, default=False)


class Employee(Base):
    __tablename__ = "employees"
    code = Column(String(50), primary_key=True)
    name = Column(String(200), nullable=False)
    grade = Column(String(60), default="")          # display grade, e.g. "SM I"
    grade_raw = Column(String(80), default="")      # as in sheet, e.g. "068-SM I"
    grade_rank = Column(Integer, default=-1)        # higher = more senior; -1 outsourced
    position = Column(String(250), default="")
    function_id = Column(Integer, ForeignKey("functions.id"), nullable=True)
    manager_code = Column(String(50), nullable=True)
    gender = Column(String(10), default="")
    emp_type = Column(String(5), default="FTE")     # FTE = permanent, FTC = contract/outsourced
    source = Column(String(10), default="master")   # master / added
    verified = Column(Boolean, default=True)
    external = Column(Boolean, default=False)
    exclude = Column(Boolean, default=False)        # exclude from span & headcount
    flag_reason = Column(String(300), default="")
    unit_id = Column(Integer, ForeignKey("units.id", ondelete="SET NULL"), nullable=True)
    region = Column(String(80), nullable=True)
    unit_source = Column(String(10), nullable=True)    # manual / inherited (from their manager)
    region_source = Column(String(10), nullable=True)  # manual / inherited / import
    unit_name = Column(String(200), nullable=True)      # the employee's unit, set in data capture step 1
    unit_name_source = Column(String(10), nullable=True)  # manual / inherited
    overrides = Column(JSON, nullable=True)  # fields changed by the admin; kept when the master sheet is imported again
    service_role = Column(String(10), nullable=True)        # Service or Support: the type of work the employee does
    service_role_source = Column(String(10), nullable=True)  # manual / inherited
    resigned = Column(Boolean, default=False)                # marked by the admin: left out of every count and list
    resigned_on = Column(String(10), nullable=True)
    added_by = Column(String(80), nullable=True)
    added_at = Column(DateTime, nullable=True)
    # the reporting line and function in the HR master sheet (set at every master import); "?" / -1 = not known yet
    hr_manager_code = Column(String(50), nullable=True)
    hr_function_id = Column(Integer, nullable=True)
    hr_row = Column(JSON, nullable=True)        # the employee's row in the last HR master sheet, as it was
    hr_row_no = Column(Integer, nullable=True)  # its place in that sheet
    is_dc = Column(Boolean, default=False)          # DC / Contract: retired and rehired on contract (its own type on the dashboard)
    is_dw = Column(Boolean, default=False)          # Daily Wager (its own type on the dashboard)
    org_note = Column(String(300), nullable=True)   # a note shown on the person's organogram card (e.g. "Card Production moves here from Jan 26")
    vac_manager_id = Column(Integer, nullable=True)  # reports to a vacant position (shown under it); manager_code is who covers it meanwhile
    hc_saved = Column(Boolean, default=False)       # headcount saved: the role is removed in the restructure (CHRO dashboard)
    hc_reason = Column(String(200), nullable=True)
    hc_date = Column(String(10), nullable=True)
    bm_below = Column(String(12), nullable=True)  # grade benchmark: what this manager's direct reports are ("team" / "others"; None = by position)
    bm_level = Column(String(12), nullable=True)  # grade benchmark level set by the admin (None = worked out from the reporting line)


class Unit(Base):
    __tablename__ = "units"
    id = Column(Integer, primary_key=True)
    function_id = Column(Integer, ForeignKey("functions.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(200), nullable=False)
    lead_code = Column(String(50), nullable=True)
    coverage = Column(String(20), default="Centralized")  # Centralized / Regionalized
    regions = Column(JSON, default=list)
    sort = Column(Integer, default=0)
    processes = relationship("Process", cascade="all, delete-orphan", order_by="Process.id")


class Process(Base):
    __tablename__ = "processes"
    id = Column(Integer, primary_key=True)
    unit_id = Column(Integer, ForeignKey("units.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(250), default="")
    daily_volume = Column(Float, default=0)
    region_volumes = Column(JSON, default=dict)
    activities = relationship("Activity", cascade="all, delete-orphan", order_by="Activity.id")


class Activity(Base):
    __tablename__ = "activities"
    id = Column(Integer, primary_key=True)
    process_id = Column(Integer, ForeignKey("processes.id", ondelete="CASCADE"), nullable=False)
    description = Column(Text, default="")
    category = Column(String(120), default="Processor")
    minutes = Column(Float, default=0)
    basis = Column(String(10), default="item")  # item = times per process item; fixed = count per day
    quantity = Column(Float, default=1)
    split_mode = Column(String(10), default="equal")  # equal / share / volume (how named performers split the work)
    performers = relationship("ActivityPerformer", cascade="all, delete-orphan", order_by="ActivityPerformer.id")


class ActivityPerformer(Base):
    """Who performs an activity and their share of its volume. No rows = the whole unit shares it equally."""
    __tablename__ = "activity_performers"
    id = Column(Integer, primary_key=True)
    activity_id = Column(Integer, ForeignKey("activities.id", ondelete="CASCADE"), nullable=False)
    code = Column(String(50), nullable=False)
    share = Column(Float, default=0)   # % of the activity's volume (split_mode "share")
    volume = Column(Float, default=0)  # this person's own items per day (split_mode "volume")


class WorkItem(Base):
    """One activity performed by one employee (the data capture template).
    Volumes are per frequency period; time per item is in minutes."""
    __tablename__ = "work_items"
    id = Column(Integer, primary_key=True)
    employee_code = Column(String(50), index=True, nullable=False)
    unit = Column(String(200), default="")
    product = Column(String(200), default="")
    process = Column(String(250), default="")
    channel = Column(String(200), default="")
    description = Column(Text, default="")
    category = Column(String(200), default="")         # one-line summary of the description
    service_type = Column(String(10), default="")      # Service / Support
    frequency = Column(String(12), default="Daily")    # Daily / Weekly / Fortnightly / Monthly
    volume = Column(Float, nullable=True)              # average volume per frequency period
    volume_type = Column(String(10), default="")       # File = file based volume (rows in uploaded files); blank = activity based
    peak_som = Column(Float, nullable=True)            # peak: start of month, average per day
    peak_eom = Column(Float, nullable=True)            # peak: end of month, average per day
    handling = Column(String(15), default="")          # Manual / File Based / System Based
    minutes = Column(Float, nullable=True)             # staff processing time per item
    automation = Column(String(3), default="")         # Yes / No
    link_id = Column(String(32), nullable=True, index=True)  # same activity copied to colleagues
    sort = Column(Integer, default=0)
    created_by = Column(String(80), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class Frequency(Base):
    """Frequency options for activities, with the working days in one period (used to convert volumes to a day)."""
    __tablename__ = "frequencies"
    id = Column(Integer, primary_key=True)
    name = Column(String(40), unique=True, nullable=False)
    days = Column(Float, default=1)
    sort = Column(Integer, default=0)


class Category(Base):
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), unique=True, nullable=False)
    sort = Column(Integer, default=0)


class Region(Base):
    __tablename__ = "regions"
    id = Column(Integer, primary_key=True)
    name = Column(String(80), unique=True, nullable=False)
    sort = Column(Integer, default=0)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    full_name = Column(String(200), default="")
    password_hash = Column(String(300), nullable=False)
    role = Column(String(10), default="user")  # admin / user  (legacy: poc, viewer)
    function_id = Column(Integer, ForeignKey("functions.id", ondelete="SET NULL"), nullable=True)  # legacy
    input_functions = Column(JSON, default=list)   # function ids this user can fill in
    view_mode = Column(String(10), default="none")  # none / input / selected / all  (dashboards)
    view_functions = Column(JSON, default=list)    # used when view_mode == "selected"
    view_units = Column(JSON, default=list)        # optional: "function id|unit" entries; limits those functions to these units
    can_export = Column(Boolean, default=False)
    can_decisions = Column(Boolean, default=False)   # sees and records the recommendations (admins always)
    can_emp_changes = Column(Boolean, default=False)  # sees the Employee Changes page (admins always)
    can_summary = Column(Boolean, default=False)      # sees the work summary pop-up in the organogram
    can_bm_view = Column(Boolean, default=False)
    can_chro = Column(Boolean, default=False)
    can_hr_bm = Column(Boolean, default=False)        # sees the grade benchmark on the HR Dashboard (given by any admin)         # sees the CHRO dashboard (given by the admin login only)      # sees the View Benchmark button (the framework only, no one's grades)
    chro_mode = Column(String(10), default="view")   # HR Dashboard functions: view (as their dashboard view) / all / selected
    chro_functions = Column(JSON, default=list)       # used when chro_mode == "selected"
    can_layer_edit = Column(Boolean, default=False)   # may set levels from the layer panel (edit mode)
    can_layers = Column(Boolean, default=False)       # sees the layer panel beside the organogram
    can_bm_edit = Column(Boolean, default=False)      # may change the grade benchmark (given only by the "admin" login)
    can_benchmark = Column(Boolean, default=False)    # sees the grade benchmark (given only by the "admin" login)
    can_role_overlap = Column(Boolean, default=False)  # sees and reviews Role Overlap (only the admin runs the AI)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class RetagRequest(Base):
    __tablename__ = "retag_requests"
    id = Column(Integer, primary_key=True)
    code = Column(String(50), nullable=False)
    kind = Column(String(10), default="function")    # function (move to another function) / manager (new reporting line)
    from_function_id = Column(Integer, nullable=True)
    to_function_id = Column(Integer, nullable=True)
    from_manager = Column(String(50), nullable=True)
    to_manager = Column(String(50), nullable=True)
    requested_by = Column(String(80))
    note = Column(String(300), default="")
    status = Column(String(15), default="Pending")  # Pending / Approved / Rejected
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_by = Column(String(80), nullable=True)
    resolved_at = Column(DateTime, nullable=True)


class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(80), primary_key=True)
    value = Column(JSON)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True)
    at = Column(DateTime, default=datetime.utcnow)
    username = Column(String(80))
    action = Column(String(80))
    detail = Column(Text, default="")


class Feedback(Base):
    """Feedback from any login about the portal: a change, an issue or a suggestion, read by the admin."""
    __tablename__ = "feedback"
    id = Column(Integer, primary_key=True)
    at = Column(DateTime, default=datetime.utcnow)
    username = Column(String(80))
    full_name = Column(String(200), default="")
    page = Column(String(80), default="")        # where in the portal it is about
    topic = Column(String(30), default="Change request")   # Change request / Issue / Suggestion / Other
    message = Column(Text, default="")
    status = Column(String(20), default="New")   # New / Under review / Done / Not planned
    reply = Column(Text, default="")             # the admin's note back to the person
    updated_at = Column(DateTime, nullable=True)
    change = Column(JSON, nullable=True)         # an employee change request: {type: retag/remove/add, ...}
    function_id = Column(Integer, nullable=True)


class Vacancy(Base):
    """A vacant or to be hired position in a function, written by the admin. Shown in the function's organogram
    under the manager it will report to; never counted as an employee."""
    __tablename__ = "vacancies"
    id = Column(Integer, primary_key=True)
    function_id = Column(Integer, nullable=False)
    manager_code = Column(String(50), nullable=True)    # who the position will report to
    parent_id = Column(Integer, nullable=True)          # or another vacant position it will report to
    position = Column(String(250), default="")
    grade = Column(String(60), default="")
    emp_type = Column(String(5), default="FTE")         # FTE / FTC
    kind = Column(String(12), default="new")            # "replacement" (someone left) or "new" (a new position)
    count = Column(Integer, default=1)                  # how many such positions
    unit = Column(String(200), default="")
    note = Column(Text, default="")
    jd = Column(Text, default="")                       # job description / activities of the position
    filled = Column(Integer, default=0)                 # how many of the positions are filled
    removed = Column(Boolean, default=False)            # hiring removed (asked not to hire): kept and shown greyed, not counted as to be hired
    removed_on = Column(String(10), nullable=True)
    removed_reason = Column(String(300), nullable=True)
    filled_log = Column(JSON, nullable=True)            # [{code, name, on, by}] one entry per position filled
    created_by = Column(String(80), default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class Decision(Base):
    """An HR decision about a function (for example a restructuring, a new role, a transfer), recorded by the admin
    or a login with decisions access, and seen only by them."""
    __tablename__ = "decisions"
    id = Column(Integer, primary_key=True)
    function_id = Column(Integer, nullable=True)        # blank = applies across functions
    decided_on = Column(String(10), nullable=True)      # YYYY-MM-DD
    subject = Column(String(250), default="")
    details = Column(Text, default="")
    status = Column(String(20), default="Recommended")  # Recommended / Approved / Implemented / On hold
    recorded_by = Column(String(80), default="")
    recorded_name = Column(String(200), default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_by = Column(String(80), nullable=True)
    updated_at = Column(DateTime, nullable=True)


# ---------------------------------------------------------------- consistent capitalisation
from sqlalchemy import event  # noqa: E402
from .textnorm import name_case, products_case, text_case, title_case  # noqa: E402


@event.listens_for(Employee, "before_insert")
@event.listens_for(Employee, "before_update")
def _norm_employee(mapper, conn, e):
    if e.name:
        e.name = name_case(e.name)
    if e.position:
        e.position = title_case(e.position)
    if e.unit_name:
        e.unit_name = title_case(e.unit_name)


@event.listens_for(WorkItem, "before_insert")
@event.listens_for(WorkItem, "before_update")
def _norm_item(mapper, conn, w):
    for f in ("category", "description", "process", "channel", "unit"):
        v = getattr(w, f, None)
        if v:
            setattr(w, f, text_case(v))
    if w.product:
        w.product = products_case(w.product)


# ---------------------------------------------------------------- role overlap (on-premise AI)
class RoRun(Base):
    """One run of the role overlap analysis (one function, or all of them), done in the background by the admin."""
    __tablename__ = "ro_runs"
    id = Column(Integer, primary_key=True)
    function_id = Column(Integer, nullable=True)       # blank = all functions
    kind = Column(String(12), default="overlap")       # overlap (Role Overlap) / summary (work summaries)
    status = Column(String(20), default="queued")      # queued / running / done / failed / cancelled
    total = Column(Integer, default=0)                 # AI requests planned
    done = Column(Integer, default=0)
    failed = Column(Integer, default=0)
    current = Column(String(250), default="")          # what it is working on
    error = Column(Text, default="")
    model = Column(String(200), default="")
    started_by = Column(String(80), default="")
    started_at = Column(DateTime, default=datetime.utcnow)
    finished_at = Column(DateTime, nullable=True)


class RoResult(Base):
    """The analysis of one function: its supervisors and colleague pairs, as found by the last run that covered it."""
    __tablename__ = "ro_results"
    id = Column(Integer, primary_key=True)
    function_id = Column(Integer, index=True)
    run_id = Column(Integer)
    payload = Column(JSON)          # {"supervisors": [...], "pairs": [...], "acts": {...}, "emps": {...}}
    created_at = Column(DateTime, default=datetime.utcnow)


class AsIsEmp(Base):
    """The As Is organisation for the CHRO dashboard: the HR master file as it was, which the admin can correct
    (add missing employees, fix a manager, function or grade) or replace with a new HR file. It never changes the
    rest of the portal."""
    __tablename__ = "chro_asis"
    code = Column(String(50), primary_key=True)
    name = Column(String(200), default="")
    grade = Column(String(80), default="")
    grade_raw = Column(String(80), default="")
    grade_rank = Column(Integer, default=-1)
    position = Column(String(250), default="")
    function = Column(String(200), default="")      # the function name, as in the HR file
    manager_code = Column(String(50), nullable=True)
    emp_type = Column(String(10), default="FTE")
    kind = Column(String(4), default="")            # "", "dc" (Contract) or "dw" (Daily Wager)
    gender = Column(String(4), default="")
    unit = Column(String(200), default="")
    source = Column(String(10), default="file")      # file / edited / added
    note = Column(String(200), default="")
    edited_by = Column(String(100), default="")
    edited_at = Column(DateTime, nullable=True)


class EmpSummary(Base):
    """The AI's summary of one employee's captured work, written in the background by the admin."""
    __tablename__ = "emp_summaries"
    code = Column(String(50), primary_key=True)
    summary = Column(Text, default="")                 # a few sentences (blank when too few activities)
    items = Column(JSON, nullable=True)                # [{"id": activity id, "text": short phrase}]
    acts_hash = Column(String(64), default="")         # the activities it was written from (changed = out of date)
    n_acts = Column(Integer, default=0)
    model = Column(String(200), default="")
    at = Column(DateTime, default=datetime.utcnow)


class RoCase(Base):
    """HR's review of one case (a supervisor, or a pair of colleagues). Kept across runs."""
    __tablename__ = "ro_cases"
    key = Column(String(120), primary_key=True)     # "sup:<code>" or "pair:<code>|<code>"
    function_id = Column(Integer, nullable=True)
    status = Column(String(20), default="Open")     # Open / Under review / Confirmed / Dismissed
    note = Column(Text, default="")
    owner = Column(String(80), default="")
    decisions = Column(JSON, nullable=True)          # {"<activity id>-<activity id>": "confirmed" | "rejected"}
    decision_id = Column(Integer, nullable=True)     # the Recommendation made from it
    updated_by = Column(String(80), default="")
    updated_at = Column(DateTime, nullable=True)
