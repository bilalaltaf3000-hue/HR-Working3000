"""Finished dashboard answers, kept until anything in the database changes.

Most page views ask for the same figures again (the same login, function and filters). Working them out takes
time with thousands of activities, so each answer is kept, ready encoded, and handed out again while the data is
unchanged. Any change anywhere (a save, an upload, an import, a change of a login's rights) makes every kept
answer out of date: the database files' change time and size are checked on every request, and a save in this
process is noticed at once. Answers are kept for a few minutes at most, and per login, so rights always apply."""
import functools
import json
import os
import threading
import time
from collections import OrderedDict

from fastapi.encoders import jsonable_encoder
from fastapi.responses import Response
from sqlalchemy import event
from sqlalchemy.orm import Session

from .db import engine

_lock = threading.Lock()
_store: "OrderedDict[tuple, tuple]" = OrderedDict()
_saves = [0]
MAX_ENTRIES = 300
TTL = 300   # seconds

_path = engine.url.database if engine.url.drivername.startswith("sqlite") else None


@event.listens_for(Session, "after_commit")
def _after_commit(session):
    _saves[0] += 1


def data_version():
    v = [_saves[0]]
    if _path and _path != ":memory:":
        for p in (_path, _path + "-wal"):
            try:
                st = os.stat(p)
                v += [st.st_mtime_ns, st.st_size]
            except OSError:
                v += [0, 0]
    return tuple(v)


def clear():
    with _lock:
        _store.clear()


def cached_json(fn):
    """For a GET endpoint with `user` and `db` parameters: the same login and the same parameters get the kept
    answer while the data is unchanged."""
    @functools.wraps(fn)
    def wrapper(*args, **kw):
        user = kw.get("user")
        key = (fn.__module__, fn.__name__, getattr(user, "id", None),
               repr(sorted((k, v) for k, v in kw.items() if k not in ("db", "user"))))
        ver, now = data_version(), time.time()
        with _lock:
            hit = _store.get(key)
            if hit and hit[0] == ver and now - hit[1] < TTL:
                _store.move_to_end(key)
                return Response(hit[2], media_type="application/json")
        out = fn(*args, **kw)
        if isinstance(out, Response):
            return out
        body = json.dumps(jsonable_encoder(out), separators=(",", ":"), ensure_ascii=False).encode()
        with _lock:
            _store[key] = (ver, now, body)
            _store.move_to_end(key)
            while len(_store) > MAX_ENTRIES:
                _store.popitem(last=False)
        return Response(body, media_type="application/json")
    return wrapper
