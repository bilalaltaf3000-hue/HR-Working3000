"""Import the employee master sheet.

Rules (agreed with the business):
* Employee code is the unique key and is always treated as text.
* The hierarchy is built ONLY from employee code + N-1 manager code. N-2..N-7 and the
  Hierarchy Path text are used for checks only, so a manager repeated in the chain can
  never create an extra layer.
* A manager code stored as a number (e.g. 0 instead of "00000") is matched to the text code.
* Self-reporting and circular reporting are blocked and reported.
* Staff added by function POCs are kept; if their code appears in a later master sheet
  they become regular (verified) master records.
"""
import io
import re
from collections import Counter
from datetime import datetime

from openpyxl import load_workbook
from sqlalchemy.orm import Session

from . import models
from .config import OUTSOURCED_GRADE_TEXT
from .security import get_setting, set_setting

HONORIFIC = re.compile(r"^(mr|mrs|ms|miss|dr|mst)\.?\s+", re.I)


def clean_name(n) -> str:
    s = str(n or "").strip()
    s = HONORIFIC.sub("", s)
    s = s.replace(" . ", " ").replace(".", " ")
    s = re.sub(r"\s*,\s*", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    s = s.strip(" ,")
    return s


def code_text(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = str(v).strip()
    if s.endswith(".0") and s[:-2].isdigit():
        s = s[:-2]
    return s


def strip_prefix(s) -> str:
    """'070-VP', '070 - VP' or '000 Outsourced' -> the text after the code."""
    s = str(s or "").strip()
    m = re.match(r"^\d+\s*[-–:.]?\s*(\D.*)$", s)
    return (m.group(1) if m else s).strip()


def is_outsourced(raw) -> bool:
    """Outsourced staff, however the grade is written: 'Outsourced Staff', '000-Outsourced', '000 Outsourced Staff'."""
    r = str(raw or "").strip().lower()
    return r == OUTSOURCED_GRADE_TEXT or "outsourc" in r


def is_external_grade(raw) -> bool:
    """A grade of only zeros ('000') marks an external person, for example an external partner."""
    return bool(re.fullmatch(r"0+", str(raw or "").strip()))


def grade_label(raw) -> str:
    if is_outsourced(raw):
        return "FTC"
    if is_external_grade(raw):
        return "External"
    return strip_prefix(raw) or "-"


SEC_GRADE = re.compile(r"\bSEC\b", re.I)


def exclude_secretaries(db: Session) -> int:
    """Secretaries (a grade with the word SEC, e.g. "S SEC II") are left out of the employee lists and counts, unless the
    admin counts them again by hand."""
    n = 0
    for e in db.query(models.Employee).filter(models.Employee.exclude == False):  # noqa: E712
        if SEC_GRADE.search(e.grade_raw or e.grade or "") and "exclude" not in (e.overrides or []):
            e.exclude = True
            n += 1
    return n


def tidy_grades(db: Session) -> int:
    """Grades shown without their code, outsourced staff as FTC (grade and type), grade '000' as External
    (and flagged external). Changes the admin made by hand are kept."""
    from . import models
    n = 0
    for e in db.query(models.Employee).filter(models.Employee.grade_raw.isnot(None)):
        ov = e.overrides or []
        if "grade" not in ov:
            g, rk = grade_label(e.grade_raw), grade_rank(e.grade_raw)
            if e.grade != g or e.grade_rank != rk:
                e.grade, e.grade_rank = g, rk
                n += 1
        if is_outsourced(e.grade_raw) and e.emp_type != "FTC" and "emp_type" not in ov:
            e.emp_type = "FTC"
            n += 1
        if is_external_grade(e.grade_raw) and not e.external and "external" not in ov:
            e.external = True
            n += 1
    return n


def grade_rank(raw: str) -> int:
    if is_outsourced(raw):
        return -1
    m = re.match(r"^\s*(\d+)", raw)
    return int(m.group(1)) if m else -1


def _cell(v):
    """A sheet value as it can be stored (JSON): numbers and text as they are, dates as text."""
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    return str(v)


def _norm_header(h) -> str:
    return re.sub(r"\s+", " ", str(h or "").strip().lower())


REQUIRED = {
    "code": "n employee no",
    "name": "n employee name",
    "grade": "n employee grade",
    "function": "n function",
    "manager": "n-1 manager number",
}
OPTIONAL = {
    "gender": "n gender",
    "position": "n position name",
    "layers": "layers",
}
# optional region / location column: the first of these headers that is present is used
REGION_HEADERS = ["n region", "region", "n location", "location", "n city", "city", "n work location", "work location"]


def import_workbook(db: Session, content: bytes, username: str) -> dict:
    wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    ws = wb.worksheets[0]
    rows = ws.iter_rows(values_only=True)
    raw_header = [str(h).strip() if h is not None else "" for h in next(rows)]
    header = [_norm_header(h) for h in raw_header]
    idx = {}
    for key, name in {**REQUIRED, **OPTIONAL}.items():
        if name in header:
            idx[key] = header.index(name)
    missing = [REQUIRED[k] for k in REQUIRED if k not in idx]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing))
    chain_cols = [i for i, h in enumerate(header) if re.match(r"^n-\d manager number", h)]
    region_col = next((header.index(h) for h in REGION_HEADERS if h in header), None)

    recs = {}
    dup_codes = []
    repeated_chain = []
    row_no = 0
    for r in rows:
        row_no += 1
        code = code_text(r[idx["code"]])
        if not code:
            continue
        if code in recs:
            dup_codes.append(code)
            continue
        raw_grade = str(r[idx["grade"]] or "").strip()
        chain = [code_text(r[i]) for i in chain_cols if code_text(r[i])]
        if len(chain) != len(set(chain)):
            rep = [c for i, c in enumerate(chain) if c in chain[:i]]
            repeated_chain.append({"code": code, "repeated": rep[0]})
        recs[code] = {
            "code": code,
            "name": clean_name(r[idx["name"]]) or code,
            "grade_raw": raw_grade,
            "grade": grade_label(raw_grade),
            "grade_rank": grade_rank(raw_grade),
            "emp_type": "FTC" if is_outsourced(raw_grade) else "FTE",
            "function": str(r[idx["function"]] or "Unassigned").strip() or "Unassigned",
            "manager": code_text(r[idx["manager"]]),
            "gender": str(r[idx["gender"]] or "").strip().lower()[:1] if "gender" in idx else "",
            "position": strip_prefix(r[idx["position"]]) if "position" in idx else "",
            "sheet_layer": r[idx["layers"]] if "layers" in idx else None,
            "region": " ".join(str(r[region_col] or "").split())[:80] if region_col is not None else "",
            "row": [_cell(v) for v in r[:len(raw_header)]], "row_no": row_no,   # the HR row as it is, for the full export
        }
    if not recs:
        raise ValueError("No employee rows found in the first sheet.")

    # --- employees the admin removed stay removed; whoever reported to them reports to their manager
    removed_set = get_setting(db, "removed_employees") or {}
    skipped_removed = [c for c in recs if c in removed_set]
    for c in skipped_removed:
        recs.pop(c)
    for rec in recs.values():
        m, n = rec["manager"], 0
        while m in removed_set and n < 30:
            m, n = removed_set[m].get("manager") or "", n + 1
        rec["manager"] = m
    if not recs:
        raise ValueError("No employee rows found in the first sheet.")

    # --- fix manager codes stored as numbers (e.g. 0 -> "00000")
    codes = set(recs)
    numeric = {}
    for c in codes:
        if c.isdigit():
            numeric.setdefault(int(c), c)
    fixed_numeric = []
    for rec in recs.values():
        m = rec["manager"]
        if m and m not in codes and m.isdigit() and int(m) in numeric:
            rec["manager"] = numeric[int(m)]
            fixed_numeric.append(rec["code"])

    # --- self reporting
    self_report = []
    for rec in recs.values():
        if rec["manager"] == rec["code"]:
            rec["manager"] = ""
            self_report.append(rec["code"])

    # --- root(s): manager missing from sheet
    root_code = (get_setting(db, "root_code") or "").strip()
    tops = [c for c, rec in recs.items() if not rec["manager"] or rec["manager"] not in codes]
    if root_code and root_code in recs:
        recs[root_code]["manager"] = ""
    # --- cycles
    cycles = []
    state = {}
    for start in recs:
        path = []
        cur = start
        while cur and cur in recs and state.get(cur) is None:
            state[cur] = "visiting"
            path.append(cur)
            cur = recs[cur]["manager"]
        if cur and cur in recs and state.get(cur) == "visiting":
            loop = path[path.index(cur):]
            cycles.append(loop)
            recs[loop[-1]]["manager"] = ""  # break loop
        for p in path:
            state[p] = "done"

    # choose root automatically if not configured: the top with the largest team
    kids = {}
    for rec in recs.values():
        if rec["manager"] in recs:
            kids.setdefault(rec["manager"], []).append(rec["code"])

    def team_size(c):
        n, st = 0, [c]
        while st:
            x = st.pop()
            for k in kids.get(x, []):
                n += 1
                st.append(k)
        return n

    tops = [c for c, rec in recs.items() if not rec["manager"] or rec["manager"] not in recs]
    if not root_code or root_code not in recs:
        root_code = max(tops, key=team_size)
        set_setting(db, "root_code", root_code)
    orphans = [c for c in tops if c != root_code]
    recs[root_code]["manager"] = ""

    # depth check vs sheet "Layers"
    depth = {root_code: 0}
    order = [root_code]
    for x in order:
        for k in kids.get(x, []):
            depth[k] = depth[x] + 1
            order.append(k)
    layer_diff = 0
    for c, rec in recs.items():
        sl = rec["sheet_layer"]
        try:
            if sl is not None and c in depth and int(sl) != depth[c]:
                layer_diff += 1
        except (TypeError, ValueError):
            pass

    # --- write to database
    fn_by_name = {}
    for f in db.query(models.Function).all():   # by the HR sheet's name first: a function renamed here is still found
        fn_by_name.setdefault(f.hr_name or f.name, f)
    for f in db.query(models.Function).all():
        fn_by_name.setdefault(f.name, f)
    for fname in sorted({rec["function"] for rec in recs.values()}):
        if fname not in fn_by_name:
            f = models.Function(name=fname, hr_name=fname)
            db.add(f)
            db.flush()
            fn_by_name[fname] = f

    # regions found in the sheet become selectable regions
    known_regions = {r.name.lower(): r.name for r in db.query(models.Region)}
    for reg in sorted({rec["region"] for rec in recs.values() if rec["region"]}):
        if reg.lower() not in known_regions:
            db.add(models.Region(name=reg, sort=99))
            known_regions[reg.lower()] = reg
    for rec in recs.values():
        if rec["region"]:
            rec["region"] = known_regions[rec["region"].lower()]

    set_setting(db, "hr_sheet_header", raw_header)   # the HR sheet's own columns, for the full export
    existing = {e.code: e for e in db.query(models.Employee).all()}
    created = updated = kept_overrides = 0
    for c, rec in recs.items():
        e = existing.get(c)
        if not e:
            e = models.Employee(code=c)
            db.add(e)
            created += 1
        else:
            updated += 1
        ov = set(e.overrides or [])   # fields the admin changed by hand are kept
        if ov:
            kept_overrides += 1
        if "name" not in ov:
            e.name = rec["name"]
        if "grade" not in ov:
            e.grade = rec["grade"]
            e.grade_raw = rec["grade_raw"]
            e.grade_rank = rec["grade_rank"]
        if "emp_type" not in ov:
            e.emp_type = rec["emp_type"]
        if "position" not in ov:
            e.position = rec["position"]
        if "gender" not in ov:
            e.gender = rec["gender"]
        if "manager" not in ov:
            e.manager_code = rec["manager"] or None
        if "function" not in ov:
            e.function_id = fn_by_name[rec["function"]].id
        e.hr_manager_code = rec["manager"] or None   # as in the HR master sheet, even when the admin changed it here
        e.hr_function_id = fn_by_name[rec["function"]].id
        e.hr_row, e.hr_row_no = rec["row"], rec["row_no"]
        e.source = "master"
        e.verified = True
        # region from the sheet, unless the function has set it themselves
        if rec["region"] and e.region_source not in ("manual", "inherited") and "region" not in ov:
            e.region, e.region_source = rec["region"], "import"

    removed = 0
    for c, e in existing.items():
        if c not in recs and e.source == "master":
            db.query(models.WorkItem).filter(models.WorkItem.employee_code == c).delete()
            db.delete(e)
            removed += 1

    added_kept = sum(1 for c, e in existing.items() if c not in recs and e.source == "added")
    grade_counter = Counter(rec["grade"] for rec in recs.values())
    report = {
        "at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "by": username,
        "rows": len(recs),
        "created": created,
        "updated": updated,
        "removed": removed,
        "skipped_removed": len(skipped_removed),
        "added_by_functions_kept": added_kept,
        "admin_changes_kept": kept_overrides,
        "fte": sum(1 for r in recs.values() if r["emp_type"] == "FTE"),
        "ftc": sum(1 for r in recs.values() if r["emp_type"] == "FTC"),
        "root_code": root_code,
        "root_name": recs[root_code]["name"],
        "duplicate_codes": dup_codes[:50],
        "duplicate_code_count": len(dup_codes),
        "repeated_chain_count": len(repeated_chain),
        "repeated_chain_managers": sorted({recs.get(x["repeated"], {}).get("name", x["repeated"]) for x in repeated_chain}),
        "numeric_manager_fixed": len(fixed_numeric),
        "self_report": self_report,
        "cycles": cycles,
        "orphans": [{"code": c, "name": recs[c]["name"], "manager": recs[c]["manager"]} for c in orphans][:100],
        "layer_diff": layer_diff,
        "region_column": header[region_col] if region_col is not None else None,
        "with_region": sum(1 for r in recs.values() if r["region"]),
        "grades": dict(grade_counter.most_common()),
    }
    set_setting(db, "last_import", report)
    exclude_secretaries(db)
    if tidy_grades(db):
        db.commit()
    return report


def load_hr_reference(db: Session, content: bytes, apply: bool) -> dict:
    """Read the HR master sheet for reference only: for each employee already in the portal it keeps HR's own row,
    manager and function, to compare with and for the full export. Nothing else changes: no employee is added,
    removed or edited, and activities, flags and every change made here stay as they are."""
    wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    ws = wb.worksheets[0]
    rows = ws.iter_rows(values_only=True)
    raw_header = [str(h).strip() if h is not None else "" for h in next(rows)]
    header = [_norm_header(h) for h in raw_header]
    idx = {k: header.index(n) for k, n in REQUIRED.items() if n in header}
    missing = [REQUIRED[k] for k in REQUIRED if k not in idx]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing))
    emps = {e.code: e for e in db.query(models.Employee)}
    fn_by_name = {}
    for f in db.query(models.Function):
        fn_by_name.setdefault((f.hr_name or f.name).strip().lower(), f.id)
    for f in db.query(models.Function):
        fn_by_name.setdefault(f.name.strip().lower(), f.id)
    removed = get_setting(db, "removed_employees") or {}
    seen, outside, n = set(), 0, 0
    rep_diff = fn_diff = 0
    plan = []
    for r in rows:
        n += 1
        code = code_text(r[idx["code"]])
        if not code or code in seen:
            continue
        seen.add(code)
        e = emps.get(code)
        if e is None or e.source == "added":
            outside += 0 if code in removed else 1
            continue
        m, k = code_text(r[idx["manager"]]), 0
        while m in removed and k < 30:   # as at import: past anyone removed here
            m, k = removed[m].get("manager") or "", k + 1
        if m == code or (m and m not in emps):   # self, or someone outside the portal (as at import: the top reports to no one)
            m = ""
        fname = str(r[idx["function"]] or "Unassigned").strip() or "Unassigned"
        fid = fn_by_name.get(fname.lower(), -1)
        rep_diff += (m or None) != (e.manager_code or None)
        fn_diff += fid != e.function_id
        plan.append((e, [_cell(v) for v in r[:len(raw_header)]], n, m or None, fid))
    master = [e for e in emps.values() if e.source == "master"]
    out = {"rows": n, "matched": len(plan), "portal_employees": len(master), "not_in_portal": outside,
           "portal_not_in_sheet": len(master) - len(plan), "reporting_differences": rep_diff, "function_differences": fn_diff,
           "applied": False}
    if len(plan) < max(1, len(master) // 2):
        raise ValueError(f"Only {len(plan)} of the portal's {len(master)} employees are in this sheet. Check that it is the full HR employee list.")
    if apply:
        for e, row, no, m, fid in plan:
            e.hr_row, e.hr_row_no, e.hr_manager_code, e.hr_function_id = row, no, m, fid
        set_setting(db, "hr_sheet_header", raw_header)
        out["applied"] = True
    return out
