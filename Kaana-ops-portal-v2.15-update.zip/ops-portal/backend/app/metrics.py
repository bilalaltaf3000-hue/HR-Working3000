"""Server-side version of the dashboard calculations, used by the PDF, PowerPoint, HTML and Excel exports.
The logic mirrors frontend/src/org.js so exported numbers match the screens."""
import re
from datetime import datetime
from typing import Optional, Set

from sqlalchemy.orm import Session

from . import models
from .logic import employee_work
from .orgdata import org_rows
from .security import get_setting


class P:
    __slots__ = ("i", "id", "n", "g", "f", "mc", "pos", "fte", "sex", "rk", "ext", "exc", "ctx", "rg", "st", "rs", "kids", "m", "d", "nk", "team", "below", "lay", "ly")


def _build(data, include_flagged: bool, senior: int):
    F = data["functions"]
    ps = []
    for i, a in enumerate(data["people"]):
        p = P()
        p.i, p.id, p.n, p.g, p.f, p.mc, p.pos = i, a[0], a[1] or a[0], a[2], a[3], a[4], a[5]
        p.fte, p.sex, p.rk, p.ext, p.exc, p.ctx = a[6] == 1, a[7], a[8], a[9] == 1, a[10] == 1, a[12] == 1
        p.rg, p.st = a[13] or "", a[14] or ""
        p.rs = len(a) > 15 and a[15] == 1
        p.lay = a[17] if len(a) > 17 else None   # the layer by level (tagged functions), else from the reporting depth
        p.kids, p.m, p.d, p.nk, p.team, p.below = [], -1, -1, 0, 0, 0
        ps.append(p)
    by = {p.id: p for p in ps}
    root = by.get(data["root_code"]) or (ps[0] if ps else None)
    for p in ps:
        if p is not root and p.mc in by:
            p.m = by[p.mc].i
            ps[p.m].kids.append(p)
    counted = (lambda p: not p.ctx and not p.rs) if include_flagged else (lambda p: not p.ctx and not p.exc and not p.rs)
    order = []
    if root:
        root.d = 0
        order = [root]
        for x in order:
            for k in x.kids:
                k.d = x.d + 1
                order.append(k)
    for x in reversed(order):
        x.nk = sum(1 for k in x.kids if counted(k))
        x.team = sum((1 if counted(k) else 0) + k.team for k in x.kids)
        x.below = 1 + max(k.below for k in x.kids) if x.kids else 0
    for p in ps:
        p.kids.sort(key=lambda k: (-k.rk, -k.team, k.n))
    for p in ps:
        p.ly = p.lay or (p.d + 1 if p.d >= 0 else -1)
    C = [p for p in ps if counted(p) and p.d >= 0]
    return F, ps, by, root, C, senior


def build_report(db: Session, allowed: Optional[Set[int]], function_ids: Optional[Set[int]] = None,
                 include_flagged: bool = True, username: str = "", units=None) -> dict:
    """allowed: functions the user may see (None = all). function_ids: the selection (None = everything allowed)."""
    scope = set(function_ids) if function_ids else allowed
    function_id = next(iter(scope)) if scope and len(scope) == 1 else None
    data = org_rows(db, scope, units)
    senior = int(get_setting(db, "senior_rank") or 68)
    ph = float(get_setting(db, "productive_hours") or 7.5)
    F, ps, by, root, C, senior = _build(data, include_flagged, senior)
    fids = data["function_ids"]
    fn_obj = {f.id: f for f in db.query(models.Function)}
    group = get_setting(db, "group_label") or "COSO"
    all_ids = set(fn_obj)
    if not scope or scope >= all_ids:
        scope_name = f"{group}: Operations Services"
    elif function_id:
        scope_name = fn_obj[function_id].name
    else:
        names = sorted(fn_obj[i].name for i in scope if i in fn_obj)
        scope_name = ", ".join(names) if len(names) <= 3 else f"{len(names)} functions"
    MGR = [p for p in C if p.nk > 0]
    non_root = [m for m in MGR if m is not root]
    total = len(C)
    fte = sum(1 for p in C if p.fte)
    narrow = [m for m in non_root if m.nk <= 2]
    wide = [m for m in non_root if m.nk > 15]
    cross = [p for p in C if p.m >= 0 and ps[p.m] is not root and ps[p.m].f != p.f]
    biggest = max(MGR, key=lambda m: m.nk) if MGR else root
    senior_no_team = [p for p in C if p.rk >= senior and not p.nk]
    pass_through = [m for m in non_root if m.nk == 1 and any(k.kids for k in m.kids if not k.ctx)]
    idle_tl = [p for p in C if re.search(r"team lead|supervisor", p.pos or "", re.I) and not p.nk]
    inv = [p for p in C if p.m >= 0 and ps[p.m] is not root and p.rk > 0 and ps[p.m].rk > 0 and p.rk > ps[p.m].rk]
    same = [p for p in C if p.m >= 0 and ps[p.m] is not root and p.rk > 0 and p.rk == ps[p.m].rk]

    fstats = []
    for f, name in enumerate(F):
        mem = [p for p in C if p.f == f]
        if not mem:
            continue
        ms = [p for p in mem if p.nk]
        heads = sorted([k for k in (root.kids if root else []) if k.f == f], key=lambda k: -k.team)
        fstats.append({"f": f, "id": fids[f], "name": name, "hc": len(mem), "fte": sum(1 for p in mem if p.fte),
                       "ftc": sum(1 for p in mem if not p.fte), "mg": len(ms),
                       "span": (sum(m.nk for m in ms) / len(ms)) if ms else 0, "layers": max(p.ly for p in mem),   # the deepest layer
                       "narrow": sum(1 for m in ms if m.nk <= 2 and m is not root),
                       "head": heads[0].n if heads else "", "head_obj": heads[0] if heads else None})
    fstats.sort(key=lambda s: -s["hc"])
    max_l = max([p.ly for p in C] or [1]) - 1   # columns L2 .. L(max_l + 1)
    bins = [("1", 1, 1), ("2", 2, 2), ("3-5", 3, 5), ("6-10", 6, 10), ("11-15", 11, 15), ("16-30", 16, 30), ("31+", 31, 10 ** 9)]
    span_bins = [(b[0], sum(1 for m in non_root if b[1] <= m.nk <= b[2])) for b in bins]
    layers = [{"name": s["name"], "values": [sum(1 for p in C if p.f == s["f"] and p.ly == l + 1) for l in range(1, max_l + 1)]} for s in fstats]
    grades = {}
    for p in C:
        if p.fte and p.rk > 0:
            g = grades.setdefault(p.g, {"grade": p.g, "rk": p.rk, "m": 0, "f": 0})
            if p.sex == "m":
                g["m"] += 1
            elif p.sex == "f":
                g["f"] += 1
    grade_rows = sorted(grades.values(), key=lambda g: -g["rk"])

    def rows(lst, fn, n=12):
        return [fn(p) for p in lst[:n]]

    Fn = lambda p: F[p.f] if 0 <= p.f < len(F) else ""
    opps = [
        {"k": "Delayer", "t": "Single-report managers", "n": len(pass_through), "u": "managers",
         "d": "Each of these managers has exactly one direct report, who in turn manages a team. The extra layer adds an approval step without widening the span of control.",
         "a": "Assess whether the two roles can be combined, or the team re-aligned to the next manager up.",
         "cols": ["Manager", "Position", "Grade", "Function", "Only direct report"], "rows": rows(pass_through, lambda p: [p.n, p.pos, p.g, Fn(p), (f"{p.kids[0].n} ({p.kids[0].pos}, {p.kids[0].g})" if p.kids else "")])},
        {"k": "Delayer", "t": "Narrow spans of control", "n": len(narrow), "u": "managers",
         "d": "These managers supervise one or two direct reports. Narrow spans add supervisory cost and lengthen decision chains.",
         "a": "Consolidate adjacent small teams under a single lead, beginning with managers in the same function.",
         "cols": ["Manager", "Position", "Grade", "Function", "Direct reports"], "rows": rows(sorted(narrow, key=lambda p: -p.rk), lambda p: [p.n, p.pos, p.g, Fn(p), p.nk])},
        {"k": "Rebalance", "t": "Spans too wide for effective supervision", "n": len(wide), "u": "managers",
         "d": f"Each manager has more than 15 direct reports; the largest span is {biggest.nk if biggest else 0} under {biggest.n if biggest else ''}.",
         "a": "Introduce team leads between the manager and the team, using existing team lead positions first.",
         "cols": ["Manager", "Position", "Grade", "Function", "Direct reports", "FTC share"], "rows": rows(sorted(wide, key=lambda p: -p.nk), lambda p: [p.n, p.pos, p.g, Fn(p), p.nk, f"{round(sum(1 for k in p.kids if not k.fte) / max(1, len(p.kids)) * 100)}%"])},
        {"k": "Rebalance", "t": "Team leads and supervisors without direct reports", "n": len(idle_tl), "u": "employees",
         "d": "The position title indicates a team lead or supervisory role, but no one reports to them in the master data.",
         "a": "Map employees to these roles, which also relieves wide spans at no additional cost, or correct the position title.",
         "cols": ["Name", "Position", "Grade", "Function", "Manager", "Manager's position", "Manager's grade"], "rows": rows(sorted(idle_tl, key=lambda p: -p.rk), lambda p: [p.n, p.pos, p.g, Fn(p), ps[p.m].n if p.m >= 0 else "", ps[p.m].pos if p.m >= 0 else "", ps[p.m].g if p.m >= 0 else ""])},
        {"k": "Grade", "t": "Employees graded above their manager", "n": len(inv), "u": "employees",
         "d": "The employee holds a higher grade than their line manager. This usually indicates a tagging error or an outdated reporting line.",
         "a": "Confirm the reporting line with the function POC and correct the master data or the grade.",
         "cols": ["Name", "Position", "Grade", "Manager", "Manager's position", "Manager's grade"], "rows": rows(sorted(inv, key=lambda p: -p.rk), lambda p: [p.n, p.pos, p.g, ps[p.m].n, ps[p.m].pos, ps[p.m].g])},
        {"k": "Grade", "t": "Employees on the same grade as their manager", "n": len(same), "u": "employees",
         "d": "This can be intentional, but when widespread it compresses the grade structure.",
         "a": "Review whether these are peer roles placed under a lead, and whether the lead role is graded correctly.",
         "cols": ["Name", "Position", "Grade", "Manager", "Manager's position", "Manager's grade", "Function"], "rows": rows(sorted(same, key=lambda p: -p.rk), lambda p: [p.n, p.pos, p.g, ps[p.m].n, ps[p.m].pos, ps[p.m].g, Fn(p)])},
        {"k": "Senior roles", "t": "Senior grades without direct reports", "n": len(senior_no_team), "u": "employees",
         "d": "Some are specialist or advisory roles; others may have reporting lines missing from the master data.",
         "a": "Ask function POCs to confirm each as a specialist role or to correct the reporting line.",
         "cols": ["Name", "Position", "Grade", "Function"], "rows": rows(sorted(senior_no_team, key=lambda p: -p.rk), lambda p: [p.n, p.pos, p.g, Fn(p)])},
        {"k": "Tagging", "t": "Reporting lines across functions", "n": len(cross), "u": "employees",
         "d": "These employees report to a manager tagged to another function, which distorts the employee count by function.",
         "a": "Function POCs to confirm the correct function during data capture.",
         "cols": ["Name", "Position", "Grade", "Function", "Manager", "Manager's position", "Manager's function"], "rows": rows(cross, lambda p: [p.n, p.pos, p.g, Fn(p), ps[p.m].n, ps[p.m].pos, Fn(ps[p.m])])},
    ]
    opps = [o for o in opps if o["n"]]

    # structure snapshot for the organogram slide/page: top person + direct reports
    top = root
    if function_id:
        fs = next((s for s in fstats if s["id"] == function_id), None)
        top = fs["head_obj"] if fs and fs["head_obj"] else root
    structure = None
    if top:
        structure = {"name": top.n, "pos": top.pos, "grade": top.g, "nk": top.nk, "team": top.team,
                     "kids": [{"name": k.n, "pos": k.pos, "grade": k.g, "nk": k.nk, "team": k.team, "fte": k.fte}
                              for k in top.kids if not k.ctx][:24],
                     "more": max(0, sum(1 for k in top.kids if not k.ctx) - 24)}

    # recorded work (data capture)
    from .logic import function_summary
    from .routers.dashboard import work_summary
    in_scope = {s["id"] for s in fstats}
    capture = [{"name": r["name"], "status": r["status"], "hc": r["headcount"], "with_work": r["staff_with_work"],
                "activities": r["activities"], "hours": r["daily_hours"], "fte": r["fte_equivalent"],
                "service_hours": r["service_hours"], "support_hours": r["support_hours"]}
               for r in function_summary(db) if r["id"] in in_scope and not (units and r["id"] in units)]   # whole-function progress is left out when limited to units
    work = work_summary(db, in_scope, include_flagged, units=units)
    # geographical spread
    regs = {}
    for p in C:
        r = regs.setdefault(p.rg or "Region not set", {"region": p.rg or "Region not set", "total": 0, "fte": 0, "ftc": 0,
                                                        "Service": 0, "Support": 0, "none": 0})
        r["total"] += 1
        r["fte" if p.fte else "ftc"] += 1
        r[p.st if p.st in ("Service", "Support") else "none"] += 1
    regions = sorted(regs.values(), key=lambda r: (r["region"] == "Region not set", -r["total"]))
    detail = None
    if function_id and function_id in fn_obj:
        w = employee_work(db, fn_obj[function_id])
        detail = {"employees": w["employees"]}

    return {
        "title": scope_name, "generated": datetime.now().strftime("%d %b %Y, %H:%M"), "by": username,
        "include_flagged": include_flagged, "productive_hours": ph, "root": root.n if root else "",
        "kpi": {"total": total, "fte": fte, "ftc": total - fte, "managers": len(MGR), "layers": max_l + 1, "functions": len(fstats),
                "avg_span": round(sum(m.nk for m in non_root) / len(non_root)) if non_root else 0,
                "narrow": len(narrow), "wide": len(wide), "cross": len(cross), "senior_no_team": len(senior_no_team),
                "biggest_n": biggest.nk if biggest else 0, "biggest_name": biggest.n if biggest else "",
                "biggest_fn": Fn(biggest) if biggest else ""},
        "fstats": [{k: v for k, v in s.items() if k != "head_obj"} for s in fstats],
        "span_bins": span_bins, "layers": layers, "max_layer": max_l, "grades": grade_rows,
        "opps": opps, "structure": structure, "capture": capture, "detail": detail, "function_id": function_id,
        "work": work, "regions": regions, "group_label": group, "show_time": bool(get_setting(db, "show_time")),
    }
