import React, { useEffect, useMemo, useState } from 'react'
import { api, download } from '../api.js'
import { buildOrg, fmt, pct, scopeData, TYPE_COL } from '../org.js'
import { L } from '../prefs.js'
import { Icon, Kpi, Modal, PeopleModal, Ring, Split, Steps, types } from '../ui.jsx'
import { Classic, vacMapOf } from './Organogram.jsx'
import { ActsSection } from './Dashboard.jsx'
import { BenchFramework } from './Benchmark.jsx'

// The HR Dashboard: the restructure, As Is (the HR master file, which the admin can correct or replace) against To Be
// (the portal today). People added in the portal and resigned people are already reflected on both sides, so only the
// restructuring shows: layers, spans, functions, single-report managers, taggings and headcount saved.
const n1 = v => v === null || v === undefined ? '–' : Number(v).toLocaleString('en-US', { maximumFractionDigits: 1 })
const CHANGES = [
  ['line', 'Reporting line changes', 'mv'], ['function', 'Function changes', 'mv'], ['span', 'Span of control changes', 'mv'],
  ['layer', 'Layer changes', 'mv'], ['grade', 'Grade changes', 'mv'], ['title', 'Title changes', 'mv'],
  ['saved', 'Headcount saved', 'gone'], ['resigned', 'Resigned', 'gone'], ['removed', 'In As Is, not in the portal', 'gone'],
  ['added', 'Added (not in the As Is)', 'new'], ['tbh', 'Positions to be hired', 'new'],
]
const COLS = {   // the columns of each change list: [heading, field]
  line: [['As Is manager', 'frm'], ['To Be manager', 'to']], function: [['From', 'frm'], ['To', 'to']], span: [['As Is direct reports', 'frm'], ['To Be', 'to']],
  layer: [['As Is', 'frm'], ['To Be', 'to']], grade: [['From', 'frm'], ['To', 'to']], title: [['As Is title', 'frm'], ['To Be title', 'to']],
  saved: [['Reason', 'reason'], ['Date', 'date'], ['Direct reports (As Is)', 'reports']], resigned: [['Resigned on', 'date']],
  removed: [['As Is manager', 'frm']], added: [['Reports to', 'to'], ['Why', 'why']], tbh: [['Vacancy', 'kind'], ['Type', 'emp_type'], ['Open', 'count'], ['Reports to', 'to']],
  single: [['As Is direct reports', 'frm'], ['To Be direct reports', 'to']], fn_added: [['As Is people', 'frm'], ['To Be people', 'to']], fn_removed: [['As Is people', 'frm'], ['To Be people', 'to']],
  tagging: [['As Is', 'frm'], ['To Be', 'to']], bm_room: [['Level', 'level'], ['Max grade', 'max']], bm_at: [['Level', 'level'], ['Max grade', 'max']], bm_above: [['Level', 'level'], ['Max grade', 'max']],
  hiring_removed: [['Vacancy', 'kind'], ['Positions', 'count'], ['Reason', 'reason'], ['Removed on', 'date']],
  delayering: [['Layer', 'lay'], ['Direct reports (Current)', 'frm']], units: [['Unit', 'unit'], ['Current function', 'frm'], ['Proposed function', 'to'], ['Staff', 'staff']],
  exit: [['Reason', 'reason'], ['Date', 'date']], pr: [['Replacement position', 'to'], ['Replacement grade', 'to_grade']], trade: [],
  saved_all: [['Saved as', 'what'], ['Headcount', 'n'], ['Reason', 'reason'], ['Date', 'date']],
}

function ChangeList({ k, title, rows, onPerson, onClose }) {
  const [q, setQ] = useState('')
  const ql = q.trim().toLowerCase()
  const sorted = rows.some(r => r.rank !== undefined) ? [...rows].sort((a, b) => (b.rank ?? -9) - (a.rank ?? -9)) : rows   // the highest grade first
  const list = sorted.filter(r => !ql || (r.name + ' ' + r.code + ' ' + r.function + ' ' + (r.frm || '') + ' ' + (r.to || '')).toLowerCase().includes(ql))
  const cols = COLS[k] || []
  return <Modal wide title={title} sub={k === 'units' ? `${fmt(rows.length)} units` : `${fmt(rows.length)} ${k === 'tbh' ? 'positions' : 'staff'}`} onClose={onClose}>
    <div className="kvline" style={{ marginBottom: 8 }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} /></div>
    <div className="tw scroll" style={{ maxHeight: 480 }}><table>
      <thead><tr><th>{k === 'tbh' ? 'Position' : k === 'saved_all' ? 'Staff / position' : 'Staff'}</th><th>Grade</th><th>Function</th>{cols.map(c => <th key={c[1]}>{c[0]}</th>)}</tr></thead>
      <tbody>{list.slice(0, 1000).map((r, i) => <tr key={r.code || i} className={r.code && onPerson ? 'click' : ''} onClick={r.code && onPerson ? () => onPerson(r) : undefined} title={r.code ? 'Show in the organograms' : ''}>
        <td><b>{r.name}</b>{r.code && <div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div>}</td><td>{r.grade}</td><td>{r.function}</td>
        {cols.map(c => <td key={c[1]} className={c[1] === 'to' && k === 'grade' ? (r.up ? 'ch-up' : 'ch-dn') : ''}>{String(r[c[1]] ?? '')}</td>)}</tr>)}
        {!list.length && <tr><td colSpan={3 + cols.length} className="formula">None.</td></tr>}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={() => {
      const csv = [[k === 'tbh' ? 'Position' : 'Employee', 'Code', 'Grade', 'Function', ...cols.map(c => c[0])], ...list.map(r => [r.name, r.code, r.grade, r.function, ...cols.map(c => r[c[1]] ?? '')])]
        .map(x => x.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n')
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' })); a.download = title + '.csv'; a.click()
    }}>Download List</button></div>
  </Modal>
}

// ---------------------------------------------------------------- vacant / to be hired positions, Replacement and New apart
function VacList({ tbh, onClose }) {
  const tabs = [['replacement', L('vac.repl'), tbh.filter(v => v.vk === 'replacement')], ['new', L('vac.new'), tbh.filter(v => v.vk !== 'replacement')]]
  const [tab, setTab] = useState(tabs[0][2].length || !tabs[1][2].length ? 'replacement' : 'new')
  const [q, setQ] = useState('')
  const cur = tabs.find(t => t[0] === tab)
  const ql = q.trim().toLowerCase()
  const rows = cur[2].filter(r => !ql || [r.name, r.function, r.to, r.unit, r.grade].join(' ').toLowerCase().includes(ql))
  const n = rs => rs.reduce((a, r) => a + (r.count || 0), 0)
  const rem = tab === 'removed'
  return <Modal wide title="Vacant / To Be Hired Positions" sub="To Be · not counted as employees" onClose={onClose}>
    <div className="tabs" style={{ marginBottom: 10 }}>{tabs.map(([k, t, rs]) => <button key={k} aria-current={tab === k} onClick={() => setTab(k)}>{t} ({fmt(n(rs)) === '-' ? 0 : fmt(n(rs))})</button>)}</div>
    <div className="kvline" style={{ marginBottom: 8 }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} /></div>
    <div className="tw scroll" style={{ maxHeight: 440 }}><table>
      <thead><tr><th>Position</th><th>Vacancy</th><th>Function</th><th>Reports To</th><th>Type</th><th>Grade</th><th className="num">{rem ? 'Positions' : 'Open'}</th><th>{rem ? 'Reason' : 'Note'}</th></tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i} className={rem ? 'vac-done' : ''}><td><b>{r.name}</b>{r.unit && <div className="formula">{r.unit}</div>}</td>
        <td><span className={'vk-pill ' + (r.vk === 'replacement' ? 'vk-r' : 'vk-n')}>{L(r.vk === 'replacement' ? 'vac.repl' : 'vac.new')}</span></td>
        <td>{r.function}</td><td>{r.to || 'Function head'}</td><td>{r.emp_type}</td><td>{r.grade || '-'}</td><td className="num">{fmt(r.count)}</td>
        <td className="formula">{rem ? [r.reason, r.date].filter(Boolean).join(' · ') : r.note || ''}</td></tr>)}
        {!rows.length && <tr><td colSpan={8} className="formula">None.</td></tr>}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={() => {
      const csv = [['Position', 'Vacancy', 'Function', 'Reports To', 'Type', 'Grade', rem ? 'Positions' : 'Open', rem ? 'Reason' : 'Note'], ...rows.map(r => [r.name, L(r.vk === 'replacement' ? 'vac.repl' : 'vac.new'), r.function, r.to, r.emp_type, r.grade, r.count, rem ? [r.reason, r.date].filter(Boolean).join(' · ') : r.note || ''])]
        .map(x => x.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n')
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' })); a.download = cur[1] + ' positions.csv'; a.click()
    }}>Download List</button></div>
  </Modal>
}

// ---------------------------------------------------------------- the As Is data: corrections and a new HR file
function AsIsData({ notify, canEdit, onChanged, onClose }) {
  const [d, setD] = useState(null)
  const [q, setQ] = useState('')
  const [show, setShow] = useState('')
  const [ed, setEd] = useState(null)   // the row being edited / added
  const [up, setUp] = useState(null)   // {file, rep}
  const load = () => api(`/api/chro/asis?q=${encodeURIComponent(q)}&show=${show}`).then(setD).catch(e => notify(e.message, true))
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [q, show])
  const save = async () => {
    try {
      const body = { name: ed.name, grade_raw: ed.grade_raw, position: ed.position, function: ed.function, manager_code: ed.manager_code, emp_type: ed.emp_type, kind: ed.kind, unit: ed.unit, note: ed.note }
      if (ed.isNew) await api('/api/chro/asis', { method: 'POST', body: { code: ed.code, ...body } })
      else await api('/api/chro/asis/' + encodeURIComponent(ed.code), { method: 'PATCH', body })
      notify(ed.isNew ? 'Added to the As Is.' : 'As Is corrected.'); setEd(null); load(); onChanged()
    } catch (e) { notify(e.message, true) }
  }
  const remove = async r => {
    if (!window.confirm(`Remove ${r.name} from the As Is? Their team in the As Is will report to their manager.`)) return
    try { await api('/api/chro/asis/' + encodeURIComponent(r.code), { method: 'DELETE' }); notify('Removed from the As Is.'); setEd(null); load(); onChanged() } catch (e) { notify(e.message, true) }
  }
  const upload = async (file, dry) => {
    const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false')
    try {
      const rep = await api('/api/chro/asis/upload', { method: 'POST', form: fd })
      if (dry) setUp({ file, rep }); else { setUp(null); notify(`As Is replaced: ${fmt(rep.rows)} employees from ${file.name}.`); load(); onChanged() }
    } catch (e) { notify(e.message, true) }
  }
  const reset = async () => {
    if (!window.confirm('Rebuild the As Is from the database (the HR master file imported in Admin)? An uploaded HR file stops being used and every correction made here is lost.')) return
    try { const r = await api('/api/chro/asis/reset', { method: 'POST' }); notify(`As Is rebuilt: ${fmt(r.rows)} employees.`); load(); onChanged() } catch (e) { notify(e.message, true) }
  }
  const m = d?.meta || {}
  return <Modal wide title="As Is Data" sub={d ? `${m.file || 'HR master file'} · ${fmt(d.total)} employees${d.edited ? ` · ${fmt(d.edited)} corrected or added` : ''}${m.loaded_at ? ' · loaded ' + m.loaded_at : ''}` : ''} onClose={onClose}>
    <p className="formula" style={{ marginTop: 0 }}>The As Is is used only on this dashboard. {m.source === 'upload' ? 'It comes from an HR file uploaded for this dashboard.' : 'It comes from the database: each employee as in the HR master file imported in Admin (HR manager, function, grade and position), and it follows a new import there.'} Correcting it, or replacing it with a new HR file, does not change anything else in the portal.</p>
    {canEdit && <div className="row-actions" style={{ gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
      <label className="btn pri" style={{ cursor: 'pointer' }}>Upload New HR File<input type="file" accept=".xlsx" hidden onChange={e => { const f = e.target.files[0]; e.target.value = ''; if (f) upload(f, true) }} /></label>
      <button className="btn" onClick={() => setEd({ isNew: true, code: '', name: '', grade_raw: '', position: '', function: '', manager_code: '', emp_type: 'FTE', kind: '', unit: '', note: '' })}>Add Missing Employee</button>
      <button className="btn" onClick={() => download('/api/chro/asis/export', 'As Is.xlsx').catch(e => notify(e.message, true))}>Export As Is (Excel)</button>
      <button className="btn" onClick={reset}>Use Database (rebuild)</button></div>}
    {up && <div className="ch-card" style={{ marginBottom: 10, borderColor: 'var(--amber)' }}>
      <b>{up.file.name}</b>: {fmt(up.rep.rows)} employees. {fmt(up.rep.new_vs_current_as_is)} not in the current As Is, {fmt(up.rep.dropped_vs_current_as_is)} of the current As Is not in the file; {fmt(up.rep.not_in_portal)} not in the portal.
      <div className="row-actions" style={{ marginTop: 8, gap: 8 }}><button className="btn pri" onClick={() => upload(up.file, false)}>Replace the As Is</button><button className="btn" onClick={() => setUp(null)}>Cancel</button></div></div>}
    {ed && <div className="ch-card" style={{ marginBottom: 10 }}><h3>{ed.isNew ? 'Add a missing employee' : `Correct ${ed.name}`}</h3>
      <div className="ch-form">
        <label className="fld"><span className="fl">Employee code</span><input className="inp" value={ed.code} disabled={!ed.isNew} onChange={e => setEd({ ...ed, code: e.target.value })} placeholder="A portal code fills the rest" /></label>
        <label className="fld"><span className="fl">Name</span><input className="inp" value={ed.name} onChange={e => setEd({ ...ed, name: e.target.value })} /></label>
        <label className="fld"><span className="fl">Grade (as in the HR file)</span><input className="inp" value={ed.grade_raw} onChange={e => setEd({ ...ed, grade_raw: e.target.value })} placeholder="e.g. 068-SM I" /></label>
        <label className="fld"><span className="fl">Position</span><input className="inp" value={ed.position} onChange={e => setEd({ ...ed, position: e.target.value })} /></label>
        <label className="fld"><span className="fl">Function</span><input className="inp" list="ch-fns" value={ed.function} onChange={e => setEd({ ...ed, function: e.target.value })} /></label>
        <label className="fld"><span className="fl">Manager code (N-1)</span><input className="inp" value={ed.manager_code} onChange={e => setEd({ ...ed, manager_code: e.target.value })} /></label>
        <label className="fld"><span className="fl">Type</span><select className="inp" value={ed.kind || ed.emp_type} onChange={e => { const v = e.target.value; setEd({ ...ed, emp_type: v === 'FTC' || v === 'dw' ? 'FTC' : 'FTE', kind: v === 'dc' || v === 'dw' ? v : '' }) }}>
          <option value="FTE">FTE</option><option value="dc">{L('dash.dc')}</option><option value="FTC">FTC</option><option value="dw">{L('dash.dw')}</option></select></label>
        <label className="fld"><span className="fl">Unit</span><input className="inp" value={ed.unit} onChange={e => setEd({ ...ed, unit: e.target.value })} /></label>
        <label className="fld" style={{ gridColumn: 'span 3' }}><span className="fl">Note</span><input className="inp" value={ed.note} onChange={e => setEd({ ...ed, note: e.target.value })} placeholder="Why it was corrected" /></label>
      </div>
      <datalist id="ch-fns">{(d?.functions || []).map(f => <option key={f} value={f} />)}</datalist>
      <div className="row-actions" style={{ marginTop: 10, justifyContent: 'space-between' }}>
        <span>{!ed.isNew && <button className="linkbtn" onClick={() => remove(ed)}>Remove from As Is</button>}</span>
        <span style={{ display: 'flex', gap: 8 }}><button className="btn" onClick={() => setEd(null)}>Cancel</button><button className="btn pri" onClick={save}>Save</button></span></div></div>}
    <div className="kvline" style={{ marginBottom: 8 }}>
      <input className="inp" placeholder="Search by name, code or position" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} />
      <select className="inp" value={show} onChange={e => setShow(e.target.value)} style={{ maxWidth: 200 }}><option value="">Everyone</option><option value="edited">Corrected</option><option value="added">Added</option></select></div>
    <div className="tw scroll" style={{ maxHeight: 400 }}><table>
      <thead><tr><th>Employee</th><th>Grade</th><th>Function</th><th>Manager (As Is)</th><th>Source</th></tr></thead>
      <tbody>{(d?.rows || []).map(r => <tr key={r.code} className={canEdit ? 'click' : ''} onClick={canEdit ? () => setEd({ ...r }) : undefined} title={canEdit ? 'Correct' : ''}>
        <td><b>{r.name}</b><div className="formula">{[r.position, r.code].filter(Boolean).join(' · ')}</div></td><td>{r.grade}</td><td>{r.function}</td>
        <td>{r.manager_name || r.manager_code || '–'}</td><td>{r.source === 'file' ? 'HR file' : r.source === 'added' ? <span className="pill p-ok">Added</span> : <span className="pill p-warn" title={r.note}>Corrected</span>}</td></tr>)}
        {d && d.rows.length >= 400 && <tr><td colSpan={5} className="formula">The first 400 are shown. Search to narrow down.</td></tr>}</tbody></table></div>
  </Modal>
}

// ---------------------------------------------------------------- the page
const nz = v => { const x = fmt(v || 0); return x === '-' ? '0' : x }
const delta = (a, b) => { const d = (b || 0) - (a || 0); return d === 0 ? '' : (d > 0 ? '+' : '−') + nz(Math.abs(d)) }

// the proposed figure under the current one (Proposed State): the value and the change
function Pp({ a, b, sm, full }) {
  const d = (b || 0) - (a || 0)
  return <span className={'hxk-pp' + (sm ? ' sm' : '')}><i>{full ? L('hr.pro') : 'Proposed'}</i><b>{nz(b)}</b>{d !== 0 && <em className={d < 0 ? 'dn' : 'up'}>{d < 0 ? '▼' : '▲'} {nz(Math.abs(d))}</em>}</span>
}

const REPL_TABS = [['normal', 'Normal Replacement'], ['special', 'Special Replacement']]
function ReplList({ repl, initial, onClose }) {
  const [tab, setTab] = useState(initial || 'normal')
  const rows = repl[tab] || []
  const staffCol = tab !== 'normal'
  return <Modal wide title={L('hr.repl')} onClose={onClose}>
    <div className="tabs" style={{ marginBottom: 10 }}>{REPL_TABS.map(([k, t]) => <button key={k} aria-current={tab === k} onClick={() => setTab(k)}>{t} ({nz(repl['n_' + k])})</button>)}</div>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr>{staffCol && <><th>Staff</th><th>Staff Grade</th></>}<th>Position</th><th>Grade</th><th>Function</th><th>Reports To</th><th>Type</th><th className="num">Positions</th></tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i}>{staffCol && <><td><b>{r.staff}</b>{r.pr && <span className="pr-tag">PR</span>}<div className="formula">{[r.staff_position, r.staff_code].filter(Boolean).join(' · ')}</div></td><td>{r.staff_grade}</td></>}
        <td><b>{r.name}</b></td><td>{r.grade || '-'}</td><td>{r.function}</td><td>{r.to || '-'}</td><td>{r.emp_type}</td><td className="num">{nz(r.count)}</td></tr>)}
        {!rows.length && <tr><td colSpan={staffCol ? 8 : 6} className="formula">None.</td></tr>}</tbody></table></div>
  </Modal>
}

function NewList({ rows, onClose }) {
  return <Modal wide title={L('hr.new')} onClose={onClose}>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr><th>Position</th><th>Grade</th><th>Function</th><th>Reports To</th><th>Type</th><th className="num">Positions</th><th>Note</th></tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i}><td><b>{r.name}</b>{r.unit && <div className="formula">{r.unit}</div>}</td><td>{r.grade || '-'}</td><td>{r.function}</td><td>{r.to || '-'}</td><td>{r.emp_type}</td><td className="num">{nz(r.count)}</td><td className="formula">{r.note}</td></tr>)}
        {!rows.length && <tr><td colSpan={7} className="formula">None.</td></tr>}</tbody></table></div>
  </Modal>
}

// Unit Transition Opportunities: the admin picks the units that count
function UnitList({ rows, canEdit, notify, onSaved, onClose }) {
  const [on, setOn] = useState(() => new Set(rows.filter(r => r.selected).map(r => r.code)))
  const save = async () => { try { await api('/api/chro/units', { method: 'PUT', body: { codes: [...on] } }); notify('Saved.'); onSaved() } catch (e) { notify(e.message, true) } }
  return <Modal wide title="Unit Transition Opportunities" sub={`${nz(rows.filter(r => on.has(r.code)).length)} units · ${nz(rows.filter(r => on.has(r.code)).reduce((a, r) => a + r.staff, 0))} staff`} onClose={onClose}>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr>{canEdit && <th></th>}<th>Unit Head</th><th>Unit</th><th>Current Function</th><th>Proposed Function</th><th className="num">Staff</th></tr></thead>
      <tbody>{rows.map(r => <tr key={r.code}>{canEdit && <td><input type="checkbox" checked={on.has(r.code)} onChange={e => setOn(s => { const n = new Set(s); e.target.checked ? n.add(r.code) : n.delete(r.code); return n })} /></td>}
        <td><b>{r.name}</b><div className="formula">{r.position}</div></td><td>{r.unit}</td><td>{r.frm}</td><td>{r.to}</td><td className="num">{nz(r.staff)}</td></tr>)}
        {!rows.length && <tr><td colSpan={canEdit ? 6 : 5} className="formula">None.</td></tr>}</tbody></table></div>
    {canEdit && rows.length > 0 && <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn pri" onClick={save}>Save</button></div>}
  </Modal>
}

// layers by function for one state (as on the dashboard, without the span)
function LayersTable({ o, people }) {
  const C = o.C, fs = [...o.fstats].sort((a, b) => a.name.localeCompare(b.name))
  const ls = C.filter(p => p.ly > 0).map(p => p.ly), hi = Math.max(1, ...ls)
  const LYR = []; for (let l = 1; l <= hi; l++) LYR.push(l)
  const mgr = ps => ps.filter(p => p.nk > 0 && p !== o.ROOT).length
  return <div className="panel" style={{ padding: '10px 14px' }}><div className="tw"><table className="heat">
    <thead><tr><th>Function</th>{LYR.map(l => <th key={l} className="num">L{l}</th>)}<th className="num">Staff</th><th className="num">Layers</th><th className="num">Line Managers</th></tr></thead>
    <tbody>{fs.length > 1 && <tr className="tot top"><td>Total</td>{LYR.map(l => { const r = C.filter(p => p.ly === l); return <td key={l} className="num">{r.length ? <button className="cellbtn" onClick={() => people(`Layer ${l}`, r)}>{nz(r.length)}</button> : ''}</td> })}
      <td className="num">{nz(C.length)}</td><td className="num">{nz(hi)}</td><td className="num">{nz(mgr(C))}</td></tr>}
      {fs.map(s => { const ps = C.filter(p => p.f === s.f); const row = LYR.map(l => ps.filter(p => p.ly === l)); const mx = Math.max(1, ...row.map(r => r.length))
        const used = Math.max(0, ...ps.map(p => p.ly || 0)), last = row.length - 1 - [...row].reverse().findIndex(r => r.length)
        return <tr key={s.f}><td><span className="dot" style={{ background: o.FCOL[s.f] }} />{s.name}</td>
          {row.map((r, i) => <td key={i} className={'num hc' + (r.length / mx > 0.6 ? ' dk' : '')} style={{ '--h': r.length ? 0.12 + 0.78 * r.length / mx : 0 }}>
            {r.length ? <button className="cellbtn" onClick={() => people(`${s.name}: Layer ${LYR[i]}`, r)}>{nz(r.length)}</button> : i < last ? <span className="dash">-</span> : ''}</td>)}
          <td className="num"><b>{nz(ps.length)}</b></td><td className="num"><b>{nz(used)}</b></td><td className="num">{nz(mgr(ps))}</td></tr> })}</tbody></table></div></div>
}

export default function Chro({ notify, theme, user }) {
  const [fn, setFn] = useState('')
  const [d, setD] = useState(null)
  const [raw, setRaw] = useState({ asis: null, tobe: null })
  const [ver, setVer] = useState(0)
  const [state, setState] = useState('cur')        // Current State / Proposed State
  const [list, setList] = useState(null)
  const [focus, setFocus] = useState(null)
  const [asIs, setAsIs] = useState(false)
  const [plist, setPlist] = useState(null)
  const [openSec, setOpenSec] = useState(null)
  const [vacs, setVacs] = useState([])
  const [vacJd, setVacJd] = useState(null)
  const [repl, setRepl] = useState(null)
  const [newOpen, setNewOpen] = useState(false)
  const [unitsOpen, setUnitsOpen] = useState(false)
  const [fw, setFw] = useState(null)
  const canBm = !!(user && user.can_hr_bm)
  const [showMax, setShowMax] = useState(false)
  const [bench, setBench] = useState(null)
  const pro = state === 'pro'
  useEffect(() => { if (canBm && showMax && !bench) api('/api/chro/bench').then(setBench).catch(e => notify(e.message, true)) }, [showMax, ver])
  useEffect(() => { if (openSec === 'bench' && !fw) api('/api/bm/framework').then(setFw).catch(e => notify(e.message, true)) }, [openSec])
  useEffect(() => { setD(null); api('/api/chro/summary?fn=' + encodeURIComponent(fn)).then(setD).catch(e => notify(e.message, true)) }, [fn, ver])
  useEffect(() => { api('/api/chro/vacancies').then(setVacs).catch(() => setVacs([])) }, [ver])
  useEffect(() => { Promise.all([api('/api/chro/org?side=asis'), api('/api/chro/org?side=tobe')]).then(([a, b]) => setRaw({ asis: a, tobe: b })).catch(e => notify(e.message, true)) }, [ver])
  const orgOf = data => {
    if (!data) return null
    const i = fn ? data.functions.indexOf(fn) : -1
    const scoped = i >= 0 ? scopeData(data, [data.function_ids[i]]) : data
    return scoped.people.length ? buildOrg(scoped, true) : null
  }
  const oa = useMemo(() => orgOf(raw.asis), [raw.asis, fn])
  const ob = useMemo(() => orgOf(raw.tobe), [raw.tobe, fn])
  const changed = () => setVer(v => v + 1)
  const m = d?.meta || {}
  const o = pro ? ob : oa
  let fp = o && focus ? o.byId.get(focus) : null
  if (o && focus && !fp) {
    const rows = new Map([...(raw.asis?.people || []), ...(raw.tobe?.people || [])].map(r => [r[0], r]))
    let c = rows.get(focus)?.[4], n = 0
    while (c && !o.byId.get(c) && n++ < 30) c = rows.get(c)?.[4]
    fp = c ? o.byId.get(c) : null
  }
  const sel = fp || (o && o.ROOT)
  const fnList = d?.functions || []
  const one = !!(d?.scoped && fnList.length === 1)
  const vacShown = useMemo(() => vacs.filter(v => !fn || v.function === fn), [vacs, fn])
  const vacMap = useMemo(() => pro && ob ? vacMapOf(vacShown, ob, ob.ROOT) : null, [vacShown, ob, pro])
  // the figures of each state
  const figs = x => {
    if (!x) return null
    const t = {}; types().forEach(tp => { t[tp.k] = x.C.filter(tp.test).length })
    return { staff: x.C.length, t, layers: x.C.length ? Math.max(0, ...x.C.map(p => p.ly || 0)) : 0, mgrs: x.C.filter(p => p.nk > 0 && p !== x.ROOT),
      svc: x.C.filter(p => p.st === 'Service').length, sup: x.C.filter(p => p.st === 'Support').length }
  }
  const fa = useMemo(() => figs(oa), [oa]), fb = useMemo(() => figs(ob), [ob])
  const people = (title, ps, org) => setPlist({ title, people: ps, org: org || o })
  const toggleSec = k => { setOpenSec(x => x === k ? null : k); setTimeout(() => document.getElementById('hx-' + k)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60) }
  // activities: the functions on show
  const actSel = useMemo(() => { const data = raw.tobe; if (!data) return []; if (fn) { const i = data.functions.indexOf(fn); return i >= 0 ? [data.function_ids[i]] : [] } return d?.scoped ? [...new Set(data.people.filter(r => !r[12]).map(r => data.function_ids[r[3]]).filter(x => x > 0))] : [] }, [raw.tobe, fn, d?.scoped])
  const uploadHr = async file => {
    const send = dry => { const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false'); return api('/api/chro/asis/upload', { method: 'POST', form: fd }) }
    try {
      const rep = await send(true)
      if (!window.confirm(`${file.name}: ${fmt(rep.rows)} staff. Use it as the Current State?`)) return
      const r = await send(false); notify(`${file.name}: ${fmt(r.rows)} staff.`); changed()
    } catch (e) { notify(e.message, true) }
  }
  const useDb = async () => {
    if (!window.confirm('Use the database for the Current State?')) return
    try { await api('/api/chro/asis/reset', { method: 'POST' }); changed() } catch (e) { notify(e.message, true) }
  }
  const stateSeg = cls => <span className={'seg hx-state' + (cls ? ' ' + cls : '')} role="group" aria-label="State"><button type="button" aria-pressed={!pro} onClick={() => setState('cur')}>{L('hr.cur')}</button><button type="button" aria-pressed={pro} onClick={() => setState('pro')}>{L('hr.pro')}</button></span>
  const maxBtn = canBm && pro ? <button type="button" className={'btn bm-btn' + (showMax ? ' on' : '')} aria-pressed={showMax} onClick={() => setShowMax(x => !x)}><span className="bm-key" />Show Max Grade</button> : null
  const strip = o && sel ? <LayerStrip o={o} p={sel} onPick={x => setFocus(x.id)} onList={(t, ps) => people(t, ps)} /> : null
  const rp = d?.repl, op = d?.opt
  const opts = !d ? [] : [
    ['delayering', 'Organizational Delayering', nz(op.delayering.length), () => setList({ k: 'delayering', title: 'Organizational Delayering', rows: op.delayering.map(r => ({ ...r, lay: 'L6' })) })],
    ['units', 'Unit Transition Opportunities', nz(op.units_n), () => setUnitsOpen(true), `${nz(op.units_staff)} staff`],
    ['title', 'Position Title Realignment', nz(d.counts.title), () => setList({ k: 'title', title: 'Position Title Realignment' })],
    ['exit', 'Staff Exit Candidates', nz(op.exit.length), () => setList({ k: 'exit', title: 'Staff Exit Candidates', rows: op.exit })],
    ['line', 'Staff Mapping Corrections', nz(d.counts.line), () => setList({ k: 'line', title: 'Staff Mapping Corrections' })],
    ...(d.benchmark ? [['grade', 'Position Grade Realignment Opportunity', nz(d.benchmark.above), () => setList({ k: 'bm_above', title: 'Position Grade Realignment Opportunity', rows: d.benchmark.lists.above })]] : []),
    ['pr', 'Post-Retirement Staff Replacement', nz(op.pr.length), () => setList({ k: 'pr', title: 'Post-Retirement Staff Replacement', rows: op.pr })],
    ['trade', 'Trade Staff Realignment', nz(op.trade.length), () => setList({ k: 'trade', title: 'Trade Staff Realignment', rows: op.trade })],
  ]
  const SECS = [...(canBm ? [['bench', 'Position Benchmark']] : []), ['layers', 'Layers'], ['org', 'Organogram'], ['opt', 'Span of Control Optimization'], ['acts', 'Activities']]
  const typeList = types().filter(t => t.k === 'fte' || t.k === 'ftc' || (fa && fa.t[t.k]) || (fb && fb.t[t.k]))
  return <section className="view on ch-page chv hr-page hx">
    <div className="hr-top">
      <label className="hr-fn"><span>Function</span>
        <select className="inp" value={fn || (one ? fnList[0] : '')} onChange={e => { setFn(e.target.value); setFocus(null) }}>
          {!one && <option value="">{d?.scoped ? 'All my functions' : L('dash.title')}</option>}{fnList.map(f => <option key={f} value={f}>{f}</option>)}</select></label>
      <div className="hr-title"><h1>HR Dashboard</h1></div>
      <div className="hx-stw">{stateSeg('big')}</div>
      <div className="ch-tools">
        {d?.can_edit && <label className="btn" style={{ cursor: 'pointer' }}>Upload HR Master File<input type="file" accept=".xlsx" hidden onChange={e => { const f = e.target.files[0]; e.target.value = ''; if (f) uploadHr(f) }} /></label>}
        {d?.can_edit && m.source === 'upload' && <button className="btn" onClick={useDb}>Use Database</button>}
        {d?.can_edit && <button className="btn" onClick={() => setAsIs(true)}>As Is Data</button>}</div>
    </div>
    {!d || !fa ? <div className="loading">Loading…</div> : <>
      <div className="hxk">
        <div className="kpi hxk-big">
          <button type="button" className="hxk-head" onClick={() => people(L('hr.active'), o.C)}>
            <span className="kpi-ic"><Icon name="people" /></span>
            <span className="kpi-tx"><span className="kpi-l">{L('hr.active')}</span><b>{nz(fa.staff)}</b></span>
            {pro && fb && <Pp a={fa.staff} b={fb.staff} full />}</button>
          <div className="hxk-types">{typeList.map(t => <button type="button" key={t.k} className="hxk-t" onClick={() => people(t.label, o.C.filter(t.test))}>
            <Ring value={pct(fa.t[t.k], fa.staff)} color={t.k === 'ftc' ? 'var(--ftc-ink)' : t.color} />
            <span className="hxk-tx"><span className="kpi-l">{t.label}</span><b>{nz(fa.t[t.k])}</b></span>{pro && fb && <Pp a={fa.t[t.k]} b={fb.t[t.k]} sm />}</button>)}</div>
        </div>
        <div className="kpi hxk-repl">
          <span className="kpi-ic"><Icon name="list" /></span>
          <span className="kpi-tx"><span className="kpi-l">{L('hr.repl')}</span><b>{nz(rp.n_normal + rp.n_special)}</b></span>
          <span className="kpi-foot">{REPL_TABS.map(([k, t]) => <button type="button" key={k} className="kpi-common" onClick={() => setRepl(k)}><span>{t}</span><b>{nz(rp['n_' + k])}</b></button>)}</span>
        </div>
        <Kpi icon="tag" label={L('hr.new')} value={nz(rp.n_new)} onClick={() => setNewOpen(true)} />
        <Kpi icon="layers" label={L('dash.layers')} value={nz(fa.layers)} viz={<Steps n={fa.layers} />} onClick={() => toggleSec('layers')} foot={pro && fb ? <Pp a={fa.layers} b={fb.layers} /> : null} />
        <Kpi icon="managers" label="Line Managers" value={nz(fa.mgrs.length)} onClick={() => people('Line Managers', (pro && fb ? fb : fa).mgrs, pro ? ob : oa)} foot={pro && fb ? <Pp a={fa.mgrs.length} b={fb.mgrs.length} /> : null} />
        <Kpi icon="work" label="Service / Support" value={<span className="kpi-pair"><span>{nz(fa.svc)}</span><small>/</small><span>{nz(fa.sup)}</span></span>}
          onClick={() => people('Service / Support', oa.C.filter(p => p.st === 'Service' || p.st === 'Support'), oa)}
          foot={<Split parts={[{ v: fa.svc, color: TYPE_COL.Service, label: 'Service' }, { v: fa.sup, color: TYPE_COL.Support, label: 'Support' }]} />} />
      </div>

      <div className="seclaunch" role="group">{SECS.map(([k, l]) => <button key={k} type="button" aria-pressed={openSec === k} onClick={() => toggleSec(k)}>
        <i className="sl-dot" /><span><b>{l}</b></span><em className="sl-go">{openSec === k ? '–' : '+'}</em></button>)}</div>

      {openSec === 'bench' && canBm && <section id="hx-bench" className="dsec"><div className="dsec-h"><div><span className="dbul" /><h2>Position Benchmark</h2></div></div>
        {fw ? <BenchFramework inline settings={fw.settings} ladder={fw.ladder} top="EXCO" topTag="" /> : <div className="loading">Loading…</div>}
        {d.benchmark && <div className="hr-bm" style={{ marginTop: 14 }}>
          {[['room', 'Below Benchmark', 'b1'], ['at', 'At Max Benchmark', 'b2'], ['above', 'Above Max Benchmark', 'b3']].map(([x, t, tone]) =>
            <button key={x} type="button" className={'hr-k ' + tone} disabled={!d.benchmark[x]} onClick={() => setList({ k: 'bm_' + x, title: t, rows: d.benchmark.lists[x] })}><span className="hr-kt">{t}</span><b>{nz(d.benchmark[x])}</b></button>)}
        </div>}</section>}

      {openSec === 'layers' && <section id="hx-layers" className="dsec"><div className="dsec-h"><div><span className="dbul" /><h2>Layers</h2></div>{stateSeg('sm')}</div>
        {o ? <LayersTable o={o} people={(t, ps) => people(t, ps)} /> : <p className="formula">None.</p>}</section>}

      {openSec === 'org' && <section id="hx-org" className="dsec"><div className="dsec-h"><div><span className="dbul" /><h2>Organogram</h2></div>
        <span className="org-right">{stateSeg('sm')}{focus && <button className="linkbtn" onClick={() => setFocus(null)}>Back to the top</button>}
          {maxBtn}</span></div>
        {strip}
        {!o ? <p className="formula">None.</p>
          : <div className="orgchart wide"><Classic simple root={o.ROOT} top={o.ROOT} focus={fp || null} onFocus={p => setFocus(p ? p.id : null)} org={o} theme={theme} largeTeam={40} onReroot={() => {}}
              onOpenList={x => people(`${x.n}: direct reports`, x.kids.filter(o.counted))} onSelect={p => setFocus(p.id)} tools={<>{stateSeg('sm')}{maxBtn}</>} strip={strip}
              vacancies={vacMap} onVacancy={v => setVacJd(v)} bench={pro && showMax ? bench : null} /></div>}</section>}

      {openSec === 'opt' && <section id="hx-opt" className="dsec hx-opt"><div className="dsec-h"><div><span className="dbul" /><h2>Span of Control Optimization</h2></div></div>
        <div className="hx-opts">{opts.map(([k, t, v, go, sub], i) => <button type="button" key={k} className="hx-o" onClick={go}>
          <span className="hx-on">{i + 1}</span><span className="hx-ot">{t}</span><b>{v}</b>{sub && <small>{sub}</small>}</button>)}</div></section>}

      {openSec === 'acts' && <div id="hx-acts"><ActsSection sel={actSel} units={[]} includeFlagged={false} theme={theme} staff /></div>}
    </>}
    {vacJd && <Modal title={vacJd.position} sub={[L(vacJd.kind === 'replacement' ? 'vac.repl' : 'vac.new'), vacJd.emp_type, vacJd.grade, vacJd.unit].filter(Boolean).join(' · ')} onClose={() => setVacJd(null)}>
      <p className="formula" style={{ marginTop: 0 }}>Reports to {vacJd.parent_position ? `${vacJd.parent_position} (vacant)` : vacJd.manager_name || 'the function head'} · {fmt(vacJd.open)} open{vacJd.replaces_name ? ` · replaces ${vacJd.replaces_name}` : ''}{vacJd.note ? ' · ' + vacJd.note : ''}</p>
      {vacJd.jd ? <div className="jd-text">{vacJd.jd}</div> : null}</Modal>}
    {repl && d && <ReplList repl={d.repl} initial={repl} onClose={() => setRepl(null)} />}
    {newOpen && d && <NewList rows={d.repl.new} onClose={() => setNewOpen(false)} />}
    {unitsOpen && d && <UnitList rows={d.opt.units} canEdit={d.can_edit} notify={notify} onSaved={() => { setUnitsOpen(false); changed() }} onClose={() => setUnitsOpen(false)} />}
    {list && d && <ChangeList k={list.k} title={list.title} rows={list.rows || d.changes[list.k] || []} onPerson={r => { setList(null); if (r.code) { setFocus(r.code); setOpenSec('org') } }} onClose={() => setList(null)} />}
    {asIs && <AsIsData notify={notify} canEdit={d?.can_edit} onChanged={changed} onClose={() => setAsIs(false)} />}
    {plist && <PeopleModal title={plist.title} people={plist.people} F={plist.org.F} heads={plist.org.headIds} initial="people" onPerson={x => { setPlist(null); setFocus(x.id); setOpenSec('org') }} onClose={() => setPlist(null)} />}
  </section>
}

// the layer panel on top of the organogram: the person's reporting line above them, and their direct reports by
// layer below them (shaded by how many direct reports sit on each layer)
const LNAME = { 1: 'EXCO', 2: 'Function', 3: 'Department', 4: 'Unit', 5: 'Team Lead', 6: 'Teams', 7: 'FTCs' }
function LayerStrip({ o, p, onPick, onList }) {
  const chain = []; let x = p; while (x) { chain.unshift(x); x = x.m >= 0 ? o.P[x.m] : null }
  const at = {}; chain.forEach(c => { if (c.ly > 0 && !at[c.ly]) at[c.ly] = c })
  const dir = {}; p.kids.forEach(k => { if (o.counted(k) && k.ly > 0) (dir[k.ly] = dir[k.ly] || []).push(k) })
  const last = Math.max(p.ly || 1, ...Object.keys(dir).map(Number))
  const mx = Math.max(1, ...Object.values(dir).map(v => v.length))
  const ls = []; for (let l = 1; l <= last; l++) ls.push(l)
  return <div className="hr-strip">{ls.map(l => {
    const c = at[l], un = l > (p.ly || 0), dl = dir[l], h = un && dl ? 0.12 + 0.78 * dl.length / mx : 0
    return <div key={l} className={'hr-sc' + (l === p.ly ? ' on' : '') + (h > 0.6 ? ' dk' : '')} style={{ '--h': h }}>
      <div className="hr-sh"><b>L{l}</b><span>{LNAME[l] || 'Layer ' + l}</span></div>
      <div className="hr-sv">{!un ? (c ? (c === p ? <b>{c.n}</b> : <button type="button" onClick={() => onPick(c)}>{c.n}</button>) : <b>–</b>)
        : dl ? <button type="button" onClick={() => onList(`${p.n}: direct reports on Layer ${l}`, dl)}>{fmt(dl.length)} {dl.length === 1 ? 'direct' : 'directs'}</button> : <b>–</b>}</div>
    </div>
  })}</div>
}
