"""CHRO dashboard API: As Is against To Be, the As Is editor and upload, the executive PDF."""
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import chro, models
from ..db import get_db
from ..importer import code_text, grade_label, grade_rank, is_outsourced
from ..security import audit, current_user, sees_everything, view_ids

SUPER = "admin"

router = APIRouter(prefix="/api/chro")


def require_chro(user=Depends(current_user)):
    if user.username == SUPER or user.can_chro:
        return user
    raise HTTPException(403, "The CHRO dashboard is not available for this login.")


def require_chro_edit(user=Depends(require_chro)):
    """Correcting the As Is: the admin login, or an administrator with the CHRO dashboard tick."""
    if user.username == SUPER or user.role == "admin":
        return user
    raise HTTPException(403, "Only administrators can change the As Is.")


def scope_of(user, db) -> Optional[set]:
    """The functions (names) the HR Dashboard shows this login; None: every function. Administrators see all;
    other logins as set in Admin -> Users: the functions of their dashboard view (default), all, or selected ones."""
    if user.username == SUPER or user.role == "admin":
        return None
    mode = user.chro_mode or "view"
    if mode == "all" or (mode == "view" and sees_everything(user)):
        return None
    ids = set(user.chro_functions or []) if mode == "selected" else view_ids(user, db)
    names = set()
    for f in db.query(models.Function):
        if f.id in ids:
            names.add(f.name)
            if f.hr_name:
                names.add(f.hr_name)   # the As Is may carry HR's name for it
    if not names:
        raise HTTPException(403, "No functions are given to this login on the HR Dashboard. Ask an administrator.")
    return names


def _fn_ok(fn: str, scope) -> str:
    if fn and scope is not None and fn not in scope:
        raise HTTPException(403, "This function is not available to this login on the HR Dashboard.")
    return fn


@router.get("/summary")
def summary(fn: str = Query(""), user=Depends(require_chro), db: Session = Depends(get_db)):
    scope = scope_of(user, db)
    fn = _fn_ok(fn, scope)
    d = chro.compare(db, fn or None, scope)
    d["can_edit"] = user.username == SUPER or user.role == "admin"
    d["scoped"] = scope is not None
    fs = {fn} if fn else scope
    inb = lambda name: fs is None or name in fs
    if user.username == SUPER or user.can_hr_bm:   # the grade benchmark only for logins the admin gave it to
        from .. import benchmark as bm
        b = bm.compute(db)
        emps = {e.code: e for e in db.query(models.Employee)}
        lists = {"room": [], "at": [], "above": []}
        for c, p in b["people"].items():
            if p.get("tier") in lists and inb(b["functions"][p["fid"]]["name"]) and c in emps:
                e = emps[c]
                lists[p["tier"]].append({"code": c, "name": e.name, "grade": e.grade or "", "rank": e.grade_rank if e.grade_rank is not None else -1, "position": e.position or "", "function": b["functions"][p["fid"]]["name"],
                                         "max": p.get("max_name", ""), "level": bm.LEVEL_NAME.get(p.get("bench_level") or p.get("level"), "")})
        for v in lists.values():
            v.sort(key=lambda x: (-x["rank"], x["function"], x["name"]))   # the highest grade first
        d["benchmark"] = {"above": len(lists["above"]), "at": len(lists["at"]), "room": len(lists["room"]), "lists": lists,
                          "extra": sum(1 for p in b["people"].values() if p.get("beyond") and inb(b["functions"][p["fid"]]["name"]))}
    return d


@router.get("/bench")
def bench(user=Depends(require_chro), db: Session = Depends(get_db)):
    """The grade benchmark per person for the To Be organogram (Show Max Grade), for logins given it."""
    if not (user.username == SUPER or user.can_hr_bm):
        raise HTTPException(403, "The benchmark is not available for this login.")
    from .. import benchmark as bm
    scope = scope_of(user, db)
    d = bm.compute(db)
    out = {}
    for c, p in d["people"].items():
        if scope is not None and d["functions"][p["fid"]]["name"] not in scope:
            continue
        r = {"l": p["level"], "a": 1 if p["auto"] else 0, "y": p["layer"]}
        if p.get("tier"):
            r.update(t=p["tier"], mx=p["max_name"], mn=p.get("min_name", ""), g=p["gap"], bl=p["bench_level"])
        out[c] = r
    return {"people": out, "functions": {}}


class UnitPick(BaseModel):
    codes: Optional[list] = None   # the unit heads counted in Unit Transition Opportunities (None: all found)


@router.put("/units")
def unit_pick(body: UnitPick, user=Depends(require_chro_edit), db: Session = Depends(get_db)):
    from ..security import set_setting
    set_setting(db, "hr_unit_transitions", None if body.codes is None else [str(c) for c in body.codes][:2000])
    audit(db, user, "hr_unit_transitions", "all" if body.codes is None else f"{len(body.codes)} units")
    db.commit()
    return {"ok": True}


@router.get("/vacancies")
def vacancies(user=Depends(require_chro), db: Session = Depends(get_db)):
    """The vacant positions for the To Be organogram (the functions this login sees on the HR Dashboard)."""
    from .vacancies import _list
    scope = scope_of(user, db)
    fids = None if scope is None else {f.id for f in db.query(models.Function) if f.name in scope or (f.hr_name or "") in scope}
    return _list(db, fids)


@router.get("/org")
def org(side: str = Query("tobe"), user=Depends(require_chro), db: Session = Depends(get_db)):
    if side not in ("asis", "tobe"):
        raise HTTPException(400, "side is asis or tobe")
    return chro.org_payload(db, side, scope_of(user, db))


@router.get("/pdf")
def pdf(fn: str = Query(""), user=Depends(require_chro), db: Session = Depends(get_db)):
    from ..chro_pdf import build
    data = summary(fn, user, db)
    out = build(db, data, user.full_name or user.username)
    name = "CHRO Report" + (f" - {fn}" if fn else "") + f" {datetime.now():%Y-%m-%d}.pdf"
    return Response(out, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ------------------------------------------------------------------ the As Is
def _out(a: models.AsIsEmp) -> dict:
    return {"code": a.code, "name": a.name, "grade": a.grade, "grade_raw": a.grade_raw or a.grade, "position": a.position, "function": a.function,
            "manager_code": a.manager_code or "", "emp_type": a.emp_type, "kind": a.kind or "", "gender": a.gender or "", "unit": a.unit or "",
            "source": a.source, "note": a.note or "", "edited_by": a.edited_by or "", "edited_at": a.edited_at.strftime("%Y-%m-%d %H:%M") if a.edited_at else ""}


@router.get("/asis")
def asis_list(q: str = "", fn: str = "", show: str = "", user=Depends(require_chro), db: Session = Depends(get_db)):
    chro.ensure(db)
    scope = scope_of(user, db)
    fn = _fn_ok(fn, scope)
    qry = db.query(models.AsIsEmp)
    if scope is not None:
        qry = qry.filter(models.AsIsEmp.function.in_(list(scope)))
    if fn:
        qry = qry.filter(models.AsIsEmp.function == fn)
    if show in ("edited", "added"):
        qry = qry.filter(models.AsIsEmp.source == show)
    for w in q.split():
        qry = qry.filter(models.AsIsEmp.name.ilike(f"%{w}%") | models.AsIsEmp.code.ilike(f"%{w}%") | models.AsIsEmp.position.ilike(f"%{w}%"))
    rows = qry.order_by(models.AsIsEmp.function, models.AsIsEmp.name).limit(400).all()
    names = {c: n for c, n in db.query(models.AsIsEmp.code, models.AsIsEmp.name)}
    fns = sorted({f for (f,) in db.query(models.AsIsEmp.function)} | {f.name for f in db.query(models.Function)})
    if scope is not None:
        fns = [f for f in fns if f in scope]
    base = db.query(models.AsIsEmp) if scope is None else db.query(models.AsIsEmp).filter(models.AsIsEmp.function.in_(list(scope)))
    return {"meta": chro.meta(db), "rows": [dict(_out(a), manager_name=names.get(a.manager_code, "")) for a in rows], "functions": fns,
            "total": base.count(), "edited": base.filter(models.AsIsEmp.source != "file").count()}


class AsIsIn(BaseModel):
    code: Optional[str] = None
    name: Optional[str] = None
    grade_raw: Optional[str] = None
    position: Optional[str] = None
    function: Optional[str] = None
    manager_code: Optional[str] = None
    emp_type: Optional[str] = None
    kind: Optional[str] = None
    gender: Optional[str] = None
    unit: Optional[str] = None
    note: Optional[str] = None


def _apply(db, a: models.AsIsEmp, b: AsIsIn):
    d = b.model_dump(exclude_unset=True)
    if "name" in d and d["name"] is not None:
        a.name = " ".join(d["name"].split())[:200] or a.name
    if d.get("grade_raw") is not None:
        g = d["grade_raw"].strip()[:80]
        a.grade_raw, a.grade, a.grade_rank = g, grade_label(g) if g else "", grade_rank(g) if g else -1
        if is_outsourced(g):
            a.emp_type = "FTC"
    for k, n in (("position", 250), ("function", 200), ("unit", 200), ("note", 200)):
        if d.get(k) is not None:
            setattr(a, k, " ".join(d[k].split())[:n])
    if "manager_code" in d:
        m = code_text(d["manager_code"]) or None
        if m and m == a.code:
            raise HTTPException(400, "An employee cannot report to themselves.")
        if m:
            x, n = m, 0   # no loops
            while x and n < 80:
                if x == a.code:
                    raise HTTPException(400, "That would make a loop in the reporting line.")
                y = db.get(models.AsIsEmp, x)
                x, n = (y.manager_code if y else None), n + 1
        a.manager_code = m
    if d.get("emp_type") in ("FTE", "FTC"):
        a.emp_type = d["emp_type"]
    if d.get("kind") is not None and d["kind"] in ("", "dc", "dw"):
        a.kind = d["kind"]
    if d.get("gender") is not None:
        a.gender = (d["gender"] or "")[:1].lower()


@router.patch("/asis/{code}")
def asis_edit(code: str, body: AsIsIn, user=Depends(require_chro_edit), db: Session = Depends(get_db)):
    a = db.get(models.AsIsEmp, code)
    if not a:
        raise HTTPException(404, "Not in the As Is.")
    _apply(db, a, body)
    if a.source == "file":
        a.source = "edited"
    a.edited_by, a.edited_at = user.username, datetime.utcnow()
    chro.bump_edits(db)
    audit(db, user, "chro_asis_edit", f"{code} {a.name}")
    db.commit()
    return _out(a)


@router.post("/asis")
def asis_add(body: AsIsIn, user=Depends(require_chro_edit), db: Session = Depends(get_db)):
    """An employee missing from the HR file. A portal employee's details are filled in when only the code is given."""
    chro.ensure(db)
    code = code_text(body.code)
    if not code:
        raise HTTPException(400, "Employee code is required.")
    if db.get(models.AsIsEmp, code):
        raise HTTPException(409, "Already in the As Is.")
    e = db.get(models.Employee, code)
    fns = {f.id: f.name for f in db.query(models.Function)}
    a = models.AsIsEmp(code=code, name=e.name if e else code, grade=(e.grade or "") if e else "", grade_raw=(e.grade_raw or "") if e else "",
                       grade_rank=(e.grade_rank if e and e.grade_rank is not None else -1), position=(e.position or "") if e else "",
                       function=fns.get(e.function_id, "") if e else "", manager_code=(e.manager_code if e else None), emp_type=(e.emp_type if e else "FTE"),
                       kind=chro._kind(e) if e else "", gender=(e.gender or "") if e else "", unit=(e.unit_name or "") if e else "", source="added")
    db.add(a)
    db.flush()
    _apply(db, a, body)
    if not a.name:
        raise HTTPException(400, "Name is required.")
    a.edited_by, a.edited_at = user.username, datetime.utcnow()
    chro.bump_edits(db)
    audit(db, user, "chro_asis_add", f"{code} {a.name}")
    db.commit()
    return _out(a)


@router.delete("/asis/{code}")
def asis_remove(code: str, user=Depends(require_chro_edit), db: Session = Depends(get_db)):
    a = db.get(models.AsIsEmp, code)
    if not a:
        raise HTTPException(404, "Not in the As Is.")
    for k in db.query(models.AsIsEmp).filter(models.AsIsEmp.manager_code == code):   # their team reports to their manager
        k.manager_code = a.manager_code
    db.delete(a)
    chro.bump_edits(db)
    audit(db, user, "chro_asis_remove", f"{code} {a.name}")
    db.commit()
    return {"ok": True}


@router.post("/asis/upload")
async def asis_upload(file: UploadFile = File(...), dry_run: bool = Form(True), user=Depends(require_chro_edit), db: Session = Depends(get_db)):
    try:
        rep = chro.replace_from_file(db, await file.read(), file.filename or "", user.username, dry_run)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception:
        raise HTTPException(400, "Could not read the file. Upload the HR master file (.xlsx).")
    if not dry_run:
        audit(db, user, "chro_asis_upload", f"{file.filename}: {rep['rows']} rows")
        db.commit()
    return rep


@router.post("/asis/reset")
def asis_reset(user=Depends(require_chro_edit), db: Session = Depends(get_db)):
    """Stop using an uploaded HR file: the As Is comes from the database again (the HR master file imported in Admin)."""
    n = chro.seed_from_hr(db, user.username)
    audit(db, user, "chro_asis_reset", f"{n} rows from the database (HR master file imported in Admin)")
    db.commit()
    return {"rows": n}


@router.get("/asis/export")
def asis_export(user=Depends(require_chro_edit), db: Session = Depends(get_db)):
    return Response(chro.asis_export(db), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="As Is {datetime.now():%Y-%m-%d}.xlsx"'})


@router.get("/saved")
def saved_list(user=Depends(require_chro), db: Session = Depends(get_db)):
    fns = {f.id: f.name for f in db.query(models.Function)}
    scope = scope_of(user, db)
    return [{"code": e.code, "name": e.name, "grade": e.grade or "", "position": e.position or "", "function": fns.get(e.function_id, ""),
             "reason": e.hc_reason or "", "date": e.hc_date or ""} for e in db.query(models.Employee).filter(models.Employee.hc_saved == True).order_by(models.Employee.name)
            if scope is None or fns.get(e.function_id) in scope]  # noqa: E712
