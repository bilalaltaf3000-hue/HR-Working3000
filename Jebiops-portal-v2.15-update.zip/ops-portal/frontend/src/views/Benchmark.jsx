import { L } from '../prefs.js'
import React, { useEffect, useState } from 'react'
import { api, download } from '../api.js'
import { canExport } from '../rights.js'
import { Modal, useLive } from '../ui.jsx'

// Grade benchmark: the max grade for each level of the structure (Division, Department, Unit, Team Leader, Others)
export const LV_TAG = { division: 'DIV', department: 'DEPT', unit: 'UNIT', team: 'TL', others: 'TEAMS', extra: 'EXTRA' }
export const LV_NAME = { division: 'Function', department: 'Department', unit: 'Unit', team: 'Team Lead / SM / Manager', others: 'Teams', extra: 'Extra layer' }
const LAYER_TXT = l => 'L' + (l || 6)   // Teams are Layer 6
export const TIER = { room: ['Opportunity to grow', 'bm-room'], at: ['At Max Grade', 'bm-at'], above: ['Above Max Grade', 'bm-above'] }
const n0 = v => Number(v || 0).toLocaleString('en-US')
const bandTxt = (b, t, words) => words ? (b === 'large' ? 'Larger' : 'Smaller') : b === 'large' ? `≥ ${t}` : `< ${t}`

export function BenchLegend({ counts }) {
  return <div className="bm-legend">
    <span><i className="bm-sw bm-room" />Opportunity to grow{counts ? <b>{n0(counts.room)}</b> : null}</span>
    <span><i className="bm-sw bm-at" />At max grade{counts ? <b>{n0(counts.at)}</b> : null}</span>
    <span><i className="bm-sw bm-above" />Above max grade{counts ? <b>{n0(counts.above)}</b> : null}</span>
    <span><i className="bm-sw bm-xl" />Extra layer (below Teams)</span>
    <span className="bm-tags">{['DIV', 'DEPT', 'UNIT', 'TL', 'TEAMS'].map(t => <em key={t}>{t}</em>)} level used</span>
  </div>
}

// ---------------------------------------------------------------- dashboard section
export function BenchSection({ sel, user, showLine }) {
  const fq = (sel || []).join(',')
  const [d, busy] = useLive(() => api('/api/bm/overview?functions=' + fq).catch(e => ({ error: e.message })), [fq])
  const [fn, setFn] = useState(null)
  const [tab, setTab] = useState('room')
  useEffect(() => setFn(null), [fq])
  if (!d) return <div className="loading">Loading…</div>
  if (d.error) return <p className="msg warn">{d.error}</p>
  const k = d.kpis, t = d.settings.threshold
  const src = { above: d.above, at: d.at || [], room: d.room || [], extra: d.extra }
  const rows = src[tab].filter(r => !fn || r.fid === fn)
  const cnt = k => n0(src[k].filter(r => !fn || r.fid === fn).length)
  const fname = fn && d.functions.find(f => f.id === fn)?.name
  return <div className={'bm-sec' + (busy ? ' busy' : '')}>
    <div className="bm-kpis">
      <div><span>Roles assessed</span><b>{n0(k.assessed)}</b><em>permanent staff in tagged functions</em></div>
      <div className="red"><span>Above max grade</span><b>{n0(k.above)}</b><em>{k.assessed ? (k.above / k.assessed * 100).toFixed(1) + '% of assessed' : '-'}</em></div>
      <div className="blue"><span>At max grade</span><b>{n0(k.at)}</b><em>no higher grade at their level</em></div>
      <div className="teal"><span>Opportunity to grow</span><b>{n0(k.room)}</b><em>below the max for their level</em></div>
      <div className="amb"><span>Extra layer</span><b>{n0(k.beyond)}</b><em>{k.beyond ? `permanent staff below Teams, under ${n0(k.extra)} Teams members, in ${k.beyond_functions} function${k.beyond_functions === 1 ? '' : 's'}` : 'Teams have no permanent direct reports'}</em></div>
    </div>
    {k.untagged > 0 && <p className="msg warn" style={{ margin: '0 0 12px' }}>{k.untagged} function{k.untagged === 1 ? ' is' : 's are'} not tagged as a Function, Department or Unit yet and {k.untagged === 1 ? 'is' : 'are'} not assessed. {user?.is_admin ? 'Tag them in Admin, Structure & Benchmark.' : ''}</p>}
    <div className="bm-two">
      <div className="panel"><div className="bm-ph"><h3>By function</h3><small>click a function to filter the list</small></div>
        <div className="tw scroll" style={{ maxHeight: 520 }}><table className="bm-t"><thead><tr><th>Function</th><th>Type</th><th className="num">Permanent</th><th>Band</th><th>Mix</th><th className="num">Above</th><th className="num">At max</th><th className="num">Extra layer</th></tr></thead>
          <tbody>{d.functions.map(f => { const a = f.assessed || 1
            return <tr key={f.id} className={'click' + (fn === f.id ? ' on' : '')} onClick={() => setFn(fn === f.id ? null : f.id)}>
              <td>{f.name}</td><td>{f.type ? LV_NAME[f.type] : <span className="bm-chip amb">Not tagged</span>}</td><td className="num">{n0(f.permanent)}</td><td>{bandTxt(f.band, t, d.settings.size_words)}{f.band_set ? <small> (set)</small> : null}</td>
              <td>{f.type ? <span className="bm-stack"><i className="bm-above" style={{ width: f.above / a * 100 + '%' }} /><i className="bm-at" style={{ width: f.at / a * 100 + '%' }} /><i className="bm-room" style={{ width: f.room / a * 100 + '%' }} /></span> : <small>not assessed</small>}</td>
              <td className="num">{f.type ? (f.above ? <span className="bm-chip red">{n0(f.above)}</span> : '0') : '-'}</td><td className="num">{f.type ? n0(f.at) : '-'}</td>
              <td className="num" title="Permanent staff reporting to a Teams member">{f.type ? (f.beyond ? <span className="bm-chip amb">{n0(f.beyond)}</span> : '0') : '-'}</td></tr> })}</tbody></table></div>
        <p className="formula">Band: the function's permanent headcount (FTE, not outsourced or FTC). Layers follow the level: L1 EXCO, L2 Function, L3 Department, L4 Unit, L5 Team Lead, then Teams. Extra layer: permanent staff reporting to a Teams member (Teams have FTC staff only).</p>
      </div>
      <div className="panel"><div className="bm-ph"><span className="seg sm" role="group">
          <button type="button" aria-pressed={tab === 'room'} onClick={() => setTab('room')}>Opportunity to grow ({cnt('room')})</button>
          <button type="button" aria-pressed={tab === 'at'} onClick={() => setTab('at')}>At Max Grade ({cnt('at')})</button>
          <button type="button" aria-pressed={tab === 'above'} onClick={() => setTab('above')}>Above Max Grade ({cnt('above')})</button></span>
          {canExport(user) && <button className="btn" onClick={() => download('/api/bm/export?functions=' + fq, 'grade_benchmark.xlsx').catch(() => {})}>Download Excel</button>}</div>
        {fname && <div className="formula" style={{ marginBottom: 6 }}>{fname} <button className="linkbtn" onClick={() => setFn(null)}>Show all</button></div>}
        <div className="tw scroll" style={{ maxHeight: 520 }}>{tab !== 'extra'
          ? <table className="bm-t"><thead><tr><th>Employee</th><th>Level</th><th className="num">Layer</th><th>Grade</th><th>Band</th><th>Max</th>{tab === 'above' && <th className="num">Gap</th>}</tr></thead>
            <tbody>{rows.slice(0, 500).map(r => <tr key={r.code} className="click" onClick={() => showLine && showLine(r.code)}>
              <td>{r.name}<small>{r.function} · {r.position || '-'}</small></td><td><span className="bm-lv">{LV_TAG[r.level]}</span></td><td className="num">{LAYER_TXT(r.layer)}</td><td>{r.grade}</td><td className="formula">{r.min ? `${r.min} / ${r.max}` : r.max}</td><td>{r.max}</td>{tab === 'above' && <td className="num"><span className="bm-chip red">+{r.gap}</span></td>}</tr>)}
              {rows.length > 500 && <tr><td colSpan={6} className="formula">Showing 500 of {n0(rows.length)}. Click a function on the left to narrow down, or download the Excel.</td></tr>}
              {!rows.length && <tr><td colSpan={6} className="formula">No one here.</td></tr>}</tbody></table>
          : <table className="bm-t"><thead><tr><th>Manager</th><th>Grade</th><th className="num">Layer</th><th className="num">People below</th></tr></thead>
            <tbody>{rows.slice(0, 400).map(r => <tr key={r.code} className="click" onClick={() => showLine && showLine(r.code)}>
              <td>{r.name}<small>{r.function} · {r.position || '-'}</small></td><td>{r.grade}</td><td className="num">{LAYER_TXT(r.layer)}</td><td className="num">{n0(r.below)}</td></tr>)}
              {!rows.length && <tr><td colSpan={4} className="formula">No extra layers: Teams have no permanent direct reports.</td></tr>}</tbody></table>}</div>
        <p className="formula">{tab !== 'extra' ? `Click a name for the reporting line.${tab === 'above' ? ' Gap: grade notches above the max (DGM II is one notch above DGM I).' : ''}` : `Teams members with permanent direct reports: their teams are an extra layer below Teams (only FTC staff should report to Teams).`}</p>
      </div>
    </div>
  </div>
}

// ---------------------------------------------------------------- the framework, presented
const FW_LEVELS = [['division', 'L2', 'Function'], ['department', 'L3', 'Department'], ['unit', 'L4', 'Unit'], ['team', 'L5', 'Team Lead / Senior Manager / Manager'], ['others', 'L6', 'Teams · No Direct Reports']]
export function BenchFramework({ settings: cfg, ladder, onClose, inline, top = 'COSO', topTag = 'EXCO', title = 'Grade Benchmark' }) {
  const nm = r => (ladder || {})[r] || r
  const band = (b, lv) => [cfg[b + '_min'][lv], cfg[b][lv]]
  const t = cfg.threshold   // follows the size threshold in Admin, Structure & Benchmark
  const body = <div className="bm-fw">
      <div className={'fw-head' + (title ? '' : ' fw-plain')}>{title && <div><span className="fw-eyebrow">Operations Services</span><h2>{title}</h2></div>}
        <div className="fw-legend"><span><i className="fw-s" />{cfg.size_words ? 'Smaller functions (lower headcount)' : `Function under ${t} permanent`}</span><span><i className="fw-l" />{cfg.size_words ? 'Larger functions (higher headcount)' : `Function ${t} or more`}</span></div></div>
      <div className="fw-pyr">
        <div className="fw-tier fw-top" style={{ '--w': '34%' }}><b>L1</b><span>{top}</span><em>{topTag}</em></div>
        {FW_LEVELS.map(([lv, L, name], i) => <div key={lv} className={'fw-tier' + (lv === 'others' ? ' fw-teams' : '')} style={{ '--w': `${46 + i * 11}%` }}>
          <b>{L}</b><span>{name}</span>
          <em><i className="fw-s" />{nm(band('small', lv)[0])} – {nm(band('small', lv)[1])}<i className="fw-l" />{nm(band('large', lv)[0])} – {nm(band('large', lv)[1])}</em></div>)}
        <div className="fw-tier fw-l7" style={{ '--w': '96%' }}><b>L7</b><span>FTCs only (if necessary)</span><em /></div>
      </div>
    </div>
  if (inline) return body
  return <Modal wide title="Grade Benchmark" onClose={onClose}>
    {body}
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 12 }}><button className="btn" onClick={() => { document.body.classList.add('print-fw'); window.print(); setTimeout(() => document.body.classList.remove('print-fw'), 500) }}>Print / Save as PDF</button></div>
  </Modal>
}

// ---------------------------------------------------------------- the organogram's three lists
export function BenchPeople({ bench, people, onPick }) {
  const [tab, setTab] = useState('above')
  const [q, setQ] = useState('')
  const all = people.map(p => ({ p, b: bench.people[p.id] })).filter(x => x.b && x.b.t)
  const ql = q.trim().toLowerCase()
  const rows = all.filter(x => x.b.t === tab && (!ql || (x.p.n + ' ' + x.p.id + ' ' + (x.p.pos || '')).toLowerCase().includes(ql)))
    .sort((a, b) => (a.b.y || 0) - (b.b.y || 0) || (b.p.rk || 0) - (a.p.rk || 0) || a.p.n.localeCompare(b.p.n))
  const n = k => all.filter(x => x.b.t === k).length
  return <div className="bm-people">
    <div className="bm-ptabs">{[['room', 'Opportunity to grow'], ['at', 'At Max Grade'], ['above', 'Above Max Grade']].map(([k, l]) =>
      <button key={k} type="button" className={'bm-pt ' + TIER[k][1]} aria-pressed={tab === k} onClick={() => setTab(k)}><b>{n0(n(k))}</b><span>{l}</span></button>)}
      <input className="inp" value={q} onChange={e => setQ(e.target.value)} placeholder="Filter by name, code or position" /></div>
    <div className="tw scroll" style={{ maxHeight: 260 }}><table className="bm-t"><thead><tr><th>Employee</th><th>Level</th><th className="num">Layer</th><th>Grade</th><th>Max grade</th></tr></thead>
      <tbody>{rows.slice(0, 400).map(({ p, b }) => <tr key={p.i} className="click" onClick={() => onPick(p)} title="Show the reporting line in the chart">
        <td>{p.n}<small>{p.pos || '-'}</small></td><td><span className="bm-lv">{LV_TAG[b.l]}</span></td><td className="num">{LAYER_TXT(b.y)}</td><td>{p.g}</td><td>{b.mx}</td></tr>)}
        {rows.length > 400 && <tr><td colSpan={5} className="formula">Showing 400 of {n0(rows.length)}. Filter to narrow down.</td></tr>}
        {!rows.length && <tr><td colSpan={5} className="formula">No one here.</td></tr>}</tbody></table></div>
  </div>
}

// ---------------------------------------------------------------- admin tab
export function BenchmarkAdminTab({ notify }) {
  const [d, setD] = useState(null)
  const [cfg, setCfg] = useState(null)
  const [edit, setEdit] = useState(null)
  const [showCheck, setShowCheck] = useState(false)
  const load = () => api('/api/bm/admin').then(x => { setD(x); setCfg(c => c || x.settings) }).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [])
  if (!d || !cfg) return <div className="loading">Loading…</div>
  const setType = async (f, type) => { try { await api(`/api/bm/function/${f.id}`, { method: 'PUT', body: { type } }); notify(`${f.name}: ${type ? LV_NAME[type] : 'not tagged'}.`); load() } catch (e) { notify(e.message, true) } }
  const setBand = async (f, band) => { try { await api(`/api/bm/function/${f.id}`, { method: 'PUT', body: { band } }); notify(`${f.name}: ${band === 'small' ? 'under ' + t : band === 'large' ? t + ' or more' : 'band from the headcount'}.`); load() } catch (e) { notify(e.message, true) } }
  const saveCfg = async () => { try { const s = await api('/api/bm/settings', { method: 'PUT', body: cfg }); setCfg(s); notify('Benchmark saved.'); load() } catch (e) { notify(e.message, true) } }
  const setMax = (band, lv, v) => setCfg(c => ({ ...c, [band]: { ...c[band], [lv]: +v } }))
  const ck = d.check
  const t = cfg.threshold
  return <>
    <div className="bm-two bm-adm">
      <div className="panel"><div className="bm-ph"><h2>Functions and Levels</h2><button className="btn pri" onClick={() => { setShowCheck(true); load() }}>Check Untagged</button></div>
        <p className="sub">Mark each function as a Function, Department or Unit; its head holds that level and its layer (Function L2, Department L3, Unit L4). Each step down the reporting line is the next level: Team Lead / SM / Manager (L5), then Teams. A level you set on a manager carries down to their team.</p>
        {showCheck && <div className="bm-check">
          {!ck.untagged.length ? <p className="msg ok" style={{ margin: 0 }}>Every function is tagged.</p> : <>
            {ck.untagged.length > 0 && <p><b>{ck.untagged.length} function{ck.untagged.length === 1 ? '' : 's'} not tagged:</b> {ck.untagged.map(f => f.name).join(', ')}. Shown as "Not assessed" until tagged.</p>}
</>}
          {ck.manual.length > 0 && <p className="formula" style={{ margin: '6px 0 0' }}>{ck.manual.length} level{ck.manual.length === 1 ? '' : 's'} set by hand. <button className="linkbtn" onClick={() => setEdit({ manual: true })}>View</button></p>}
        </div>}
        <div className="tw"><table className="bm-t"><thead><tr><th>Function</th><th className="num">Permanent</th><th>Band</th><th>Type</th><th>Levels inside</th><th /></tr></thead>
          <tbody>{d.functions.map(f => <tr key={f.id}><td>{f.name}</td><td className="num">{n0(f.permanent)}</td><td><select className={'inp' + (f.band_set ? ' bm-set' : '')} value={f.band_set ? f.band : ''} onChange={e => setBand(f, e.target.value)} style={{ minWidth: 150 }} title="The size band of the function: from its permanent headcount, or set by hand">
              <option value="">{`Auto: ${bandTxt(f.auto_band, t)}`}</option><option value="small">{`Under ${t} (set)`}</option><option value="large">{`${t} or more (set)`}</option></select></td>
            <td><select className="inp" value={f.type || ''} onChange={e => setType(f, e.target.value || null)} style={{ minWidth: 130 }}>
              <option value="">Not tagged</option><option value="division">Function</option><option value="department">Department</option><option value="unit">Unit</option></select></td>
            <td className="bm-cnt">{f.type ? ['department', 'unit', 'team', 'extra'].filter(k => f.counts[k] && k !== f.type).map(k => `${LV_NAME[k]} ${f.counts[k]}`).join(' · ') || 'No managers' : <span className="bm-chip amb">Not assessed</span>}</td>
            <td>{f.type && <button className="btn sm" onClick={() => setEdit({ fid: f.id, name: f.name })}>Edit</button>}</td></tr>)}</tbody></table></div>
      </div>
      <div className="panel"><div className="bm-ph"><h2>Max Grade by Level</h2><button className="btn pri" onClick={saveCfg}>Save</button></div>
        <label className="bm-thr">{L('dash.dc')} staff in the permanent headcount<select className="inp" value={cfg.dc_permanent === false ? 'n' : 'y'} onChange={e => setCfg(c => ({ ...c, dc_permanent: e.target.value === 'y' }))} style={{ maxWidth: 330 }}>
          <option value="y">{`Count ${L('dash.dc')} as permanent`}</option><option value="n">{`Do not count ${L('dash.dc')}`}</option></select></label>
        <label className="bm-thr">Show the size as<select className="inp" value={cfg.size_words ? 'w' : 'n'} onChange={e => setCfg(c => ({ ...c, size_words: e.target.value === 'w' }))} style={{ maxWidth: 330 }}>
          <option value="n">{`The number (under ${t} / ${t} or more)`}</option><option value="w">Words (smaller / larger functions)</option></select></label>
        <label className="bm-thr">Size threshold (permanent headcount of the function)<input className="inp" type="number" min="1" value={t} onChange={e => setCfg(c => ({ ...c, threshold: +e.target.value }))} /></label>
        <table className="bm-t bm-max"><thead><tr><th>Level</th><th>Function under {t}<small>lower / max grade</small></th><th>Function {t} or more<small>lower / max grade</small></th></tr></thead>
          <tbody><tr><td>Level 1 · COSO</td><td colSpan={2} className="formula">EXCO</td></tr>
            {['division', 'department', 'unit', 'team', 'others'].map((lv, i) => <tr key={lv}><td>{lv === 'others' ? 'Level 6 · Teams · No Direct Reports' : `Level ${i + 2} · ${LV_NAME[lv]}`}</td>
              {['small', 'large'].map(b => <td key={b}><span className="bm-pair"><select className="inp" value={cfg[b + '_min'][lv]} onChange={e => setMax(b + '_min', lv, e.target.value)}>
                {d.ladder.map(g => <option key={g.rank} value={g.rank}>{g.name}</option>)}</select><span>/</span><select className="inp" value={cfg[b][lv]} onChange={e => setMax(b, lv, e.target.value)}>
                {d.ladder.map(g => <option key={g.rank} value={g.rank}>{g.name}</option>)}</select></span></td>)}</tr>)}
            <tr><td>Level 7 · FTCs only (if necessary)</td><td colSpan={2} className="formula">not assessed</td></tr></tbody></table>
        <p className="formula">The grade band of each level, as in HR's grid. The max grade decides the result: below it, opportunity to grow; at it, at max grade; above it, above max grade. Only permanent staff are assessed. Grades are compared by the number in front of them in the HR sheet ({d.ladder.map(g => g.name).join(' < ')}).</p>
      </div>
    </div>
    {edit && <LevelEditor edit={edit} d={d} notify={notify} onClose={() => setEdit(null)} onSaved={load} />}
  </>
}

function LevelEditor({ edit, d, notify, onClose, onSaved }) {
  const [rows, setRows] = useState(null)
  const [q, setQ] = useState('')
  const seq = React.useRef(0)
  const reload = () => {   // only the latest answer is shown (an earlier, slower one never overwrites it)
    const id = ++seq.current
    if (edit.fid) api(`/api/bm/function/${edit.fid}/people`).then(x => { if (id === seq.current) setRows(x.people) }).catch(e => notify(e.message, true))
    else api('/api/bm/check').then(x => { if (id === seq.current) setRows((edit.extra ? x.extra : x.manual).map(r => ({ ...r, auto: r.auto !== undefined ? r.auto : !edit.manual }))) }).catch(e => notify(e.message, true))
  }
  useEffect(reload, [])
  const setBelow = async (r, below) => {
    try { await api('/api/bm/level', { method: 'PUT', body: { code: r.code, below: below || '' } }); notify(`${r.name}'s direct reports: ${below === 'team' ? 'Team Lead / SM / Manager' : below === 'others' ? 'Teams' : 'by position'}.`); reload(); onSaved() } catch (e) { notify(e.message, true) }
  }
  const set = async (r, level) => {
    try { await api('/api/bm/level', { method: 'PUT', body: { code: r.code, level: level || null } }); notify(`${r.name}: ${level ? LV_NAME[level] : 'level from the reporting line'}.`); reload(); onSaved()
      if (level === 'unit' && r.reports > 0) setAsk(r)   // a Unit head: ask what their team is
    } catch (e) { notify(e.message, true) }
  }
  const [ask, setAsk] = useState(null)
  const ql = q.trim().toLowerCase()
  const shown = (rows || []).filter(r => !ql || (r.name + ' ' + r.code + ' ' + r.position).toLowerCase().includes(ql))
  return <Modal wide title={edit.fid ? `Levels: ${edit.name}` : edit.extra ? 'Extra-layer managers' : 'Levels set by hand'}
    sub={edit.fid ? 'Everyone in the function. "Their direct reports" decides whether a manager\'s team are Team Lead / SM / Manager or Teams (for example under a Unit head). Pick a level to change it; "From reporting line" goes back to the portal\'s own placement.' : ''} onClose={onClose}>
    <input className="inp" value={q} onChange={e => setQ(e.target.value)} placeholder="Filter by name, code or position" style={{ marginBottom: 10, maxWidth: 360 }} />
    {!rows ? <div className="loading">Loading…</div> : <div className="tw scroll" style={{ maxHeight: '60vh' }}><table className="bm-t"><thead><tr><th>Employee</th>{!edit.fid && <th>Function</th>}<th>Grade</th><th className="num">Layer</th><th className="num">Reports</th><th>Level</th><th>Their direct reports</th></tr></thead>
      <tbody>{shown.slice(0, 600).map(r => <tr key={r.code}><td>{r.name}<small>{r.code} · {r.position || '-'}</small></td>{!edit.fid && <td>{r.function}</td>}<td>{r.grade}</td><td className="num">{r.layer}</td><td className="num">{n0(r.reports)}</td>
        <td><select className="inp" value={r.auto ? '' : r.level} onChange={e => set(r, e.target.value)} style={{ minWidth: 200 }}>
          <option value="">{`From reporting line${r.auto ? ': ' + LV_NAME[r.level] : ''}`}</option>
          {d.levels.map(l => <option key={l.k} value={l.k}>{l.name}{!r.auto && r.level === l.k ? ' (set by hand)' : ''}</option>)}</select></td>
        <td>{r.reports > 0 && <select className={'inp' + (r.below ? ' bm-set' : '')} value={r.below || ''} onChange={e => setBelow(r, e.target.value)} style={{ minWidth: 150 }}>
          <option value="">By position</option><option value="team">Team Lead / SM / Manager</option><option value="others">Teams</option></select>}</td></tr>)}
        {!shown.length && <tr><td colSpan={7} className="formula">No one to show.</td></tr>}</tbody></table></div>}
    {ask && <Modal title={`${ask.name} is a Unit head`} sub={`What are their ${ask.reports} direct reports?`} onClose={() => setAsk(null)}>
      <div className="row-actions">
        <button className="btn pri" onClick={() => { setBelow(ask, 'team'); setAsk(null) }}>Team Lead / SM / Manager</button>
        <button className="btn pri" onClick={() => { setBelow(ask, 'others'); setAsk(null) }}>Teams</button>
        <button className="btn" onClick={() => { setBelow(ask, ''); setAsk(null) }}>By position</button></div>
      <p className="formula">You can change this later in the "Their direct reports" column.</p></Modal>}
  </Modal>
}

// ---------------------------------------------------------------- the organogram's data
export function useBench(on, key) {   // key: fetched again when the organisation reloads
  const [b, setB] = useState(null)
  useEffect(() => { if (on) api('/api/bm/people').then(setB).catch(() => setB({ people: {}, functions: {} })) }, [on, key])
  return on ? b : null
}
