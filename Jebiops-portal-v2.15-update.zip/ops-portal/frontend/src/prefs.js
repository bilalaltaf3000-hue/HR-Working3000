// Display preferences from the admin's settings (loaded with /api/lookups).
// showTime: show man-hours, FTE equivalents and utilisation. Off by default.
// nature: the "nature of work" heading and its options (managed by the admin in Lists).
export const prefs = {
  showTime: false, hideResigned: true, showThemes: false, showCategories: true,
  nature: { label: 'Nature of Work', options: ['Core Physical', 'System Based', 'Straight Through Processing (STP)'] },
}
export const setPrefs = lk => {
  prefs.showTime = !!(lk && lk.show_time)
  prefs.hideResigned = !lk || lk.hide_resigned !== false
  prefs.showCategories = !lk || lk.show_categories !== false   // the activity category panel on Activity Insights
  prefs.labels = (lk && lk.labels) || {}
  prefs.catThemes = (lk && lk.category_themes) || {}
  prefs.themeList = (lk && lk.theme_list) || []
  prefs.showThemes = !!(lk && lk.show_themes)   // activity themes on Activity Insights and in exports, once the admin turns them on
  if (lk && lk.handling) prefs.nature = { label: lk.handling_label || 'Nature of Work', options: lk.handling }
}
// colour of each nature-of-work option, in the admin's order (CSS variable names, so both themes work)
const NAT_VARS = ['--n1', '--n2', '--n3', '--nat4', '--nat5', '--nat6']
export const natVar = name => { const i = prefs.nature.options.indexOf(name); return NAT_VARS[(i < 0 ? 5 : i) % NAT_VARS.length] }
export const natCol = name => `var(${natVar(name)})`

// Labels on the dashboard pages that the admin can rename (Admin, Labels). Each: [page, key, default text].
export const LABELS = [
  ['Sidebar', 'nav.dashboard', 'Dashboard'], ['Sidebar', 'nav.activities', 'Activity Insights'],
  ['Sidebar', 'nav.employees', 'Employee Activities'], ['Sidebar', 'nav.regions', 'Geographical Spread'],
  ['Dashboard', 'dash.title', 'Operations Services'],
  ['Dashboard', 'dash.total', 'Total Employees'], ['Dashboard', 'dash.fte', 'FTE'], ['Dashboard', 'dash.dc', 'Contract'], ['Dashboard', 'dash.dw', 'Daily Wagers'], ['Dashboard', 'dash.ftc', 'FTC'], ['Organogram', 'vac.repl', 'Replacement'], ['Organogram', 'vac.new', 'New position'], ['Organogram', 'vac.pend', 'Pending Hiring'],
  ['HR Dashboard', 'hr.active', 'Active Staff'], ['HR Dashboard', 'hr.repl', 'Replacement 2026'], ['HR Dashboard', 'hr.new', 'New Headcount 2027'], ['HR Dashboard', 'hr.pend', 'Pending Hiring 2026'], ['HR Dashboard', 'hr.appr', 'Approved Headcount 2026'], ['HR Dashboard', 'hr.saved', 'Headcount Saved'], ['HR Dashboard', 'hr.xf', 'Cross Functional Transition Staff'], ['HR Dashboard', 'hr.cur', 'Current State'], ['HR Dashboard', 'hr.pro', 'Proposed State'],
  ['Dashboard', 'dash.layers', 'Layers'], ['Dashboard', 'dash.managers', 'Managers'], ['Dashboard', 'dash.svc', 'Service or Support'],
  ['Dashboard', 'sec.org', 'Organogram'], ['Dashboard', 'sec.layers', 'Layers and Spans'], ['Dashboard', 'sec.work', 'Service or Support'],
  ['Dashboard', 'sec.acts', 'Activities'], ['Dashboard', 'sec.opps', 'Opportunities'], ['Dashboard', 'sec.bench', 'Grade Benchmark'], ['Dashboard', 'dash.actshead', 'Activities'],
  ['Dashboard', 'dash.layerhead', 'Function-Wise Layer'], ['Dashboard', 'dash.span', 'Span of Control'],
  ['Dashboard', 'dash.oppshead', 'Structure Opportunities and Gaps'],
  ['Activity Insights', 'ins.title', 'Activity Insights'],
  ['Activity Insights', 'ins.employees', 'Employees'], ['Activity Insights', 'ins.activities', 'Activities'],
  ['Activity Insights', 'ins.volbased', 'Volume Based Activities'], ['Activity Insights', 'ins.nonvol', 'Non Volume Based Activities'],
  ['Activity Insights', 'ins.themes', 'Activity Themes'], ['Activity Insights', 'ins.categories', 'Activity Categories'],
  ['Activity Insights', 'ins.volume', 'Avg Daily Volume'], ['Activity Insights', 'vol.file', 'File Based'], ['Activity Insights', 'vol.txn', 'Activity Based'], ['Activity Insights', 'ins.auto', 'Automation Candidates'],
  ['Activity Insights', 'ins.themepanel', 'Activity Themes'], ['Activity Insights', 'ins.catpanel', 'Activity Category'],
  ['Activity Insights', 'ins.autopanel', 'Automation Opportunity'], ['Activity Insights', 'ins.freq', 'Frequency of Work'],
  ['Activity Insights', 'ins.vol.function', 'Avg Daily Volume by Function'], ['Activity Insights', 'ins.vol.unit', 'Avg Daily Volume by Unit'],
  ['Activity Insights', 'ins.vol.theme', 'Avg Daily Volume by Activity Theme'], ['Activity Insights', 'ins.vol.category', 'Avg Daily Volume by Activity Category'],
  ['Activity Insights', 'ins.byfunction', 'Activities by Function'], ['Activity Insights', 'ins.ranking', 'Employees by Number of Activities'],
  ['Geographical Spread', 'reg.title', 'Geographical Spread'],
  ['Geographical Spread', 'reg.employees', 'Employees'], ['Geographical Spread', 'reg.regions', 'Regions'], ['Geographical Spread', 'reg.ftc', 'FTC Share'],
  ['Geographical Spread', 'reg.byregion', 'Employees by Region'], ['Geographical Spread', 'reg.share', 'Share of Employees'],
  ['Geographical Spread', 'reg.glance', 'Regions at a Glance'], ['Geographical Spread', 'reg.across', 'Functions Across Regions'],
]
const LABEL_DEFAULT = Object.fromEntries(LABELS.map(([, k, d]) => [k, d]))
prefs.labels = {}
// the admin's text for a label, or the default
export const L = key => (prefs.labels && prefs.labels[key]) || LABEL_DEFAULT[key] || key

// the theme of an activity category ('' when themes are off or the category has none)
prefs.catThemes = {}
export const themeOf = cat => (prefs.showThemes && cat && prefs.catThemes[cat.split(/\s+/).filter(Boolean).join(' ').toLowerCase()]) || ''
// one colour per theme, the same on every page (by its place in the admin's theme list)
prefs.themeList = []
export const themeColor = name => {
  if (!name || name === 'No Theme') return 'var(--none)'
  const i = prefs.themeList.indexOf(name)
  return `var(--th${(i < 0 ? [...name].reduce((a, ch) => a + ch.charCodeAt(0), 0) : i) % 6})`
}
// categories hidden from the dashboard pages: themes on and the admin's "Show Categories" off (data capture keeps them)
export const catHidden = () => !!(prefs.showThemes && !prefs.showCategories)

// volume type of an activity: "File" = file based (e.g. the rows of an uploaded file), otherwise activity based
export const VOL_FILE = 'File'
export const volTypeLabel = t => t === VOL_FILE ? L('vol.file') : L('vol.txn')
export const VOL_COL = { file: 'var(--x-file)', txn: 'var(--x-txn)' }

// the kinds of vacant position: the admin's name and the pill colour
export const vacKindL = k => L(k === 'replacement' ? 'vac.repl' : k === 'pending' ? 'vac.pend' : 'vac.new')
export const vacPillC = k => k === 'replacement' ? 'vk-r' : k === 'pending' ? 'vk-p' : 'vk-n'
