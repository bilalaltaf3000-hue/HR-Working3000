# Updating the VM to version 2.15: Work Summaries

Version 2.15 adds **Work Summaries**: a small box button on organogram cards opens a summary of the employee's recorded work, written by the bank's on-premise AI (Qwen on vLLM, as for Role Overlap).

- **2.15 contains everything in 2.14** (Grade Benchmark, Layer 1, the Role Overlap changes). If 2.14 is not installed yet, install this zip instead and read `UPDATE_TO_2.14_VM.md` for what 2.14 brings.
- **Only the portal code changes.** No pip install; vLLM is not touched. New tables and columns are added automatically at start.

---

## What is new

- **The box button** on organogram cards (dashboard and the Organogram page), only for employees with recorded activities, and only for logins with the new **Work Summary** tick (Admin → Users → Edit access; administrators always). The "No team" tag is removed from the organogram.
- **The pop-up:**
  - **Summary of work:** two or three sentences from the AI covering the volume-based work (with the volumes) and the non-volume-based work;
  - four figures from the portal's own data: activities, volume-based, non-volume-based, items a day;
  - **Volume-based work** (each with its volume and frequency) and **Non-volume-based work**, as short phrases;
  - **View all activities** (the full list) and, for the admin, **Write now** for that one person.
  - With fewer than 2 activities there is no written summary; the work is listed.
- **Written in advance:** **Admin → AI Server → Work Summaries** shows how many are up to date, changed since, or not written, and runs **Write New and Changed** (or **Write All Again**) for one function or all, in the background. When an employee's activities change, their pop-up says so and the next run rewrites only them. Only one AI run (summaries or Role Overlap) goes at a time.
- **Grade benchmark follows HR's grid** (Shehzad Shafi's mail):
  - **The layer comes from the level, not from the reporting depth:** Level 1 COSO, Level 2 Division, Level 3 Department, Level 4 Unit, Level 5 Team Lead / Senior Manager / Manager, then **Teams**. A Department head reporting straight to Kamran Muggo is Layer 3.
  - **Teams** sit below Layer 5 and have no direct reports, FTC staff only. Permanent staff reporting to a Teams member are shown as an **Extra layer** (dashed amber card, "Extra layer" figure, list and Excel sheet). The old "max layers 5" setting is gone.
  - **Each level has a band** (lower / max grade), editable in Admin → Structure & Benchmark, filled with the grid: for example Division DGM II / GM I under 50 and GM I / GM II for 50 or more. The **max grade** still decides Opportunity to grow, At Max Grade and Above Max Grade; the band is shown in the lists, the hover text and the Excel.
  - **Layers everywhere follow the level** for tagged functions: the dashboard's Function-Wise Layer table, the Layers figure, the organogram and the reporting line, and the PDF / PowerPoint / Excel. A function marked Department starts at L3 (L2 shows "-"); L6 is Teams and L7 an extra layer below Teams. Untagged functions still count by reporting depth. The **Layers** count is the layers in use plus Layer 1 (a blank layer, such as L2 under a Department, is not counted), and each function in the table shows its tag (Division, Department or Unit) in front of its name.
  - **View Benchmark Framework** (button at the top of the Grade Benchmark section): the boss's grid presented as a pyramid of levels with both bands, and the bands drawn on the grade ladder; **Print / Save as PDF** for sharing.
  - **Size band by hand:** in Admin → Structure & Benchmark, each function's Band can stay **Auto** (from its permanent headcount) or be set to **Under 50** or **50 or more**.
  - **Who may change the benchmark:** the admin login can tick **Change Grade Benchmark** for another administrator (Admin → Users → Edit access; needs Administrator and Grade Benchmark). That administrator then sees Admin → Structure & Benchmark and can change function types, levels and bands.
  - Tags on cards: DIV, DEPT, UNIT, **TL** (Team Lead / SM / Manager) and **TEAMS**.
- **Layer panel** (new **Layers** button on the dashboard organogram, and always beside the reporting line chart that opens when you click a person):
  - the reporting line of the selected person layer by layer from the Group Head, **"–" where a layer is skipped** (for example no Division head above a Department);
  - the layers **below** the person with how many people sit on each, and how deep their part goes ("their part goes down to L6"), so the depth is known before opening anyone;
  - **Edit** switch at the top: when on, set the person's level (Division, Department, Unit, Team Lead / SM / Manager, Teams) and what their direct reports are; the chart and every count update at once.
  - Click a layer count ("32 people") for the list of those employees; the panel also shows in **Full Screen**.
  - A level set by hand carries down from that level: a Department head set to **Division** moves their Units up to Department, and so on.
  - Ticks in Admin → Users → Edit access: **Layer Panel** (sees it; administrators always) and **Edit in Layer Panel** (may use Edit; any administrator can give it).
- **Grade Benchmark view:** the button is **View Benchmark**; the ladder chart, the explanation boxes and the paragraph are removed; **L6 · Teams · No Direct Reports** and a light **L7 · FTCs only (if necessary)** row. The Layers count is the deepest layer again (a blank L2 still counts).
- **Role Overlap:** each activity's volume and frequency is now given to the AI, so it can see when the same task is done at very different volumes. Run the analysis again to use it.

---

## Install

### 1. Copy the zip to the VM

```
scp ops-portal-v2.15-update.zip YOUR_VM_USER@hblassist.domestic.hbl.com:/tmp/
```

### 2. Back up first (do not skip)

```
sudo systemctl stop ops-portal
STAMP=$(date +%Y%m%d_%H%M)
sudo mkdir -p /data/opt/ops-portal/backups
sudo python3 -c "import sqlite3,sys; s=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); d=sqlite3.connect(sys.argv[1]); s.backup(d); d.close(); s.close(); print('database backed up')" /data/opt/ops-portal/backups/portal_before_2.15_$STAMP.db
sudo tar -czf /data/opt/ops-portal/backups/code_before_2.15_$STAMP.tgz -C /data/opt/ops-portal --exclude backend/venv --exclude backend/data --exclude backups .
sudo python3 -c "import sqlite3,glob; f=sorted(glob.glob('/data/opt/ops-portal/backups/portal_before_2.15_*.db'))[-1]; c=sqlite3.connect(f); print(f); print(c.execute('pragma integrity_check').fetchone()[0], c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities')"
```

The last command prints `ok`, then the employee and activity counts. **Write the two numbers down.**

### 3. Install the new code

```
rm -rf /tmp/ops-update && python3 -m zipfile -e /tmp/ops-portal-v2.15-update.zip /tmp/ops-update
ls /tmp/ops-update/ops-portal/backend/app/empsum.py && echo "zip OK"
sudo rsync -a --exclude 'backend/data' --exclude 'backend/venv' --exclude 'backups' --exclude 'wheels' /tmp/ops-update/ops-portal/ /data/opt/ops-portal/
```

Without `rsync`:

```
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo cp -r /tmp/ops-update/ops-portal/backend/app /tmp/ops-update/ops-portal/backend/static /data/opt/ops-portal/backend/
sudo cp -r /tmp/ops-update/ops-portal/deploy /data/opt/ops-portal/
```

### 4. Owner and permissions

```
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 700 /data/opt/ops-portal/backend/data
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backend/data/secret.key
sudo chmod -R a+rX /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo chmod 755 /data/opt/ops-portal/backend/venv/bin/*
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
```

### 5. Start and check

```
sudo systemctl start ops-portal
sleep 8
sudo systemctl status ops-portal --no-pager | head -5
sudo journalctl -u ops-portal -n 30 --no-pager
sudo -u opsportal python3 -c "import sqlite3; c=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); print(c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities'); print('emp_summaries' in [r[0] for r in c.execute("select name from sqlite_master")], 'can_summary' in [r[1] for r in c.execute('pragma table_info(users)')])"
```

The status shows **active (running)**, the log has no `Traceback`, the counts match step 2, and the last line prints `True True`.

---

## In the browser (one time)

1. Sign in as admin, press **Ctrl+F5** once.
2. If 2.14 was not installed before, do its one-time browser steps too (`UPDATE_TO_2.14_VM.md`, "In the browser").
3. **Admin → AI Server → Work Summaries:** click **Write New and Changed**. It runs in the background; all of COSO can take a few hours, so start it after office hours. One function first is a good test (choose it in the Function list).
4. **Admin → Users → Edit access:** tick **Work Summary** for the logins that should see the summary button. Administrators see it already.
5. **Dashboard → Organogram:** the small box button on a card opens the summary. It shows only on employees with recorded activities.
6. **Admin → Users → Edit access:** tick **View Benchmark** for anyone who should see the framework (levels and max grades only, no one's grades). The button sits at the top right of the dashboard. The admin login has it already.
7. **Admin → Structure & Benchmark → Show the size as:** choose *The number* (under 50 / 50 or more) or *Words* (smaller / larger functions), then Save.
8. **Layer panel, Edit on:** if a person's function is not tagged yet, the panel now asks "Function is a" (Division / Department / Unit) first; after that their level can be set.
9. **Contract (DC) and Daily Wagers:** mark people in **Admin → Employees → Edit** (tick Contract or Daily Wagers), or many at once with the **DC** and **Daily Wager** columns in Data Transfer ("Yes" marks; a blank clears only when "apply structure" is ticked). Their cards appear after FTE once anyone is marked. Rename them, and set the order of the four types (FTE, Contract, FTC, Daily Wagers), in **Admin → Labels**.
10. **Admin → Structure & Benchmark:** choose whether Contract (DC) staff count in the permanent headcount (the under 50 / 50 or more size). Default: they count. Daily Wagers never count and are not benchmarked.
11. **Admin → Staff Segmentation:** choose the function (Credit Administration Division is preselected), type the rows, figures and "as of" date, then Save. A button with the table's title appears at the top of that function's dashboard for everyone who can see it.
13. **Vacant positions:** in **Admin → Vacant Positions** each position is now **Replacement** or **New position** (existing ones show as New position; edit them to change). They have different colours in the organogram (blue / amber). Rename the two in **Admin → Labels → Organogram**.
    - **An employee reporting to a vacant position:** in **Admin → Employees → Edit**, under *Reports to*, choose **Or a vacant position…**, or open the vacant position and add employees under *Employees Who Report to This Position*. They show under the vacant box (with To Be Hired on); meanwhile they count under the manager the position reports to. When the position is filled with an employee, they move to that employee.
15. **Vacant position list (main dashboard):** Show To Be Hired → *View List* now has two tabs, Replacement and New.
18. **Restructure columns in Data Transfer (Employees sheet):** *Headcount saved* (Yes = surrender), *Replacement* (Yes = open a Replacement vacant position for them), *Replacement position / grade / type*, *Replacement reports to (manager code)* (blank = their line manager), *Trade Staff Realignment* (Yes), *Reports to (vacancy ID)* (the employee reports to that vacant position; works for a new employee row with *Added by function: Yes*). The Vacant positions sheet is imported first, but a position added in the same file has no ID yet: import it, export again, then use its ID.
17. **Layer columns in Data Transfer:** the Employees sheet now has *Layer* and *Layer name* after *Manager name* (as on the dashboard; the to be hired rows one layer below their manager). They are for information: changing them in Excel changes nothing on import.
16. **Vacant positions in Data Transfer:** the export now has a **Vacant positions** sheet. Change a row to update a position, add a row with a blank *Vacancy ID* to add one, or write *Yes* in *Delete* to remove one; then import (Check first shows the counts). Importing the same file twice does not add the new positions twice.
14. **Export HTML** (organogram buttons, for logins with Export): saves the organogram on screen as one HTML file that opens in any browser, with the layer panel on the left, search, zoom and click to open teams. Vacant positions are included when To Be Hired is shown.
12. **HR Dashboard** (new design, named *Dashboard* on the page): any administrator gives it in **Admin → Users → Edit access → HR Dashboard** (and *HR Dashboard shows* sets the functions a login sees; administrators see all).
    - **Current State / Proposed State** at the top. Current State = the HR master file (database, or an HR file uploaded with *Upload HR Master File*; *Use Database* goes back). Proposed State = the portal today, shown as *Current → Proposed* with the change.
    - Current State shows **Active Staff** (FTE / Contract / FTC / Daily Wagers; a type with 0 is hidden) and **Layers**. Proposed State adds **Replacement 2026** (Normal = resigned staff replacement, Special = surrendered staff replacement, PR tagged), **New Headcount 2027** and **Service / Support**.
    - Section buttons: Position Benchmark, Organogram, Layers, Optimization, Activities. Staff lists show the highest grade first.
    - **Position Benchmark** (logins with *Benchmark on HR Dashboard*): the grade framework (L1 EXCO) and Below / At / Above Benchmark lists. **Organogram**: in Proposed State the layer panel on the left shows the selected person's direct reports (Current State shows the chart only); Proposed State shows the vacant positions (Replacement and New) as boxes; surrendered staff are a cut box with their team under them. **Layers**: by function, most staff first.
    - **Optimization** (a dash for none): 1 Delayering (layers reduced, Current → Proposed; Max Managerial Layers 5), 2 Unit Transition Opportunity (administrators tick the ones that count; only ticked units move staff between functions: anyone else whose function differs in the HR file counts in their Proposed function in both states and, in the Current State organogram, sits under their Proposed line manager when their HR file manager is in another function), 3 Geographic Consolidation, 4 Position Realignment Opportunity (above max grade), 5 Title Realignment, 6 Staff Exit Candidate (PR · FTE · FTC), 7 Post Retirement Staff Replacement, 8 Trade Staff Realignment (counted as headcount saved: out of the Proposed State, cut box; shown for Operations Services and the Trade function; administrators choose that function in the card's list, default: functions named "Trade..."). Then **Activities**.
    - **Unit Transition check:** at the bottom of the Unit Transition list, *Not in the list? Check someone* shows why a person is, or is not, a unit transition (function in the HR file and Proposed, line managers, team, ticked). A head whose HR file function equals the Proposed one is a reporting change: set their old function in As Is Data (tick *Their team too*).
    - **Pending Hiring 2026:** a third vacancy type next to Replacement and New position. Choose *Pending Hiring* in Admin → Vacant Positions, or write *Pending Hiring* in the *Vacancy* column of the Vacant positions sheet in Data Transfer. The card (after Replacement 2026, Proposed State) shows the open positions with FTE / FTC; they are purple on the organogram and have their own tab in the vacancy lists. Rename it in Admin → Labels.
    - **Span of Control (Layers button):** above the layer table, Current → Proposed: Line Managers, Span Increased and Span Reduced (managers and the direct reports gained or lost). Click a figure for the details: each manager's direct reports before and after, the KM direct reports first, then the most direct reports (Download List for Excel).
    - **Geographic Consolidation:** Admin → Employees → Edit a unit head → *Geographic Consolidation* → choose the region the unit merges into (e.g. Karachi). The card shows the regions today and the one proposed. Data Transfer column: *Geographic Consolidation (region)*.
    - **Surrender and replacement:** Admin → Employees → Edit → Restructure: tick **Headcount saved**, then optionally **Replace with a vacant position** (position, grade, FTE / FTC). Choose who the replacement reports to (default: the same line manager). The portal creates the linked Replacement vacant position: a Special Replacement (PR when the staff member is Contract / DC, also counted in Post-Retirement Staff Replacement). On the organogram the staff member's box is cut and marked *Replacement* (and *PR*), with their direct reports as is. Unticking removes that position.
    - **Trade Staff Realignment:** Admin → Employees → Edit → tick *Marked for Trade Staff Realignment* (filter *Trade Staff Realignment* in the employee list).
    - **Current State line managers:** **Admin → Current State Line Managers**: search the employee, search the new line manager, Save. It changes only the Current State (not the Proposed State, not the rest of the portal); their team stays under them. Two options: **Whole team** (their direct reports also report to the new manager in the Current State, for a flat HR file) and, when the new manager is in another function, **move them and their team to that function** in the Current State (Unit Transition Opportunity lists heads whose Current State function differs from the Proposed State). The list shows each change (HR file manager → Current State manager) with *Undo* (it also brings the team and the function back). Uploading a new HR file or *Use Database* clears these changes.
    - **Who changed:** in Proposed State, click the ▲ / ▼ change under Active Staff or a staff type: the staff in or out between the states and why (function moved, type changed, headcount saved, not in the other state).
    - **HR Dashboard only login:** Admin → Users → Add (or Edit access) → template **HR Dashboard only**: no other pages, no benchmark tick: Position Benchmark shows the framework only (no Below / At / Above lists, no Show Max Grade, no Position Realignment card). Set *HR Dashboard shows* (all or selected functions).
    - **As Is Data** (administrators) corrects anything else in the Current State for this dashboard only. **Organogram note**, **Hiring removed** and the **SEC** grade exclusion work as before.
13. **Vacant positions:** in **Admin → Vacant Positions** each position is now **Replacement** or **New position** (existing ones show as New position; edit them to change). They have different colours in the organogram (blue / amber). Rename the two in **Admin → Labels → Organogram**.
    - **An employee reporting to a vacant position:** in **Admin → Employees → Edit**, under *Reports to*, choose **Or a vacant position…**, or open the vacant position and add employees under *Employees Who Report to This Position*. They show under the vacant box (with To Be Hired on); meanwhile they count under the manager the position reports to. When the position is filled with an employee, they move to that employee.
15. **Vacant positions in Data Transfer:** the export now has a **Vacant positions** sheet. Change a row to update a position, add a row with a blank *Vacancy ID* to add one, or write *Yes* in *Delete* to remove one; then import (Check first shows the counts). Importing the same file twice does not add the new positions twice.
14. **Export HTML** (organogram buttons, for logins with Export): saves the organogram on screen as one HTML file that opens in any browser, with the layer panel on the left, search, zoom and click to open teams. Vacant positions are included when To Be Hired is shown.
12. **CHRO Dashboard:** sign in as **admin**, open **Admin → Users → Edit access** for the CHRO's login and tick **CHRO Dashboard** (only the admin login can give it). It appears in the sidebar under Dashboard.
    - **As Is** starts as the HR master file as it was imported. Fix it from **CHRO Dashboard → As Is Data**: correct a person (click them), **Add Missing Employee**, or **Upload New HR File** (same columns as the HR master file; it shows what will change before replacing). **Export As Is (Excel)** gives the file to correct offline and upload again. None of this changes the rest of the portal.
    - **Headcount saved:** in **Admin → Employees → Edit**, tick **Headcount saved** (role removed in the restructure) with a reason and date, or use the **Headcount saved** column in Data Transfer. Those roles leave the To Be; their direct reports move up to their manager there only.
    - **Export Report (PDF)** gives the executive report for the whole organisation or the function chosen at the top.

---

## If something goes wrong

```
sudo systemctl stop ops-portal
STAMP=PUT_THE_STAMP_HERE
sudo tar -xzf /data/opt/ops-portal/backups/code_before_2.15_$STAMP.tgz -C /data/opt/ops-portal
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo systemctl start ops-portal
```

The database does not need restoring: the new columns are ignored by the older version.
